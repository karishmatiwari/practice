create materialized view VIEW_STUDIO_APP_ALLOWED
refresh complete on demand
  as
    with dates_between as
(select last_day(add_months(trunc(sysdate), -2)) + 1 first_date,
         last_day(add_months(trunc(sysdate), -1)) last_date
    from dual),
max_date as
(select max(event_date) max_date from TABLE_STUDIO_APP_ALLOWED cross join dates_between where   event_date between  trunc(dates_between.first_date) and  trunc(dates_between.last_date) )
SELECT CE.ENV_UUID                               ENVIRONMENT_UUID,
       CE.ENV_ID                                       ENVIRONMENT_ID,
       CE.ENV_NAME                                     ENVIRONMENT_NAME,
       cdc.data_center_name,
       CCP.CP_ID                                       CLIENT_PROJECT_ID,
       CCP.CP_CLIENT_ID                                CLIENT_ID,
       to_char(CCP.CP_SUB_PROJECT_ID)                           SUB_PROJECT_ID,
       ccp.cp_client_name                              client_name,
       CET.ENV_TYPE_VALUE                              ENVIRONMENT_TYPE,
       to_char(dates_between.last_date, 'DD-MM-YYYY') METRIC_DATE,
       TRIM(to_CHAR(dates_between.last_date, 'Month')) ||' '||to_CHAR(dates_between.last_date, 'YYYY') METRIC_MONTH,
       TEFS.NO_OF_ALLOWED_STUDIO_APPS
  FROM TABLE_STUDIO_APP_ALLOWED TEFS
  JOIN CONFIG_ENVIRONMENTS CE
    ON ( TRIM(TEFS.environment_name) = TRIM(CE.env_name) and tefs.ENV_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
  join config_data_centers cdc
    on ce.env_data_center_id = cdc.data_center_id
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
cross join dates_between
cross join max_date
where trunc(event_date) = trunc(max_date.max_date)
and   CE.STATUS='Y' and CCP.CP_IS_DELETED=0
/

