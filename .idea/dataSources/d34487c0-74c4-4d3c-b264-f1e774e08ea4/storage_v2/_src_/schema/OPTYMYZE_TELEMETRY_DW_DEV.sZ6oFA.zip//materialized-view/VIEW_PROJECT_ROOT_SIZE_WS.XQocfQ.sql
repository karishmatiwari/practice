create materialized view VIEW_PROJECT_ROOT_SIZE_WS
refresh complete on demand
  as
    with dates_between as
(select NEXT_DAY(sysdate, 'MONDAY') - 14 first_date,
       NEXT_DAY(sysdate, 'SUNDAY') - 7 last_date
  from dual),
max_date as
(select max(event_time) max_date from TABLE_PROJECT_ROOT_SIZE_WS cross join dates_between where  event_time <= trunc(dates_between.last_date) )
SELECT CE.ENV_UUID                               ENVIRONMENT_UUID,
       CE.ENV_ID                                       ENVIRONMENT_ID,
       CE.ENV_NAME                                     ENVIRONMENT_NAME,
       CDC.DATA_CENTER_NAME                            data_center_name,
       CCP.CP_ID                                       CLIENT_PROJECT_ID,
       CCP.CP_CLIENT_ID                                CLIENT_ID,
       to_char(CCP.CP_SUB_PROJECT_ID)                 SUB_PROJECT_ID,
       ccp.cp_client_name                              client_name,
       CET.ENV_TYPE_VALUE                              ENVIRONMENT_TYPE,
       to_char(dates_between.last_date, 'DD-MM-YYYY') METRIC_DATE,
       TRIM(to_CHAR(dates_between.last_date, 'Month')) ||' '||to_CHAR(dates_between.last_date, 'YYYY') METRIC_MONTH,
       file_name,
folder,
file_path,
file_extension,
size_in_bytes
  FROM TABLE_PROJECT_ROOT_SIZE_WS TPRS
  JOIN CONFIG_ENVIRONMENTS CE
    ON TRIM(TPRS.ENV_UUID) = TRIM(CE.ENV_UUID)
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON CCP.CP_ID = CE.ENV_CP_ID
  join config_data_centers cdc
    on ce.env_data_center_id = cdc.data_center_id
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
cross join dates_between
cross join max_date
WHERE trunc(event_time) = trunc(max_date.max_date)
and  CE.STATUS='Y' and CCP.CP_IS_DELETED=0
/

