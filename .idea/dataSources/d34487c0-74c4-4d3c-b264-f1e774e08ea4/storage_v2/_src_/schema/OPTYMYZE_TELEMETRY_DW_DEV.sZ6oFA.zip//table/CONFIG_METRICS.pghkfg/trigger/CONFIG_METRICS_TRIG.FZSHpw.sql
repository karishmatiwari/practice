create trigger CONFIG_METRICS_TRIG
  after insert or update of METRIC_ID, METRIC_INPUT_FILE_PATH or delete
  on CONFIG_METRICS
  for each row
  BEGIN
      if DELETING or updating then
        delete from config_metric_data_centre_map where metric_id=TO_CHAR(:OLD.metric_ID);
      END IF;

       IF INSERTING or UPDATING then
         if (instr(lower(:new.METRIC_INPUT_FILE_PATH),q'`/datacentre_check/`')) > 0 then
           insert into  config_metric_data_centre_map cmdc 
             select :new.metric_id,cdc.DATA_CENTER_ID,decode(cdc.DATA_CENTER_FLAG,0,'N',1,'Y')
             from CONFIG_DATA_CENTERS cdc ;
         else --  (instr(lower(:new.METRIC_INPUT_FILE_PATH),q'`/datacentre_all/`')) > 0 then
           insert into  config_metric_data_centre_map cmdc 
             select :new.metric_id,'DATACENTRE_ALL',
             decode(coalesce((select '1' from CONFIG_DATA_CENTERS cdc where cdc.DATA_CENTER_FLAG =1 and rownum =1 ),'0'),'1','Y','N')
             from dual ;
         end if;
      END IF ;
  
END config_metrics_trig;
/

