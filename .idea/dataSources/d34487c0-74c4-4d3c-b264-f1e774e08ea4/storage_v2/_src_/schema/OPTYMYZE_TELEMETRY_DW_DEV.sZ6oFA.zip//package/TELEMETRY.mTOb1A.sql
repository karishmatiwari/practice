create PACKAGE telemetry AS

  PROCEDURE p_objects_count(pi_file_date IN DATE);                 --
  PROCEDURE p_studio_app_count(pi_file_date IN DATE);              --
  PROCEDURE p_studio_app_allowed(pi_file_date IN DATE);            --
  PROCEDURE p_widget_count(pi_file_date IN DATE);                  --
  PROCEDURE p_optymyze_version(pi_file_date IN DATE);              --
  PROCEDURE p_used_space(pi_file_date IN DATE);                    --
  PROCEDURE p_data_processed_volume(pi_file_date IN DATE);         --
  PROCEDURE p_backup_size_time(pi_file_date IN DATE);              --
  PROCEDURE p_user_languages(pi_file_date IN DATE);                --
  PROCEDURE p_languages_per_client_count(pi_file_date IN DATE);    --
  PROCEDURE p_studio_app_licenced(pi_file_date IN DATE);           --


  PROCEDURE p_http_sessions(pi_file_date IN DATE) ;      -- app
  PROCEDURE p_web_service_call(pi_file_date IN DATE) ;   -- app
  PROCEDURE p_login_sessions(pi_file_date IN DATE) ;     -- app
  PROCEDURE p_email_count(pi_file_date IN DATE);         -- app
  PROCEDURE p_studio_app_time(pi_file_date IN DATE) ;    -- app
  PROCEDURE p_widget_load_count(pi_file_date IN DATE) ;  -- app
  --PROCEDURE p_object_used_space(pi_file_date IN DATE) ;  -- PHS (OS)
  
  PROCEDURE p_lang_per_client_count_ws(pi_file_date IN DATE) ;  -- ws

END;
/

