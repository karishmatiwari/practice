create materialized view VIEW_PUSH_NOTIFICATIONS
refresh force on demand
  as
    with dates_between as
(select last_day(add_months(trunc(sysdate), -2)) + 1 first_date,
         last_day(add_months(trunc(sysdate), -1)) last_date
    from dual)
SELECT TPNU.ENVIRONMENT_UUID                                    ENVIRONMENT_UUID,
       CE.ENV_ID                                       ENVIRONMENT_ID,
       CE.ENV_NAME                                     ENVIRONMENT_NAME,
       CCP.CP_ID                                       CLIENT_PROJECT_ID,
        to_char(CCP.CP_CLIENT_ID)                              CLIENT_ID,
       to_char(CCP.CP_SUB_PROJECT_ID)                 SUB_PROJECT_ID,
       ccp.cp_client_name                              client_name,
       CET.ENV_TYPE_VALUE                              ENVIRONMENT_TYPE,
       to_char(dates_between.last_date, 'DD-MM-YYYY') METRIC_DATE,
       TRIM(to_CHAR(dates_between.last_date, 'Month')) ||' '||to_CHAR(dates_between.last_date, 'YYYY') METRIC_MONTH,
       DEVICE_ID                       DEVICE_ID,
       device_type                     device_type,
       device_os                       device_os,
       SEND_STATUS                     SEND_STATUS,
count (DEVICE_ID) Device_notification_count
  FROM TABLE_PUSH_NOTIFICATION_UNIQUE TPNU
  JOIN CONFIG_ENVIRONMENTS CE
    ON TPNU.ENVIRONMENT_UUID = CE.ENV_UUID
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON CCP.CP_ID = CE.ENV_CP_ID
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
cross join dates_between
where trunc(EVENT_TIME) between  trunc(dates_between.first_date) and  trunc(dates_between.last_date)
and   CE.STATUS='Y' and CCP.CP_IS_DELETED=0
group by
        TPNU.environment_uuid         ,
        TPNU.device_type              ,
        TPNU.device_os                ,
        TPNU.DEVICE_ID                ,
        TPNU.SEND_STATUS              ,
        CE.ENV_ID                     ,
        CE.ENV_NAME                   ,
        CCP.CP_ID                     ,
        to_char(CCP.CP_CLIENT_ID)     ,
        TO_CHAR(CCP.CP_SUB_PROJECT_ID),
        ccp.cp_client_name            ,
        CET.ENV_TYPE_VALUE            ,
        to_char(dates_between.last_date, 'DD-MM-YYYY') ,
        TRIM(to_CHAR(dates_between.last_date, 'Month')) ||' '||to_CHAR(dates_between.last_date, 'YYYY')
/

