create PROCEDURE p_job_create_fetch_SQS_metrics IS
      exists_cnt pls_integer;
      BEGIN
      
       SELECT COUNT(1)
        INTO exists_cnt
        FROM user_SCHEDULER_SCHEDULES
        WHERE schedule_name = 'NEW_SCHEDULE';

        IF exists_cnt=0 THEN
          -- schedule Creation
          DBMS_SCHEDULER.CREATE_SCHEDULE (schedule_name => 'NEW_SCHEDULE',
                                          Repeat_interval => 'FREQ=MINUTELY; INTERVAL=10',
                                          start_date => TRUNC(SYSDATE)-900/86400, 
                                          Comments => '10 Minute schedule');
       END IF;
       
      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_PROGRAMS
      WHERE PROGRAM_NAME = 'FETCH_SQS_METRIC_PROG';
      IF exists_cnt      =0 
      THEN
      DBMS_SCHEDULER.CREATE_PROGRAM(program_name        => 'FETCH_SQS_METRIC_PROG',
                                    program_type        => 'STORED_PROCEDURE',
                                    program_action      => 'COMMONS_UTILS.P_SQS_METRICS_WRAPPER', --CHANGE PROC NAME
                                    number_of_arguments => 1,
                                    enabled             => false,
                                    comments            => 'fetch SQS metrics');
                                    
      DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT(program_name      => 'FETCH_SQS_METRIC_PROG',
                                            argument_position => 1,
                                            argument_name     => 'P_check_flag',
                                            argument_type     => 'VARCHAR2',
                                            default_value     => 'Y');
    
      DBMS_SCHEDULER.ENABLE(name => 'FETCH_SQS_METRIC_PROG');
      END IF;
      
      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_JOBS a
      WHERE JOB_NAME = 'FETCH_SQS_METRIC_JOB';
      
      IF exists_cnt  =0 
      THEN
      DBMS_SCHEDULER.CREATE_JOB(Job_name => 'FETCH_SQS_METRIC_JOB',
                                Program_name => 'FETCH_SQS_METRIC_PROG',
                                Schedule_name => 'NEW_SCHEDULE',
                                Enabled => TRUE,
                                auto_drop => FALSE,
                                Comments => 'This job will run the FETCH_SQS_METRIC_JOB program according to the NEW_SCHEDULE schedule.'
                                );
                                    
      DBMS_SCHEDULER.SET_JOB_ARGUMENT_VALUE(job_name       => 'FETCH_SQS_METRIC_JOB',
                                            argument_name  => 'P_CHECK_FLAG',
                                            argument_value => 'Y');
                              
      END IF;
    END p_job_create_fetch_SQS_metrics;
/

