create materialized view VIEW_COMP_VIEW_BYTES_WS
refresh force on demand
  as
    SELECT CE.ENV_UUID ENVIRONMENT_UUID,
       CE.ENV_ID ENVIRONMENT_ID,
       CE.ENV_NAME ENVIRONMENT_NAME,
       cdc.data_center_name,
       CCP.CP_ID CLIENT_PROJECT_ID,
       CCP.CP_CLIENT_ID CLIENT_ID,
       TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
       ccp.cp_client_name client_name,
       CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
       TRUNC(A.EVENT_TIME) METRIC_DATE,
       TRIM(TO_CHAR(TRUNC(A.EVENT_TIME), 'Month')) || ' ' ||
       TO_CHAR(TRUNC(A.EVENT_TIME), 'YYYY') metric_month,
       STD.COMPONENT_VIEW_PAGE_ID,
       STD.VIEW_ID,
       STD.PORTAL_VIEW_ID,
       STD.APP_MENU_ITEM_NAME "APP ITEM NAME",
       STD.APP_MENU_ITEM_LABEL "APP ITEM LABEL",
       STD.PAGE_NAME,
       STD.PAGE_LABEL,
       STD.PAGE_TYPE,
       STD.PORTAL_APPLICATION_ID,
       STD.PORTAL_APPLICATION_NAME,
       STD.PORTAL_APPLICATION_LABEL,
       STD.PORTAL_APPLICATION_GROUP_ID,
       STD.PORTAL_APPLICATION_GROUP_NAME,
       A.APP_COMPONENT,
       A.TABLE_NAME,
       DECODE (A.TABLE_TYPE_FLAG,1,'TABLE',2,'VIEW',3,'SYNONYM') TABLE_TYPE_FLAG,
       A.TABLE_TYPE,
       round((DECODE (A.TABLE_TYPE_FLAG,2,(DECODE(A.TABLE_ROWS,0,131072,
              (A.TABLE_ROWS*CE.A_ROW_BYTE_VAL))), A.BYTES_READ)/1024/1024),3) BYTES_READ,
       A.TABLE_ROWS,
       A.PARENT_NAME,
       A.COMPONENT_VIEW_ID,
       A.COMPONENT_TITLE,
       A.COMPONENT_SUBTITLE,
       A.COMPONENT_VIEW_NAME,
       A.COMPONENT_DEFINITION_ID,
       A.COMPONENT_NAME,
       ce.ENV_VERSION,
       ce.release_year,
       ce.release_month,
       ce.branch_number,
       ce.build_number
  FROM TABLE_STUDIO_APPS_COMP_VIEW_WS STD
  JOIN CONFIG_ENVIRONMENTS CE
    ON TRIM(STD.ENV_UUID) = TRIM(CE.ENV_UUID)
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID and
       ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
  JOIN config_data_centers cdc
    ON ce.env_data_center_id = cdc.data_center_id
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
  JOIN (SELECT ENV_UUID,app_component,
               table_name,
               table_type_flag,
               table_type,
               bytes_read,
               table_rows,
               parent_name,
               component_view_id,
               table_component_title    component_title,
               table_component_subtitle component_subtitle,
               component_view_name,
               component_definition_id,
               table_component_name     component_name,
               event_time
          FROM TABLE_TAB_COMP_VIEW_BYTES_WS
         where TRUNC(event_time) = TRUNC(SYSDATE - 1)
        union ALL
        SELECT ENV_UUID,app_component,
               table_name,
               table_type_flag,
               table_type,
               bytes_read,
               table_rows,
               parent_name,
               component_view_id,
               vr_component_title         component_title,
               vr_component_subtitle      component_subtitle,
               vr_component_name          component_name,
               vr_component_definition_id component_definition_id,
               vr_component_view_name     component_view_name,
               event_time
          FROM TABLE_VISUAL_RECORDS_BYTES_WS VR
         where TRUNC(event_time) = TRUNC(SYSDATE - 1)
        union ALL
        SELECT ENV_UUID,app_component,
               table_name,
               table_type_flag,
               table_type,
               bytes_read,
               table_rows,
               parent_name,
               component_view_id,
               pie_chart_component_title    component_title,
               pie_chart_component_subtitle component_subtitle,
               component_view_name,
               component_definition_id,
               pie_chart_component_name     component_name,
               event_time
          FROM TABLE_PIE_CHART_BYTES_WS PIE
         where TRUNC(event_time) = TRUNC(SYSDATE - 1)
        union ALL
        SELECT ENV_UUID,app_component,
               table_name,
               table_type_flag,
               table_type,
               bytes_read,
               table_rows,
               parent_name,
               component_view_id,
               xy_chart_component_title    component_title,
               xy_chart_component_subtitle component_subtitle,
               component_view_name,
               component_definition_id,
               xy_chart_component_name     component_name,
               event_time
          FROM TABLE_XY_CHART_BYTES_WS XY
         where TRUNC(event_time) = TRUNC(SYSDATE - 1)
        union ALL
        SELECT ENV_UUID,app_component,
               table_name,
               table_type_flag,
               table_type,
               bytes_read,
               table_rows,
               parent_name,
               component_view_id,
               ang_gauge_component_title    component_title,
               ang_gauge_component_subtitle component_subtitle,
               component_view_name,
               component_definition_id,
               ang_gauge_component_name     component_name,
               event_time
          FROM TABLE_ANG_GAUGE_BYTES_WS AG
         where TRUNC(event_time) = TRUNC(SYSDATE - 1)) A
    ON STD.COMPONENT_VIEW_ID = A.COMPONENT_VIEW_ID
     and A.ENV_UUID = STD.ENV_UUID
 WHERE TRUNC(STD.EVENT_TIME) = TRUNC(A.EVENT_TIME)
   AND CE.STATUS = 'Y'
   AND CCP.CP_IS_DELETED = 0
/

