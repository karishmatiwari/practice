create materialized view VIEW_DATA_TRANSFORMATION_WS
refresh force on demand
  as
    SELECT CE.ENV_UUID ENVIRONMENT_UUID,
  CE.ENV_ID ENVIRONMENT_ID,
  CE.ENV_NAME ENVIRONMENT_NAME,
  cdc.data_center_name,
  CCP.CP_ID CLIENT_PROJECT_ID,
  CCP.CP_CLIENT_ID CLIENT_ID,
  TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
  ccp.cp_client_name client_name,
  CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
  trunc(sysdate-1) METRIC_DATE,
  TRIM(TO_CHAR(trunc(sysdate-1), 'Month'))
  ||' '
  ||TO_CHAR(trunc(sysdate-1), 'YYYY') metric_month,
  DT.DATA_TRANS_NAME,
  DT.DATA_TRANS_FOLDER_NAME,
  DT.DATA_TRANS_DESCRIPTION,
  DT.DATA_TRANS_FREQUENCY,
  regexp_count(DT.DATA_TRANS_INPUT_TABLES, ',') + 1 data_trans_input_tables_count,
  regexp_count(DT.DATA_TRANS_OUTPUT_TABLES, ',') + 1 data_trans_output_tables_count,
  --DT.DATA_TRANS_INPUT_TABLES,
  --DT.DATA_TRANS_OUTPUT_TABLES,
  DT.DATA_TRANS_OPERATIONS_COUNT,
  DT.DATA_TRANS_LAST_RUN_DATE,
  DT.DATA_TRANS_CREATED_DATE,
  --DT.DATA_TRANS_CREATED_BY
  nvl(ro.login_id,DT.DATA_TRANS_CREATED_BY) DATA_TRANS_CREATED_BY,
  ce.ENV_VERSION,
       ce.release_year,
       ce.release_month,
       ce.branch_number,
       ce.build_number
  FROM TABLE_DATA_TRANSFORMATION_WS DT
JOIN CONFIG_ENVIRONMENTS CE
ON TRIM(DT.ENV_UUID)    = TRIM(CE.ENV_UUID)
JOIN CONFIG_CLIENT_PROJECTS CCP
ON (CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
JOIN config_data_centers cdc
ON ce.env_data_center_id = cdc.data_center_id
JOIN CONFIG_ENVIRONMENT_TYPES CET
ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
left outer join table_role_wise_user_ws ro
on to_char(ro.user_id)=dt.data_trans_created_by
and trunc(ro.event_time)=TRUNC(dt.event_time)
--and ro.env_uuid=dt.env_uuid
WHERE TRUNC(DT.EVENT_TIME) = trunc(sysdate-1)
AND CE.STATUS='Y' and CCP.CP_IS_DELETED=0
/

