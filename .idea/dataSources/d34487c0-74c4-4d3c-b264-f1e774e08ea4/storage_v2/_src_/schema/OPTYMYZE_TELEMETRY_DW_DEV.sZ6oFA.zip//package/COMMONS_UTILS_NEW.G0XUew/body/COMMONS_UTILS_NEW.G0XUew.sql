create PACKAGE BODY commons_utils_new AS
-- -----------------------------------------------------------------------------
  -- Copyright (c) 2018 - 2019 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product        : Client Analytics Portal
  -- Module         : Client Analytics Portal
  -- First version Requester/s  : Pimparkar Shriniket,Gaurav Rajput
  -- First version author/s : Gaurav Rajput 
  -- First Create date    : 20181210
  -- First version Reviewer       : -- 
  -- First version Review date    : --
  -- Description    : Package used to handle new architecture operations for Client Analytics Portal

  -- Change author      :
  -- Change date        :
  -- Change reviewer    :
  -- Change review date :
  -- Change description :
  -- ---------------------------------------------------------------------------
  

  procedure p_set_context_new_loader_seq(pin_loader_seq pls_integer default new_loader_seq.nextval ) IS
  begin
     dbms_session.set_context('gc_new_loader_seq_cur_val', 'global_attribute', pin_loader_seq);   
  end p_set_context_new_loader_seq;
  
  procedure p_create_context_nw_loadr_seq IS
  begin
   execute immediate'create context gc_new_loader_seq_cur_val using commons_utils_new accessed globally'; 
  end p_create_context_nw_loadr_seq;  
  
    
 procedure p_create_contexts IS
  begin
     p_create_context_nw_loadr_seq;
  end  p_create_contexts;
    
  PROCEDURE p_load_metric(pi_file_date IN DATE , pi_metric_id IN varchar2,pi_extra_derived_cols_val varchar2,pi_attach_string_to_filenam varchar2 default 'TESTING',
     Pi_Merge_insert_flag IN VARCHAR2 DEFAULT 'N') IS
  -- ------------------------------------------------------------------------------------
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Description    : Generic procedure that performs loading of the provided metric into its respective base table.
  
  -- Change description :
  -- ------------------------------------------------------------------------------------
    
    lv_insert_into_central_table commons_utils.maxvarchar2;
    lv_external_tab_column_list  commons_utils.optimizedvarchar2;
    lv_staging_tab_column_list   commons_utils.optimizedvarchar2;
    lv_ext_tab_col_nam_datatype  commons_utils.optimizedvarchar2;
    lv_access_parameter_col_list commons_utils.optimizedvarchar2;
    lv_directory_name            commons_utils.optimizedvarchar2;
    lv_file_name                 commons_utils.optimizedvarchar2;
    lv_metric_table_name         commons_utils.optimizedvarchar2;
    lv_view_name                 commons_utils.optimizedvarchar2;
    lv_metric_name               commons_utils.optimizedvarchar2;
    lv_metric_input_file_path    commons_utils.optimizedvarchar2;
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_num_processed             PLS_INTEGER;
    lv_proc_name                 commons_utils.optimizedvarchar2;
    lv_metric_source_id          PLS_INTEGER;
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;
    lv_csv_file_name             commons_utils.optimizedvarchar2;
    lv_bad_file_name             commons_utils.optimizedvarchar2; 
    lv_external_tab_name         commons_utils.optimizedvarchar2; 
    lv_field_delimiter           commons_utils.optimizedvarchar2; 
    lv_data_centre_id            commons_utils.optimizedvarchar2;  
    lv_staging_tab_col_nam_datatyp commons_utils.optimizedvarchar2;
    lv_Merge_on_clause commons_utils.maxvarchar2;
    lv_merge_values_clause commons_utils.maxvarchar2;
    lv_date_column_name commons_utils.optimizedvarchar2;
    lv_date_column_value commons_utils.optimizedvarchar2;
    lv_root commons_utils.optimizedvarchar2;
    
  BEGIN

    lv_proc_name   := Upper('p_load_metric') || ' for Metric id ' || pi_metric_id;
    lv_data_centre_id :='Datacentre_All';
    
    -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
    commons_utils.p_fetch_metric_details(pi_file_date                  => pi_file_date,
                                         pi_metric_id                  => pi_metric_id,
                                         pi_data_center_id             => lower(lv_data_centre_id),
                                         pi_attach_string_to_filenam   => pi_attach_string_to_filenam,
                                         po_metric_table_name        => lv_metric_table_name,
                                         po_view_name                => lv_view_name,
                                         po_metric_input_file_path   => lv_metric_input_file_path,
                                         po_external_tab_column_list => lv_external_tab_column_list,
                                         po_staging_tab_column_list  => lv_staging_tab_column_list,
                                         po_access_parameter_col_list=> lv_access_parameter_col_list,
                                         po_ext_tab_col_nam_datatype => lv_ext_tab_col_nam_datatype,
                                         po_staging_tab_col_nam_datatyp=>lv_staging_tab_col_nam_datatyp ,
                                         po_metric_source_id         => lv_metric_source_id,
                                         po_csv_file_name            => lv_csv_file_name,
                                         po_bad_file_name            => lv_bad_file_name,
                                         po_metric_external_table_nam => lv_external_tab_name,
                                         po_metric_name               => lv_metric_name,
                                         po_metric_default_dir_name =>lv_directory_name,
                                         po_field_delimiter =>lv_field_delimiter );
    dbms_output.put_line(lv_bad_file_name);
    -- get the csv filename that are present at the path 
    BEGIN
      commons_utils.p_get_filename(pi_directory => lv_metric_input_file_path,pi_filename => lv_csv_file_name);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE commons_utils.ex_directory_missing;
    END;

    BEGIN
      SELECT filename
        INTO lv_file_name
        FROM dir_list
       WHERE  upper(filename) = upper(lv_csv_file_name);

    EXCEPTION
      WHEN no_data_found THEN
        dbms_output.put_line(lv_metric_input_file_path || '-->'||lv_csv_file_name);
        RAISE commons_utils.ex_file_missing;
      WHEN OTHERS THEN
        RAISE;
    END; 

    -- Replace the directory to point to the specified path
    commons_utils.p_replace_directory(pi_path=> lv_metric_input_file_path,pi_directory_name=>lv_directory_name);
 
    -- alter the external table with the location file and the log file 
    commons_utils.p_alter_external_table(pi_ext_table_name => lv_external_tab_name,
                                          pi_csv_file_name => lv_csv_file_name,
                                          pi_bad_file_name => lv_bad_file_name,
                                          pi_access_parameter_col_list => lv_access_parameter_col_list,
                                          pi_field_delimiter => lv_field_delimiter,
                                          pi_logging_dir => 'new_logging_dir'
                                        );

IF pi_extra_derived_cols_val is not null then 
      -- insertion in the specified metric table
      
IF Pi_Merge_insert_flag = 'N' THEN  
      
      lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' ||lv_staging_tab_column_list||')
                                       select ' || lv_external_tab_column_list || ',' ||pi_extra_derived_cols_val||'
                                       from ' || lv_external_tab_name  ;
ELSE  
      SELECT pr.pr_name, pr.pr_value into lv_date_column_name,lv_date_column_value FROM PROPERTIES pr where pr.pr_id= pi_metric_id;
        
      lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' ||lv_staging_tab_column_list||')
                                       select ' || lv_external_tab_column_list || ',' ||pi_extra_derived_cols_val||'
                                       from ' || lv_external_tab_name ||' WHERE trunc('||lv_date_column_name|| ')>to_date('''
                                       ||lv_date_column_value||''',''DD.MM.YYYY'')';


                                                                   
END IF;                                    
                                       
    ELSE
      -- insertion in the specified metric table
      lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' ||lv_staging_tab_column_list||')
                                       select ' || lv_external_tab_column_list ||'
                                       from ' || lv_external_tab_name  ;      
END IF;    
    
    EXECUTE IMMEDIATE lv_insert_into_central_table;
    
    lv_num_processed := SQL%ROWCOUNT;

    -- retrieve the list of .bad  present at the path 
    commons_utils.p_get_filename(pi_directory => commons_utils.gv_loggingroot,pi_filename => lv_bad_file_name);
    BEGIN
      SELECT count(*)
        INTO lv_badfile_cnt
        from dir_list
       where lower(filename) = lower(lv_bad_file_name);

    EXCEPTION
      WHEN OTHERS THEN
        RAISE;
    END;

    if lv_badfile_cnt > 0 then
      raise commons_utils.ex_bad_file_exists;
    end if;

    -- exception to check if the file being loaded is empty ?
    if lv_num_processed = 0 then
     raise commons_utils.ex_file_empty;
    end if;

    -- clean the GTT
    DELETE FROM dir_list
    WHERE  upper(filename) = upper(lv_csv_file_name);
     
    DELETE FROM dir_list
     where lower(filename) = lower(lv_bad_file_name);
     
    UPDATE table_load_metrics
    SET loaded_flag = 'Y'
    WHERE metric_id = pi_metric_id
    AND loaded_date = pi_file_date; 

    UPDATE PROPERTIES P
    SET P.PR_VALUE = TO_CHAR(trunc(sysdate-1), 'DD.MM.YYYY')
    WHERE P.PR_ID = pi_metric_id; 

  EXCEPTION
    WHEN OTHERS THEN
      execute immediate 'ROLLBACK TO S_'||pi_metric_id;

    -- clean the GTT
    DELETE FROM dir_list
     WHERE  upper(filename) = lv_csv_file_name;
     
    DELETE FROM dir_list
     where lower(filename) = lower(lv_bad_file_name);
     
      IF SQLCODE = commons_utils.c_ex_directory_missing THEN
        commons_utils.p_error_logging(pi_metric_id            => pi_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Directory does not exist OR read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = commons_utils.c_ex_file_missing THEN
        commons_utils.p_error_logging(pi_metric_id            => pi_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = commons_utils.c_ex_bad_file_exists THEN
        commons_utils.p_error_logging(pi_metric_id            => pi_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Bad file '||lv_bad_file_name ||' was generated for '||lv_data_centre_id||' on at the following path ' || commons_utils_new.gv_loggingroot,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
     ELSIF SQLCODE = commons_utils.c_ex_file_empty THEN
        commons_utils.p_error_logging(pi_metric_id            => pi_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'File '||lv_csv_file_name ||' does not have any records for '||lv_data_centre_id||' on at the following path ' || lv_metric_input_file_path,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSE
        commons_utils.p_error_logging(pi_metric_id            => pi_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Failed at p_load_metric for metric '||lv_metric_name|| ' with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      END IF;
  END p_load_metric;
  
  
 /* PROCEDURE p_fetch_SQS_metrics_wrapper(pin_processing_date in date, pi_attach_string_to_filenam in varchar2 default 'TEST' )  is
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that fetches the SQS metrics
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    lv_start_epoch_time number;
    lv_end_epoch_time   number;
    lv_proc_name  VARCHAR2(4001 CHAR) ;
    lv_metric_name VARCHAR(30 CHAR) ;
    lv_start_date date;
    lv_end_date date ;
    lv_split_value pls_integer;
    lv_Addition_factor pls_integer;
    lv_fetch_flag varchar2(4001);
    lv_state varchar2(4001);
  
    le_state_of_job EXCEPTION;
    
  BEGIN
    lv_proc_name  := 'p_fetch_SQS_metrics_wrapper';
    lv_metric_name := 'SQS_METRICS';
    
    p_insert_table_fetch_metrics(lv_metric_name,pin_processing_date);
    lv_end_date := to_date(pin_processing_date,'DD-MM-RRRR') -(1/86400) ;
    
    begin
        SELECT distinct cmsm.SPLIT_VALUE,tfm.fetched_flag
        INTO  lv_split_value,lv_fetch_flag
        FROM table_fetch_metrics tfm ,
          config_fetch_metrics_split cfms,
          config_metrics_splits_master cmsm
        WHERE tfm.Metric_or_group_name = lv_metric_name
        AND tfm.fetched_date           = pin_processing_date
        --AND tfm.fetched_flag           = 2
        AND tfm.Metric_or_group_name   = cfms.Metric_or_group_name
        AND cfms.split_id              = cmsm.split_id
        AND cmsm.enabled_flag          = 'Y';
    exception
    when No_data_found then
      lv_fetch_flag :=  2 ;
      lv_split_value := 1 ;
     when Others then
       raise;
     end;
  
  if lv_fetch_flag = '2'    then
  
       
  
          BEGIN
           p_job_run_fetch_app_metrics('-create', lv_start_epoch_time, lv_end_epoch_time, pi_attach_string_to_filenam,'-Xmx2048m' ,'FETCH_APP',NULL); ----COMBINE_JOB 
  
            LOOP
                dbms_lock.sleep(20);

            -- using this instead of user_scheduler_jobs because of oracle's bug where status is not updated at times
              SELECT STATUS
              INTO lv_state
              FROM
              (SELECT u.STATUS,
              row_number() over ( partition BY JOB_NAME order by ACTUAL_START_DATE DESC) rn
                FROM user_SCHEDULER_JOB_RUN_DETAILS u
                WHERE job_name= 'FETCH_APP_METRIC_JOB'
                )
              WHERE rn =1 ;  

                IF lv_state   IN( 'SUCCEEDED','COMPLETED','SCHEDULED') THEN
                     EXIT;
                ELSIF   lv_state = 'RUNNING' THEN
                    CONTINUE;
                ELSE
                      RAISE le_state_of_job;
                END IF;
  
          EXCEPTION
           WHEN le_state_of_job THEN
          commons_utils.p_error_logging(pi_metric_id    => lv_metric_name,
                                        pi_procedure_name => lv_proc_name,
                                        pi_error_message  => 'The state of the job  FETCH_APP_METRIC_JOB at  ' || sysdate || 'was '|| lv_state || 'hence fetching of application metrics did not take place ',
                                        pi_error_in_code  => SQLCODE,
                                        pi_tel_error_event_date => pin_processing_date);
                                       -- RAISE;
  
            WHEN OTHERS THEN
             commons_utils.p_error_logging(pi_metric_id    => lv_metric_name,
                                         pi_procedure_name => lv_proc_name,
                                         pi_error_message  => 'Error in p_job_run_fetch_app_metrics : '   || SQLERRM,
                                         pi_error_in_code  => SQLCODE,
                                         pi_tel_error_event_date => pin_processing_date);
                                        -- raise;
          END;
  
        END LOOP;
  
        IF lv_state   IN( 'SUCCEEDED','COMPLETED','SCHEDULED') THEN
                UPDATE table_fetch_metrics
                SET fetched_flag           = 0
                WHERE metric_or_group_name = 'SQS_METRICS'
                AND fetched_date           = pin_processing_date
                AND fetched_flag           = 2;
                COMMIT;
  
        END IF;
  
  END IF;
   EXCEPTION
    WHEN OTHERS THEN
            commons_utils.p_error_logging(pi_metric_id    => lv_metric_name,
                                        pi_procedure_name => lv_proc_name,
                                        pi_error_message  => 'Error in p_fetch_SQS_metrics_wrapper : ' || SQLERRM,
                                        pi_error_in_code  => SQLCODE,
                                        pi_tel_error_event_date => pin_processing_date);
                                        raise;
  END p_fetch_SQS_metrics_wrapper; */
  
PROCEDURE p_load_SQS_wrapper(pin_processing_date date) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Description    : Wrapper procedure for loading of SQS metric
  
  -- Change description :
  -- -----------------------------------------------------------------------------
    lv_metric_string varchar2(4001);
  BEGIN
    SELECT LISTAGG(CM.METRIC_ID,',') within GROUP(ORDER BY CM.METRIC_ID) INTO lv_metric_string FROM CONFIG_METRICS CM WHERE CM.METRIC_SOURCE_ID = 10  AND CM.METRIC_ENABLED='Y';
    
    commons_utils.p_insert_table_load_metrics(pin_processing_date,lv_metric_string);
    FOR indx_metric_id IN (SELECT distinct metric_id
                             FROM table_load_metrics
                            WHERE loaded_flag = 'N'
                              AND loaded_date = pin_processing_date
                              and metric_id in (91,92,93,94,95,96,98,99,100,101,102,103,104,105,106)) LOOP  
begin                              
      <<case_metrics_function_call>>
      CASE indx_metric_id.metric_id
      when 91 then
           SAVEPOINT S_91;
           commons_utils_new.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>91,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
/*     
     when 92 then
           SAVEPOINT S_92;
           commons_utils_new.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>92,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
  
    when 93 then
           SAVEPOINT S_93;
           commons_utils_new.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>93,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');

    when 94 then
           SAVEPOINT S_94;
           commons_utils_new.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>94,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                                    

    when 95 then
           SAVEPOINT S_95;
           commons_utils_new.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>95,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                                    

    when 96 then
           SAVEPOINT S_96;
           commons_utils_new.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>96,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                                    
                                   
    when 98 then
           SAVEPOINT S_98;
           commons_utils_new.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>98,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                                    
    when 99 then
           SAVEPOINT S_99;
           commons_utils_new.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>99,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                                    

    when 100 then
           SAVEPOINT S_100;
           commons_utils_new.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>100,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                                    

    when 101 then
           SAVEPOINT S_101;
           commons_utils_new.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>101,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                                    
    when 102 then
           SAVEPOINT S_102;
           commons_utils_new.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>102,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                                    
    when 103 then
           SAVEPOINT S_103;
           commons_utils_new.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>103,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                                    
    when 104 then
           SAVEPOINT S_104;
           commons_utils_new.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>104,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');  */                                  
    when 105 then
           SAVEPOINT S_105;
           commons_utils_new.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>105,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                                    
/*    when 106 then
           SAVEPOINT S_106;
           commons_utils_new.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>106,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                                    
  */                                  

      END CASE case_metrics_function_call;
exception 
when CASE_NOT_FOUND then
null;
end;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      commons_utils.p_error_logging(pi_metric_id    => 'WS_Metrics',
                                  pi_procedure_name => 'p_load_SQS_wrapper',
                                  pi_error_message  => 'In  When others (last) of load of SQS wrapper' || SQLERRM || SQLCODE,
                                  pi_error_in_code  => SQLERRM || SQLCODE,
                                  pi_tel_error_event_date => pin_processing_date);
      RAISE;
END p_load_SQS_wrapper;


PROCEDURE p_SQS_metrics_wrapper(P_check_flag varchar2 default 'N') is
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Master Wrapper procedure that is invoked from scheduler
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    lv_processing_date date;
    lv_bad_file_seq pls_integer;
    lv_attach_string_to_filename varchar2(4001);
    lv_mail_flag varchar2(4001);
    lv_ocm_flag  varchar2(4001);
    lv_check_flag varchar2(1);
    lv_loader_seq_val number;
    
  begin
    lv_check_flag :=P_check_flag;
    IF lv_check_flag='Y'
    then
      p_set_context_new_loader_seq;   ---- setting context gc_loader_seq_cur_val
    end if;
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_val from dual; 
  
    lv_bad_file_seq:=lv_loader_seq_val;                   ----- enhancement for timely mail alert OF-87697
/*    
    --- Making the MV blank
    IF lv_bad_file_seq = 1 THEN
    COMMONS_UTILS.P_UPDATE_MVIEW_STATUS(lv_bad_file_seq);
    FOR I IN (SELECT *
                FROM CONFIG_MATERIALIZED_VIEWS C
               WHERE C.CMV_REFRESH_STATUS IN ('N')) LOOP
        DBMS_MVIEW.REFRESH(I.CMV_MV_NAME);
    end loop;
    END IF;

    BEGIN
    p_table_ocm_sync_insert (pi_processing_date=>(gv_processing_date+1));
    select TOC_FLAG into lv_ocm_flag from table_ocm_sync where TOC_EVENT_DATE=gv_processing_date+1;
      if lv_ocm_flag='N' then
          Delete from config_environments_ocm;
          Delete from config_farms_ocm;
          Delete from config_client_projects_ocm;-- temporary commnt until FETCH CALL OF OCM is not in place
          COMMIT;
          --Merge master config tables from _ocm staging tables that are fetched via ocm_sync_job 
          p_config_tables_merge_ocm (pin_processing_date=>(gv_processing_date+1) );
      END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
           commons_utils.p_telemetry_info_logging(  pi_procedure_name       => 'p_SQS_metrics_wrapper',pi_description =>'Error in p_table_ocm_sync_insert/p_config_tables_merge_ocm : '|| SQLERRM|| 'Backtraced : ' || commons_utils.f_get_exception_backtrace );
    end;
  */
  
  ------- SQS metrics
       Begin
          execute immediate ' alter session set nls_date_format = ''dd-mon-yy''';
       --p_fetch_SQS_metrics_wrapper(gv_processing_date,pi_attach_string_to_filenam => 'DW_INPUT'); -- ADD lv_attach_string_to_filename for determining the input string for prod or testing
         p_load_SQS_wrapper(gv_processing_date);
       EXCEPTION
          WHEN OTHERS THEN
           commons_utils.p_telemetry_info_logging(  pi_procedure_name       => 'p_SQS_metrics_wrapper',pi_description =>'Error in p_SQS_PR_metrics_wrapper/p_load_SQS_wrapper : '|| SQLERRM|| 'Backtraced : ' || commons_utils.f_get_exception_backtrace );
        end;
  
  /*   
     ---- MV refresh call
    Begin
      p_mview_refresh(lv_bad_file_seq);
    EXCEPTION
      WHEN OTHERS THEN
           commons_utils.p_telemetry_info_logging(  pi_procedure_name       => 'p_SQS_metrics_wrapper',pi_description =>'Error in p_mview_refresh : '|| SQLERRM|| 'Backtraced : ' || commons_utils.f_get_exception_backtrace );
    end;

     select PR_VALUE into lv_mail_flag from properties WHERE PR_ID=4 ;
     if lv_mail_flag ='Y'
       then
     commons_utils.p_send_alert_email(pin_processing_date=> gv_processing_date,pin_load_current_iteration=>lv_bad_file_seq);
     end if;
*/     
    -- commit;
    EXCEPTION
      WHEN OTHERS THEN
        commons_utils.p_error_logging(pi_metric_id    => 'p_SQS_metrics_wrapper',
                                    pi_procedure_name => 'p_SQS_metrics_wrapper',
                                    pi_error_message  => 'In  When others (last) of p_SQS_metrics_wrapper'|| ' Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                    pi_error_in_code  => SQLERRM || SQLCODE,
                                    pi_tel_error_event_date => gv_processing_date);
        RAISE;
  END p_SQS_metrics_wrapper;

begin
 
    -- selecting the new Logging path from properties table
    SELECT pr_value
      INTO gv_loggingroot
      FROM properties
     WHERE pr_name = 'New_logging_path';
     
    --SELECT TRUNC(SYSDATE-1) 
    SELECT to_date('04-01-2019','dd-mm-yyyy') 
     INTO gv_processing_date 
     FROM dual ;

end commons_utils_new;
/

