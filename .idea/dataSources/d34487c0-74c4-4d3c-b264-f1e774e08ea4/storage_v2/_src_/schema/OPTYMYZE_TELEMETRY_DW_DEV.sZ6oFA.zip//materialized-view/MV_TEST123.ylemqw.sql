create materialized view MV_TEST123
refresh force on demand
  as
    SELECT * FROM TEST123
/

