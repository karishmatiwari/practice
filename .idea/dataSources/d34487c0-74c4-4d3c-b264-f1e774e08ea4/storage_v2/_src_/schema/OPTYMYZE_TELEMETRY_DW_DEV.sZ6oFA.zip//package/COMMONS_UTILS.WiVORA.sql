create PACKAGE commons_utils AS
-- -----------------------------------------------------------------------------
  -- Copyright (c) 2016 - 2017 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product        : Client Analytics Portal
  -- Module         : Client Analytics Portal
  -- First version Requester/s  : Pimparkar Shriniket,Gaurav Rajput
  -- First version author/s : Gaurav Rajput 
  -- First Create date    : 20160915
  -- First version Reviewer       : -- 
  -- First version Review date    : --
  -- Description    : Package used to handle all operations for Client Analytics Portal

  -- Change author      :
  -- Change date        :
  -- Change reviewer    :
  -- Change review date :
  -- Change description :
  -- ---------------------------------------------------------------------------
  
  -- *******************************    PUBLIC TYPES CONSTANTS EXCEPTIONS START       *******************************
  
     type ty_config_data_centers is table of config_data_centers%rowtype index by binary_integer;
     c_distribution_list constant pls_integer  :=1 ;
     c_receipient_list  constant pls_integer  :=2 ;
     c_both_list  constant pls_integer  :=3 ;
     c_max_run_duration constant pls_integer  :=0 ;
  
    SUBTYPE maxvarchar2 IS VARCHAR2(32767);
    SUBTYPE optimizedvarchar2 IS VARCHAR2(4001);
    gv_root optimizedvarchar2;  
    gv_new_root optimizedvarchar2;  
    gv_loggingroot optimizedvarchar2;     
    gv_processing_date date;   ---- OF-80673
    c_mv_monthly_ref_tryout_days constant pls_integer  :=3 ;  ---- OF-87954

    c_ex_directory_missing constant pls_integer := -20010;
    c_str_directory_missing  optimizedvarchar2 := 'No Such Directory';
    ex_directory_missing EXCEPTION;
    PRAGMA EXCEPTION_INIT(ex_directory_missing, -20010);

    c_ex_file_missing constant  pls_integer := -20011;
    c_str_file_missing optimizedvarchar2 := 'Csv File Missing';
    ex_file_missing EXCEPTION;
    PRAGMA EXCEPTION_INIT(ex_file_missing, -20011);

    c_ex_bad_file_exists  constant pls_integer := -20012;
    c_str_bad_file optimizedvarchar2 := 'Bad File Generated';
    ex_bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(ex_bad_file_exists, -20012);

    c_ex_file_empty constant pls_integer     := -20013;
    c_str_file_empty optimizedvarchar2 := 'Csv File Empty';
    ex_file_empty EXCEPTION;
    PRAGMA EXCEPTION_INIT(ex_file_empty, -20013);
    c_invalid_entry constant PLS_INTEGER  := -20014;
    ex_invalid_entry EXCEPTION;
    PRAGMA EXCEPTION_INIT(ex_invalid_entry, -20014);
    c_merge_failed  constant PLS_INTEGER  := -20014;
    ex_merge_failed EXCEPTION;
    PRAGMA EXCEPTION_INIT(ex_merge_failed, -20015);
    
    c_ex_mv_refresh_alert  constant pls_integer := -20016;
    c_str_mv_refresh_alert optimizedvarchar2 := 'MV refresh failed';
    ex_mv_refresh_alert EXCEPTION;
    PRAGMA EXCEPTION_INIT(ex_mv_refresh_alert, -20016);

    
    c_ex_database_load constant pls_integer     := -20019;
    c_str_database_load optimizedvarchar2 := 'Database load exceeded';
    
    
    c_ex_Json_mismatch constant pls_integer     := -20017;
    c_str_Json_mismatch optimizedvarchar2 := 'Json attributes mismatch';
    
    c_logging_enable constant pls_integer := 0;
    c_logging_disable constant pls_integer := 1;
    

-- *******************************    PUBLIC TYPES CONSTANTS EXCEPTIONS END       *******************************

-- *******************************    PUBLIC FUNCTIONS  START     *******************************
  FUNCTION f_create_directory(fi_path        IN VARCHAR2,
                              fi_metric_name IN VARCHAR2)
                              RETURN VARCHAR2;
                              
  FUNCTION f_get_metric_file_name(fi_flag        IN NUMBER,
                                  fi_metric_name IN VARCHAR2,
                                  fi_date        IN DATE,
                                  fi_start_time  IN VARCHAR2,
                                  fi_end_time    IN VARCHAR2) RETURN VARCHAR2;
                                  
  Function  f_get_exception_backtrace return varchar2;                                
                                
-- *******************************    PUBLIC FUNCTIONS  END       *******************************


-- *******************************    PUBLIC PROCEDURES  START       *******************************

    PROCEDURE p_load_metric(pi_file_date IN DATE ,
                            pi_metric_id IN VARCHAR2,
                            pi_extra_derived_cols_val   VARCHAR2,
                            pi_attach_string_to_filenam VARCHAR2 DEFAULT 'TESTING',
                            Pi_Merge_insert_flag IN VARCHAR2 DEFAULT 'N');
    
    PROCEDURE p_send_alert_email(pin_processing_date IN date,pin_load_current_iteration pls_integer);
    PROCEDURE p_get_filename( pi_directory IN VARCHAR2, pi_filename VARCHAR2);
    PROCEDURE p_alter_external_table( pi_ext_table_name IN varchar2,
                                      pi_csv_file_name  IN varchar2,
                                      pi_bad_file_name  IN varchar2,
                                      pi_access_parameter_col_list  IN VARCHAR2,
                                      pi_field_delimiter            IN VARCHAR2
                                      
       );
    
    PROCEDURE p_replace_directory(pi_path        IN VARCHAR2,
                                  pi_directory_name IN VARCHAR2) ;
    
    PROCEDURE p_fetch_metric_details(pi_root                       IN VARCHAR2,
                                     pi_file_date                  IN DATE,
                                     pi_metric_id                  IN CONFIG_METRICS.metric_id%TYPE,
                                     pi_data_center_id             IN VARCHAR2,
                                     pi_loader_seq_currval         IN NUMBER,
                                     pi_attach_string_to_filenam   IN VARCHAR2,
                                     po_metric_table_name          OUT CONFIG_METRICS.metric_table_name%TYPE,
                                     po_view_name                  OUT CONFIG_METRICS.metric_view_name%TYPE,
                                     po_metric_input_file_path     OUT VARCHAR2,
                                     po_external_tab_column_list   OUT VARCHAR2,
                                     po_staging_tab_column_list    OUT VARCHAR2,
                                     po_access_parameter_col_list  OUT varchar2,
                                     po_ext_tab_col_nam_datatype   OUT VARCHAR2,
                                     po_staging_tab_col_nam_datatyp   OUT VARCHAR2,
                                     po_metric_source_id           OUT CONFIG_METRICS.metric_source_id%TYPE,
                                     po_csv_file_name              OUT varchar2 ,
                                     po_bad_file_name              OUT varchar2,
                                     po_metric_external_table_nam  OUT varchar2,
                                     po_metric_name                OUT CONFIG_METRICS.metric_name%TYPE,
                                     po_metric_default_dir_name OUT config_metrics.metric_default_directory_name%type,
                                     po_field_delimiter           OUT varchar2
                                   );

  PROCEDURE p_create_external_table(pi_metric_id IN config_metrics.metric_id%type ,
                                    pi_file_date IN DATE,
                                    pi_attach_string_to_filenam VARCHAR DEFAULT 'TESTING',
                                    pi_is_create_required IN pls_integer DEFAULT 1);
  --procedure p_merge_config_environmnt_http (pi_processing_date date);
  
  
  procedure p_config_tables_merge_ocm (pin_processing_date  in date, PIN_ITERATION_NUMBER IN NUMBER);   -- 4 TIMES OCM SYNC
  procedure p_read_write_config( pi_read_write_action in number,pi_config_table in varchar2, pi_exe_proc_name     IN VARCHAR2);
PROCEDURE p_time_logging(pi_metric_farm_id  number,
                          pi_metric_env_id number,
                          pi_metric_name VARCHAR2,
                          pi_metric_source_id NUMBER,
                          pi_start_time TIMESTAMP);

  PROCEDURE p_error_logging(pi_metric_id    IN VARCHAR2,
                            pi_procedure_name IN VARCHAR2,
                            pi_error_message  IN VARCHAR2,
                            pi_error_in_code  IN VARCHAR2,
                            pi_tel_error_event_date IN DATE,
                            pi_env_id IN VARCHAR2 DEFAULT NULL);

  PROCEDURE p_telemetry_info_logging(  pi_procedure_name        IN VARCHAR2,
                                       pi_description CLOB ) ;
                                       
  PROCEDURE p_get_metric_details(pi_root                       IN VARCHAR2,
                                 pi_file_date                  IN DATE,
                                 pi_v_metric_name              IN VARCHAR2,
                                 pi_data_center_id             NUMBER,
                                 po_v_metric_table_name        OUT VARCHAR2,
                                 po_v_view_name                OUT VARCHAR2,
                                 po_v_metric_input_file_format OUT VARCHAR2,
                                 po_v_metric_input_file_path   OUT VARCHAR2,
                                 po_v_column_list              OUT VARCHAR2,
                                 po_v_column_list_date         OUT CLOB,
                                 po_v_column_datatype_list     OUT VARCHAR2,
                                 po_v_metric_source_id         OUT NUMBER);


  PROCEDURE p_merge_config_tables(pi_farm_id                    IN config_farms.farm_id%TYPE,
                                  pi_data_center_id             IN config_data_centers.data_center_id%TYPE,
                                  pi_data_center_name           IN config_data_centers.data_center_name%TYPE,
                                  pi_data_center_ocm_url        IN config_data_centers.data_center_ocm_url%TYPE DEFAULT NULL,
                                  pi_data_center_flag           IN config_data_centers.data_center_flag%TYPE,
                                  pi_data_centre_graphite_cnnct IN config_data_centers.data_centre_graphite_connect%TYPE DEFAULT NULL,
                                  pi_farm_name                  IN config_farms.farm_name%TYPE DEFAULT NULL,
                                  pi_farm_application_url       IN config_farms.farm_application_url%TYPE,
                                  pi_cp_id                      IN config_client_projects.cp_id%TYPE,
                                  pi_cp_client_nm               IN config_client_projects.cp_client_name%TYPE DEFAULT NULL,
                                  pi_cp_client_id               IN config_client_projects.cp_client_id%TYPE,
                                  pi_envi_uuid                  IN config_environments.env_uuid%TYPE,
                                  pi_envi_id                    IN config_environments.env_id%TYPE,
                                  pi_env_type_id                IN config_environments.env_env_type_id%TYPE,
                                  pi_envi_name                  IN config_environments.env_name%TYPE,
                                  pi_status                     IN config_environments.status%TYPE,
                                  pi_config_table               IN VARCHAR2,
                                  pi_skip_alter_flag            IN VARCHAR2 default 'N',
                                  pi_processing_date            IN DATE,
                                  pi_env_version                IN config_environments.env_version%TYPE,   -- ENV_VERSION
                                  pi_spm_server                 IN VARCHAR2 DEFAULT NULL,
                                  pi_pla_sever                  IN VARCHAR2 DEFAULT NULL,
                                  pi_commission_status          IN VARCHAR2 DEFAULT NULL,
                                  po_insert_status              OUT NUMBER);

PROCEDURE p_bad_rec_insert_wrapper(PI_CONFIG_TABLE                IN VARCHAR2,
                                     PI_DATA_CENTER_ID              IN CONFIG_DATA_CENTERS.DATA_CENTER_ID%TYPE,
                                     PI_DATA_CENTER_NAME            IN CONFIG_DATA_CENTERS.DATA_CENTER_NAME%TYPE DEFAULT NULL,
                                     PI_DATA_CENTER_OCM_URL         IN CONFIG_DATA_CENTERS.DATA_CENTER_OCM_URL%TYPE DEFAULT NULL,
                                     PI_DATA_CENTER_FLAG            IN CONFIG_DATA_CENTERS.DATA_CENTER_FLAG%TYPE DEFAULT NULL,
                                     PI_DATA_CENTRE_GRAPHITE_CONECT IN CONFIG_DATA_CENTERS.DATA_CENTRE_GRAPHITE_CONNECT%TYPE  DEFAULT NULL,
                                     PI_FARM_ID                     IN CONFIG_FARMS.FARM_ID%TYPE ,
                                     PI_FARM_NAME                   IN CONFIG_FARMS.FARM_NAME%TYPE  DEFAULT NULL,
                                     PI_FARM_APPLICATION_URL        IN CONFIG_FARMS.FARM_APPLICATION_URL%TYPE,
                                     PI_CP_ID                       IN CONFIG_CLIENT_PROJECTS.CP_ID%TYPE,
                                     PI_CP_CLIENT_NAME              IN CONFIG_CLIENT_PROJECTS.CP_CLIENT_NAME%TYPE  DEFAULT NULL,
                                     PI_CP_CLIENT_ID                IN CONFIG_CLIENT_PROJECTS.CP_CLIENT_ID%TYPE,
                                     PI_ENVI_UUID                   IN CONFIG_ENVIRONMENTS.ENV_UUID%TYPE,
                                     PI_ENVI_ID                     IN CONFIG_ENVIRONMENTS.ENV_ID%TYPE,
                                     PI_ENV_TYPE_ID                 IN CONFIG_ENVIRONMENTS.ENV_ENV_TYPE_ID%TYPE,
                                     PI_ENVI_NAME                   IN CONFIG_ENVIRONMENTS.ENV_NAME%TYPE,
                                     PI_STATUS                      IN CONFIG_ENVIRONMENTS.STATUS%TYPE,
                                     PI_METRIC_ID                   IN VARCHAR2,
                                     PI_PROCEDURE_NAME              IN VARCHAR2,
                                     PI_ERROR_MESSAGE               IN VARCHAR2,
                                     pi_spm_server                 IN VARCHAR2 DEFAULT NULL,
                                     pi_pla_sever                  IN VARCHAR2 DEFAULT NULL,
                                     pi_commission_status          IN VARCHAR2 DEFAULT NULL,
                                     PO_INSERT_STATUS OUT NUMBER);


PROCEDURE p_config_bad_rec_insert(pi_farm_id                    IN config_farms.farm_id%TYPE,
                                  pi_data_center_id             IN config_data_centers.data_center_id%TYPE,
                                  pi_data_center_name           IN config_data_centers.data_center_name%TYPE,
                                  pi_data_center_ocm_url        IN config_data_centers.data_center_ocm_url%TYPE DEFAULT NULL,
                                  pi_data_center_flag           IN config_data_centers.data_center_flag%TYPE,
                                  pi_data_centre_grapht_cnnct   IN config_data_centers.data_centre_graphite_connect%TYPE DEFAULT NULL,
                                  pi_farm_name                  IN config_farms.farm_name%TYPE DEFAULT NULL,
                                  pi_farm_application_url       IN config_farms.farm_application_url%TYPE,
                                  pi_cp_id                      IN config_client_projects.cp_id%TYPE,
                                  pi_cp_client_nm               IN config_client_projects.cp_client_name%TYPE DEFAULT NULL,
                                  pi_cp_client_id               IN config_client_projects.cp_client_id%TYPE,
                                  pi_envi_uuid                  IN config_environments.env_uuid%TYPE,
                                  pi_envi_id                    IN config_environments.env_id%TYPE,
                                  PI_ENV_TYPE_ID                IN config_environments.env_env_type_id%TYPE,
                                  pi_envi_name                  IN config_environments.env_name%TYPE,
                                  pi_status                     IN config_environments.status%TYPE,
                                  pi_error_message              IN VARCHAR2,
                                  pi_config_table               IN VARCHAR2,
                                  pi_spm_server                 IN VARCHAR2 DEFAULT NULL,
                                  pi_pla_sever                  IN VARCHAR2 DEFAULT NULL,
                                  pi_commission_status          IN VARCHAR2 DEFAULT NULL,
                                  po_insert_status              OUT NUMBER);

  PROCEDURE p_delete_config_tables(pi_envi_uuid      IN config_environments.env_uuid%TYPE,
                                   pi_cp_id          IN config_client_projects.cp_id%TYPE,
                                   pi_data_center_id IN config_data_centers.data_center_id%TYPE,
                                   pi_farm_id        IN config_farms.farm_id%TYPE,
                                   pi_config_table   IN VARCHAR2,
                                   po_row_count      OUT NUMBER);


  PROCEDURE p_create_external_table(pi_column_datatype_list IN VARCHAR2,
                                    pi_directory_name       IN VARCHAR2,
                                    pi_file_name            IN VARCHAR2,
                                    pi_ext_tab_source_flag  IN NUMBER,
                                    pi_fields_list          IN VARCHAR2,
                                    pi_metric_name          IN VARCHAR2,
                                    pi_file_date            IN DATE,
                                    pi_data_center          IN VARCHAR2,
                                    po_external_table_name  OUT VARCHAR2
                                    ) ;
  PROCEDURE p_drop_external_table(pi_table_name IN VARCHAR2);

  
  PROCEDURE p_drop_directory(pi_directory_name IN VARCHAR2);

  PROCEDURE p_get_dir_list(p_directory IN VARCHAR2);

  PROCEDURE p_job_creation;
  PROCEDURE p_job_deletion;
  PROCEDURE p_job_delete_app_met_fol_del;
  PROCEDURE p_job_create_app_met_fol_del;

  PROCEDURE p_job_cr_Logging_bad_file_del;
  PROCEDURE p_job_del_Logging_bad_file_del;
  
  PROCEDURE p_job_OS_Log_bad_file_del;
  PROCEDURE p_job_OS_Log_bad_file_cr;
  
  PROCEDURE p_load_metrics_wrapper(P_check_flag varchar2 default 'N');  ----  enhancement for timely mail alert

  PROCEDURE refresh_mviews;
  PROCEDURE p_load_phs_metrics_for_dates(pin_from_date date,pin_to_date date) ;
  PROCEDURE p_load_os_metrics_for_dates(pin_from_date date,pin_to_date date) ;
  PROCEDURE p_load_app_metrics_for_dates(pin_from_date date,pin_to_date date,pin_root varchar2) ;

  PROCEDURE p_load_phs_reports_wrapper(pin_processing_date date) ;
  PROCEDURE p_load_OS_reports_wrapper(pin_processing_date date) ;
  PROCEDURE p_fetch_app_metrics_wrapper(pin_processing_date in date, pi_attach_string_to_filenam in varchar2 default 'TEST' );
  PROCEDURE p_load_app_metrics_wrapper(pin_processing_date in date);

  PROCEDURE p_fetch_ws_metrics_wrapper(pin_processing_date in date, pi_attach_string_to_filenam in varchar2 default 'TEST' );
   PROCEDURE p_fetch_PR_metrics_wrapper(pin_processing_date in date, pi_attach_string_to_filenam in varchar2 default 'TEST' ) ;
  PROCEDURE p_load_ws_wrapper(pin_processing_date in date);

 PROCEDURE p_load_PR_wrapper(pin_processing_date date) ;
  PROCEDURE p_load_ws_metrics_for_dates(pin_from_date date,pin_to_date date);

  procedure p_geo_location_insert ;                                     
  procedure p_set_context_geo_location(pin_last_run_date date default gv_processing_date-1 );
  procedure p_set_context_loader_seq(pin_loader_seq pls_integer default loader_seq.nextval );
  procedure p_set_context_logging(pin_logging pls_integer default commons_utils.c_logging_disable) ;

  procedure p_mview_refresh(P_ITERATION_NUMBER NUMBER);
  
  PROCEDURE p_create_metric_tables(pi_metric_id IN config_metrics.metric_id%type);
  PROCEDURE p_insert_table_load_metrics(pin_processing_date IN DATE,pin_metric_string IN varchar2) ;
  PROCEDURE p_update_mview_status(P_ITERATION_NUMBER NUMBER) ;
                                         
-- *******************************    PUBLIC PROCEDURES  END       *******************************

-- *******************************    PUBLIC PROCEDURES ONE TIME SETUP REQUIRED IF DB MIGRATED START       *******************************
  procedure p_create_contexts ;
-- *******************************    PUBLIC PROCEDURES ONE TIME SETUP REQUIRED IF DB MIGRATED END       *******************************

END commons_utils;
/

