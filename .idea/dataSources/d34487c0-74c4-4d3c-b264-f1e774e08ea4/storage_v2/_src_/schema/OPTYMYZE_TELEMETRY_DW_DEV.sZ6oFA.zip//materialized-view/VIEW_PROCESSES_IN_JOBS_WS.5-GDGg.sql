create materialized view VIEW_PROCESSES_IN_JOBS_WS
refresh force on demand
  as
    SELECT CE.ENV_UUID ENVIRONMENT_UUID,
  CE.ENV_ID ENVIRONMENT_ID,
  CE.ENV_NAME ENVIRONMENT_NAME,
  cdc.data_center_name,
  CCP.CP_ID CLIENT_PROJECT_ID,
  CCP.CP_CLIENT_ID CLIENT_ID,
  TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
  ccp.cp_client_name client_name,
  CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
  trunc(sysdate-1) METRIC_DATE,
  TRIM(TO_CHAR(trunc(sysdate-1), 'Month'))
  ||' '
  ||TO_CHAR(trunc(sysdate-1), 'YYYY') metric_month,
  JP.JOB_ID,
  JP.JOB_NAME,
  JP.FOLDER,
  JP.PROCESS_NAME,
  JP.PROCESS_TYPE,
  JP.DATE_CREATED,
  ro.login_id CREATED_BY,
  JP.DATE_OF_LAST_RUN,
  JS.SCHEDULE_ID,
  JS.SCHEDULE_NAME,
  JS.SCHEDULE_FREQUENCY
FROM TABLE_PROCESSES_IN_JOBS_WS JP
JOIN CONFIG_ENVIRONMENTS CE
ON TRIM(JP.ENV_UUID)    = TRIM(CE.ENV_UUID)
JOIN CONFIG_CLIENT_PROJECTS CCP
ON (CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
JOIN config_data_centers cdc
ON ce.env_data_center_id = cdc.data_center_id
JOIN CONFIG_ENVIRONMENT_TYPES CET
ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
LEFT OUTER JOIN TABLE_JOBS_SCHEDULES_WS JS
ON JP.JOB_ID=JS.JOB_ID
left outer join table_role_wise_user_ws ro
on to_char(ro.user_id)=jp.CREATED_BY
and trunc(ro.event_time)=TRUNC(jp.event_time)
and ro.env_uuid=jp.env_uuid
WHERE TRUNC(JP.event_time) = trunc(sysdate-1)
AND CE.STATUS='Y' and CCP.CP_IS_DELETED=0
and JP.Supported=0
/

