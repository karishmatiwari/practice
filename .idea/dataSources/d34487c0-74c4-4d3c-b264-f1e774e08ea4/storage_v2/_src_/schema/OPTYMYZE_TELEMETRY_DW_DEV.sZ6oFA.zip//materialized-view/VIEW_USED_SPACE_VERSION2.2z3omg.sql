create materialized view VIEW_USED_SPACE_VERSION2
refresh complete on demand
  as
    select
A.ENVIRONMENT_UUID,ENVIRONMENT_ID,ENVIRONMENT_NAME,DATA_CENTER_NAME,CLIENT_PROJECT_ID,CLIENT_ID,SUB_PROJECT_ID,CLIENT_NAME,ENVIRONMENT_TYPE,METRIC_DATE,METRIC_MONTH,DB_TOTAL_ALLOCATED_SPACE,DB_USED_SIZE,PROJECT_FILE_ALLOCATED_SPACE,PROJECT_FILE_USED_SIZE,PROJECT_FILE_FREE_SIZE,CONTRACTUAL_SPACE,BILLABLE_SPACE
from
(SELECT
  tus.PROJECT_UUID ENVIRONMENT_UUID,
  CE.ENV_ID ENVIRONMENT_ID,
  CE.ENV_NAME ENVIRONMENT_NAME,
  CDC.DATA_CENTER_NAME DATA_CENTER_NAME,
  CCP.CP_ID CLIENT_PROJECT_ID,
  TO_CHAR(CCP.CP_CLIENT_ID) CLIENT_ID,
  CCP.CP_SUB_PROJECT_ID SUB_PROJECT_ID,
  ccp.cp_client_name client_name,
  CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
  TO_CHAR(to_date(dates_between.last_date, 'DD-MM-YYYY')) METRIC_DATE,
  TRIM(TO_CHAR(dates_between.last_date, 'Month'))||chr(32)||TO_CHAR(dates_between.last_date, 'YYYY') METRIC_MONTH,
  round(avg(tus.db_total_allocated_space),2) db_total_allocated_space,
  round(avg(tus.project_file_allocated_space),2) project_file_allocated_space,
  round(avg(tus.project_file_used_size),2) project_file_used_size,
  round(avg(tus.project_file_free_size),2) project_file_free_size,
  round(avg(tus.contractual_space),2) contractual_space
FROM TABLE_USED_SPACE tus
JOIN CONFIG_ENVIRONMENTS CE
ON (TRIM(tus.PROJECT_UUID) = TRIM(CE.ENV_UUID))
JOIN CONFIG_CLIENT_PROJECTS CCP
ON CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID
JOIN CONFIG_ENVIRONMENT_TYPES CET
ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
JOIN CONFIG_DATA_CENTERS CDC
ON CDC.DATA_CENTER_ID=CE.ENV_DATA_CENTER_ID
CROSS JOIN (  (SELECT last_day(add_months(TRUNC(sysdate), -2)) + 1 first_date,
    last_day(add_months(TRUNC(sysdate),       -1)) last_date
  FROM dual
  )) dates_between
WHERE TRUNC(event_date) between dates_between.first_date and  dates_between.last_date
AND CE.STATUS           ='Y' and CCP.CP_IS_DELETED=0
group by
tus.PROJECT_UUID ,
CE.ENV_ID,
CE.ENV_NAME,
CDC.DATA_CENTER_NAME,
CCP.CP_ID,
TO_CHAR(CCP.CP_CLIENT_ID) ,
CCP.CP_SUB_PROJECT_ID,
ccp.cp_client_name ,
CET.ENV_TYPE_VALUE,
TO_CHAR(to_date(dates_between.last_date, 'DD-MM-YYYY')) ,
TRIM(TO_CHAR(dates_between.last_date, 'Month'))  ||chr(32)  ||TO_CHAR(dates_between.last_date, 'YYYY')
) A  left outer join
  ( SELECT ENVIRONMENT_UUID, round(avg (a.DB_USED_SIZE),2) DB_USED_SIZE ,  round(avg(a.Billable_space),2) Billable_space,trunc(event_date) last_date  from
(
  SELECT res.ENVIRONMENT_UUID, round(avg (res.DB_USED_SIZE),2) DB_USED_SIZE ,  round(avg(res.Billable_space),2) Billable_space,trunc(last_day(event_date)) event_date
  from
      (SELECT ENV_UUID ENVIRONMENT_UUID,
            trunc(event_date) event_date ,
            sum(decode(substr(TDPV.TABLESPACE_NAME,-4,4), '_MTD', TDPV.NO_OF_BYTES_IN_TABLESPACE,'_DTS', TDPV.NO_OF_BYTES_IN_TABLESPACE, '_IND', TDPV.NO_OF_BYTES_IN_TABLESPACE,'_OUT', TDPV.NO_OF_BYTES_IN_TABLESPACE,0))/(1024*1024*1024) DB_USED_SIZE,
            sum(decode(substr(TDPV.TABLESPACE_NAME,-4,4), '_MTD', TDPV.NO_OF_BYTES_IN_TABLESPACE,'_DTS', TDPV.NO_OF_BYTES_IN_TABLESPACE, '_IND', TDPV.NO_OF_BYTES_IN_TABLESPACE,0))/(1024*1024*1024)  Billable_space
    --      sum(decode(substr(TABLESPACE_NAME,-3,3), 'OUT', -TDPV.NO_OF_BYTES_IN_TABLESPACE,TDPV.NO_OF_BYTES_IN_TABLESPACE))/(1024*1024*1024)  Billable_space_09
            FROM TABLE_DATA_PROCESSED_VOLUME TDPV JOIN CONFIG_ENVIRONMENTS CE
        ON (TRIM(TDPV.ENV_NAME) = TRIM(CE.ENV_NAME))
            where  TRUNC(event_date)  between last_day(add_months(TRUNC(sysdate), -2)) + 1 and  last_day(add_months(TRUNC(sysdate),-1))
            and decode(substr(TABLESPACE_NAME,-8,4), '_SPM',1,'_PAR',1,'_RDS',1,'_EDD',1,'_OA_',1,'_PLA',1,0) =1
            group by ENV_UUID,trunc(event_date)
      ) res
        group by res.ENVIRONMENT_UUID,trunc(last_day(event_date)) )a group by a.ENVIRONMENT_UUID,a.event_date) B
on (A.ENVIRONMENT_UUID = B.ENVIRONMENT_UUID and to_date(A.METRIC_DATE) = B.last_date )
/

