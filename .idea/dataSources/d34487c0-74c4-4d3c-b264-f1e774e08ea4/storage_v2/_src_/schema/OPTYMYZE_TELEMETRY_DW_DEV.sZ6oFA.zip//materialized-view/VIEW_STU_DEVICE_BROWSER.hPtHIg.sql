create materialized view VIEW_STU_DEVICE_BROWSER
refresh complete on demand
  as
    SELECT tus.ENVIRONMENT_UUID                               ENVIRONMENT_UUID,
       CE.ENV_ID                                       ENVIRONMENT_ID,
       CE.ENV_NAME                                     ENVIRONMENT_NAME,
       CDC.DATA_CENTER_NAME                            DATA_CENTER_NAME,
       CCP.CP_ID                                       CLIENT_PROJECT_ID,
       to_char(CCP.CP_CLIENT_ID)                                CLIENT_ID,
       to_char(CCP.CP_SUB_PROJECT_ID)                           SUB_PROJECT_ID,
       ccp.cp_client_name                              client_name,
       CET.ENV_TYPE_VALUE                              ENVIRONMENT_TYPE,
       METRIC_DATE,
       METRIC_MONTH,
       TUS.studio_page_type,
       tus.browser_name BROWSER_VERSION,
       REGEXP_SUBSTR(BROWSER_NAME,'[^0-9]*[:space]*') browser_name ,
       decode(tus.device_name,'Computer','Desktop',tus.device_name) device_name,
       tus.STUDIO_APP_LOAD_COUNT,
       tus.time_taken_to_load  avg_time_to_load
 FROM (
 SELECT TO_DATE(TO_CHAR( event_time ,'YYYY-MM-DD' ),'YYYY-MM-DD')  METRIC_DATE,TRIM(to_CHAR(event_time, 'Month')) ||' '||to_CHAR(event_time, 'YYYY') METRIC_MONTH,
 TRIM(ENVIRONMENT_UUID) ENVIRONMENT_UUID,
trim(PAGE_TYPE) studio_page_type,
trim(browser_name) browser_name,
trim(device_name) device_name,
avg(time_taken_to_load) time_taken_to_load,
 COUNT(*)  STUDIO_APP_LOAD_COUNT
 FROM Table_STUDIO_APP_TIME
 where trunc(event_time) = trunc(sysdate-1)
GROUP BY
TRIM(ENVIRONMENT_UUID),
trim(PAGE_TYPE),
trim(browser_name),
trim(device_name),
TO_DATE(TO_CHAR( event_time ,'YYYY-MM-DD' ),'YYYY-MM-DD')  ,TRIM(to_CHAR(event_time, 'Month')) ||' '||to_CHAR(event_time, 'YYYY')
 ) tus
  JOIN CONFIG_ENVIRONMENTS CE
    ON (TRIM(tus.ENVIRONMENT_UUID) = TRIM(CE.ENV_UUID))
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
     JOIN CONFIG_DATA_CENTERS CDC
    ON CDC.DATA_CENTER_ID=CE.ENV_DATA_CENTER_ID
    where  CE.STATUS='Y' and CCP.CP_IS_DELETED=0
/

