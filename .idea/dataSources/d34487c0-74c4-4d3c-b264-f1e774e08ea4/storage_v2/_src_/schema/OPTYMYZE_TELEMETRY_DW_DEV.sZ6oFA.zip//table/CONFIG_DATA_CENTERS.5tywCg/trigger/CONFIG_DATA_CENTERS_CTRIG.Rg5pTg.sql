create trigger CONFIG_DATA_CENTERS_CTRIG
  instead of insert or update of DATA_CENTER_ID, DATA_CENTER_FLAG
  on CONFIG_DATA_CENTERS
  for each row
COMPOUND TRIGGER
  lc_config_data_centers ty_config_data_centers;

   BEFORE EACH ROW IS
   BEGIN
       IF INSERTING
         then
             insert into  config_metric_data_centre_map cmdc 
             select cm.metric_id,:NEW.DATA_CENTER_ID,decode(:new.DATA_CENTER_FLAG,0,'N',1,'Y')
             from config_metrics cm 
             where (instr(lower(METRIC_INPUT_FILE_PATH),q'`/datacentre_check/`')) > 0;
       end if;
       
      if UPDATING  THEN
         UPDATE config_metric_data_centre_map
          SET DATA_CENTRE_ID  =TO_CHAR(:NEW.DATA_CENTER_ID) ,
            IS_ENABLED        = DECODE(coalesce(:new.DATA_CENTER_FLAG,:old.DATA_CENTER_FLAG),0,'N',1,'Y')
          WHERE DATA_CENTRE_ID=TO_CHAR(:OLD.DATA_CENTER_ID);
    
      END IF;
  END BEFORE EACH ROW; 

  AFTER STATEMENT IS
    BEGIN
        select obj_config_data_centers(DATA_CENTER_ID	,DATA_CENTER_NAME,DATA_CENTER_OCM_URL,DATA_CENTER_COMMENTS	,DATA_CENTER_FLAG,DATA_CENTRE_GRAPHITE_CONNECT)
        bulk collect into lc_config_data_centers
        from config_data_centers;
      
        merge into config_metric_data_centre_map cmdc using 
         (
         select cm.metric_id,'DATACENTRE_ALL' dc_id ,
         decode(coalesce((select '1' from table(lc_config_data_centers) tcdc where tcdc.DATA_CENTER_FLAG =1 and rownum =1 ),'0'),'1','Y','N') flg
         from config_metrics cm 
         where (instr(lower(METRIC_INPUT_FILE_PATH),q'`/datacentre_all/`')) > 0
         ) src
         on (cmdc.metric_id = src.metric_id and cmdc.DATA_CENTRE_ID = src.dc_id)
         when matched then
         update set IS_ENABLED = flg 
         when not matched then 
         insert (METRIC_ID,DATA_CENTRE_ID,IS_ENABLED) values(src.metric_id,src.dc_id,src.flg);

   END AFTER STATEMENT;  
END config_data_centers_Ctrig;

/

