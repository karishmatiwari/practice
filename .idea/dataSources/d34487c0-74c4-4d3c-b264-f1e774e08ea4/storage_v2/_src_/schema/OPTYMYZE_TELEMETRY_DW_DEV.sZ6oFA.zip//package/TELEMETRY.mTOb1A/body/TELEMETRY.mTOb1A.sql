create PACKAGE BODY telemetry AS

  
  PROCEDURE p_http_sessions(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_num_processed             PLS_INTEGER;
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := Upper('http_sessions');
    lv_proc_name   := Upper('p_http_sessions');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
    commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                       pi_file_date                  => pi_file_date,
                                       pi_v_metric_name              => lv_metric_name,
                                       pi_data_center_id             => null,
                                       po_v_metric_table_name        => lv_metric_table_name,
                                       po_v_view_name                => lv_view_name,
                                       po_v_metric_input_file_format => lv_metric_input_file_format,
                                       po_v_metric_input_file_path   => lv_metric_input_file_path,
                                       po_v_column_list              => lv_column_list,
                                       po_v_column_list_date         => lv_fields_list,
                                       po_v_column_datatype_list     => lv_column_datatype_list,
                                       po_v_metric_source_id         => lv_metric_source_id);

    --    --dbms_output.put_line(lv_column_datatype_list);
    --    --dbms_output.put_line(lv_directory_name);
    --    --dbms_output.put_line(lv_metric_source_id);
    --    --dbms_output.put_line(lv_metric_input_file_path);
    BEGIN
      commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE no_such_directory;
    END;

    BEGIN
      SELECT filename
        INTO lv_file_name
        FROM dir_list
       WHERE regexp_like(filename, 'http_sessions[_0-9-]*.csv$', 'i');

    EXCEPTION
      WHEN no_data_found THEN
        RAISE no_such_file;
      WHEN too_many_rows THEN

        SELECT MAX(filename)
          INTO lv_file_name
          FROM dir_list
         WHERE regexp_like(filename, 'http_sessions[_0-9-]*.csv$', 'i');

      WHEN OTHERS THEN
        RAISE;
    END;

    -- creating the directory on the specified path
    lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                          fi_metric_name => lv_metric_name);

    -- creating the external table with respect to the directory created

    commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                          pi_directory_name       => lv_directory_name,
                                          pi_file_name            => lv_file_name,
                                          pi_ext_tab_source_flag  => lv_metric_source_id,
                                          pi_fields_list          => lv_fields_list,
                                          pi_metric_name          => lv_metric_name,
                                          pi_file_date            => pi_file_date,
                                          pi_data_center          => 'Datacentre_All',
                                          po_external_table_name  => lv_external_table_name);

    -- insertion in the specified metric table
    lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date)
                                    select ' || lv_column_list || ', CURRENT_DATE
                                    from ' || lv_external_table_name;


    EXECUTE IMMEDIATE lv_insert_into_central_table;
    lv_num_processed := SQL%ROWCOUNT;

    commons_utils.p_get_dir_list(p_directory => lv_badroot);
    BEGIN
      SELECT count(*)
        INTO lv_badfile_cnt
        from dir_list
       where filename = 'http_sessions_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad';

    EXCEPTION
      WHEN OTHERS THEN
        RAISE;

    END;

    if lv_badfile_cnt > 0 then
      raise bad_file_exists;
    end if;

    -- clean the GTT
    DELETE FROM dir_list
     WHERE regexp_like(filename, 'http_sessions(*)', 'i');
    -- drop the external table
    commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
    -- drop the directory
    commons_utils.p_drop_directory(lv_directory_name);


  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO s_http_sessions;
      -- clean the GTT
      DELETE FROM dir_list
       WHERE regexp_like(filename, 'http_sessions(*)', 'i');
      -- drop the external table
      commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
      -- drop the directory
      commons_utils.p_drop_directory(lv_directory_name);
      
      IF SQLCODE = -20010 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20011 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20012 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Bad file http_sessions_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad' || ' was generated  for Datacentre_All on at the following path ' || lv_badroot,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSE
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Failed at p_http_sessions with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      END IF;
      RAISE;
  END p_http_sessions;


  PROCEDURE p_web_service_call(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_num_processed             PLS_INTEGER;
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN
    lv_metric_name := Upper('web_service_call');
    lv_proc_name   := Upper('p_web_service_call');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
    commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                       pi_file_date                  => pi_file_date,
                                       pi_v_metric_name              => lv_metric_name,
                                       pi_data_center_id             => null,
                                       po_v_metric_table_name        => lv_metric_table_name,
                                       po_v_view_name                => lv_view_name,
                                       po_v_metric_input_file_format => lv_metric_input_file_format,
                                       po_v_metric_input_file_path   => lv_metric_input_file_path,
                                       po_v_column_list              => lv_column_list,
                                       po_v_column_list_date         => lv_fields_list,
                                       po_v_column_datatype_list     => lv_column_datatype_list,
                                       po_v_metric_source_id         => lv_metric_source_id);

    BEGIN
      commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE no_such_directory;
    END;

    BEGIN
      SELECT filename
        INTO lv_file_name
        FROM dir_list
       WHERE regexp_like(filename, 'web_service_call[_0-9-]*.csv$', 'i');

    EXCEPTION
      WHEN no_data_found THEN
        RAISE no_such_file;
      WHEN too_many_rows THEN

        SELECT MAX(filename)
          INTO lv_file_name
          FROM dir_list
         WHERE regexp_like(filename, 'web_service_call[_0-9-]*.csv$', 'i');

      WHEN OTHERS THEN
        RAISE;
    END;

    -- creating the directory on the specified path
    lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                          fi_metric_name => lv_metric_name);

    -- creating the external table with respect to the directory created
    commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                          pi_directory_name       => lv_directory_name,
                                          pi_file_name            => lv_file_name,
                                          pi_ext_tab_source_flag  => lv_metric_source_id,
                                          pi_fields_list          => lv_fields_list,
                                          pi_metric_name          => lv_metric_name,
                                          pi_file_date            => pi_file_date,
                                          pi_data_center          => 'Datacentre_All',
                                          po_external_table_name  => lv_external_table_name);

    -- insertion in the specified metric table
    --    lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' ||lv_column_list ||', insert_date)
    --                                      select ' ||lv_column_list || ', CURRENT_DATE from ' ||lv_external_table_name;

    lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ',Sent_Received_flag,Number_of_records,Time_taken, insert_date)
                                     select ' || lv_column_list || ',DECODE(service_subtype,
                                                                            ''adjust'',1,
                                                                            ''read_records'',0,
                                                                            ''read_table_metadata'',0,
                                                                            ''read_tables_metadata'',0,
                                                                            ''create_user'',1,
                                                                            ''delete_user'',1,
                                                                            ''email_user'',1,
                                                                            ''disable_user'',1,
                                                                            ''enable_user'',1,''add_user'',1
                                                                            ),
                                                                            DECODE(service_subtype,
                                                                            ''adjust'',updated_records_count,
                                                                            ''read_records'',read_records_count,
                                                                            ''read_table_metadata'',NULL,
                                                                            ''read_tables_metadata'',NULL,
                                                                            ''create_user'',NULL,
                                                                            ''delete_user'',updated_records_count,
                                                                            ''email_user'',NULL,
                                                                            ''disable_user'',NULL,
                                                                            ''enable_user'',NULL,
                                                                            ''add_user'',updated_records_count),
                                                                            DURATION,
                                                                            CURRENT_DATE
                                     from ' || lv_external_table_name;

   -- --dbms_output.put_line(lv_insert_into_central_table);

    EXECUTE IMMEDIATE lv_insert_into_central_table;
    lv_num_processed := SQL%ROWCOUNT;
    ----dbms_output.put_line(lv_num_processed);

    commons_utils.p_get_dir_list(p_directory => lv_badroot);
    BEGIN
      SELECT count(*)
        INTO lv_badfile_cnt
        from dir_list
       where filename = 'web_service_call_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'||lv_loader_seq_currval || '.bad';

    EXCEPTION
      WHEN OTHERS THEN
        RAISE;
    END;

    if lv_badfile_cnt > 0 then
      raise bad_file_exists;
    end if;

    -- clean the GTT
    DELETE FROM dir_list
     WHERE regexp_like(filename, 'web_service_call(*)', 'i');
    -- drop the external table
    commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
    -- drop the directory
    commons_utils.p_drop_directory(lv_directory_name);

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO s_web_service_call;
      -- clean the GTT
      DELETE FROM dir_list
       WHERE regexp_like(filename, 'web_service_call(*)', 'i');
      -- drop the external table
      commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
      -- drop the directory
      commons_utils.p_drop_directory(lv_directory_name);

      IF SQLCODE = -20010 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20011 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20012 THEN
        commons_utils.p_error_logging(pi_metric_id                => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Bad file web_service_call_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'||lv_loader_seq_currval || '.bad' ||' was generated for Datacentre_All on at the following path ' ||lv_badroot,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSE
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Failed at p_web_service_call with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      END IF;
      RAISE;
  END p_web_service_call;



  PROCEDURE p_login_sessions(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_num_processed             PLS_INTEGER;
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := Upper('login_sessions');
    lv_proc_name   := Upper('p_login_sessions');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
    commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                       pi_file_date                  => pi_file_date,
                                       pi_v_metric_name              => lv_metric_name,
                                       pi_data_center_id             => null,
                                       po_v_metric_table_name        => lv_metric_table_name,
                                       po_v_view_name                => lv_view_name,
                                       po_v_metric_input_file_format => lv_metric_input_file_format,
                                       po_v_metric_input_file_path   => lv_metric_input_file_path,
                                       po_v_column_list              => lv_column_list,
                                       po_v_column_list_date         => lv_fields_list,
                                       po_v_column_datatype_list     => lv_column_datatype_list,
                                       po_v_metric_source_id         => lv_metric_source_id);

    --    --dbms_output.put_line(lv_column_datatype_list);
    --    --dbms_output.put_line(lv_directory_name);
    --    --dbms_output.put_line(lv_metric_source_id);
    --    --dbms_output.put_line(lv_metric_input_file_path);
    BEGIN
      commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE no_such_directory;
    END;

    BEGIN
      SELECT filename
        INTO lv_file_name
        FROM dir_list
       WHERE regexp_like(filename, 'login_sessions[_0-9-]*.csv$', 'i');

    EXCEPTION
      WHEN no_data_found THEN
        RAISE no_such_file;
      WHEN too_many_rows THEN

        SELECT MAX(filename)
          INTO lv_file_name
          FROM dir_list
         WHERE regexp_like(filename, 'login_sessions[_0-9-]*.csv$', 'i');

      WHEN OTHERS THEN
        RAISE;
    END;

    -- creating the directory on the specified path
    lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                              fi_metric_name => lv_metric_name);

    -- creating the external table with respect to the directory created

    commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                          pi_directory_name       => lv_directory_name,
                                          pi_file_name            => lv_file_name,
                                          pi_ext_tab_source_flag  => lv_metric_source_id,
                                          pi_fields_list          => lv_fields_list,
                                          pi_metric_name          => lv_metric_name,
                                          pi_file_date            => pi_file_date,
                                          pi_data_center          => 'Datacentre_All',
                                          po_external_table_name  => lv_external_table_name);
    -- insertion in the specified metric table
    lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date)
                                     select ' || lv_column_list || ', CURRENT_DATE
                                     from ' || lv_external_table_name;

    EXECUTE IMMEDIATE lv_insert_into_central_table;
    lv_num_processed := SQL%ROWCOUNT;

    commons_utils.p_get_dir_list(p_directory => lv_badroot);
    BEGIN
      SELECT count(*)
        INTO lv_badfile_cnt
        from dir_list
       where filename = 'login_sessions_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad';

    EXCEPTION
      WHEN OTHERS THEN
        RAISE;
    END;

    if lv_badfile_cnt > 0 then
      raise bad_file_exists;
    end if;

    -- clean the GTT
    DELETE FROM dir_list
     WHERE regexp_like(filename, 'login_sessions(*)', 'i');
    -- drop the external table
    commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
    -- drop the directory
    commons_utils.p_drop_directory(lv_directory_name);

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO s_login_sessions;
      -- clean the GTT
      DELETE FROM dir_list
       WHERE regexp_like(filename, 'login_sessions(*)', 'i');
      -- drop the external table
      commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
      -- drop the directory
      commons_utils.p_drop_directory(lv_directory_name);

      IF SQLCODE = -20010 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20011 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20012 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Bad file login_sessions_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad' || ' was generated for Datacentre_All on at the following path ' || lv_badroot,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSE
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Failed at p_login_sessions with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      END IF;
      RAISE;
  END p_login_sessions;

  PROCEDURE p_email_count(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_num_processed             PLS_INTEGER;
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := Upper('email_count');
    lv_proc_name   := Upper('p_email_count');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
    commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                       pi_file_date                  => pi_file_date,
                                       pi_v_metric_name              => lv_metric_name,
                                       pi_data_center_id             => null,
                                       po_v_metric_table_name        => lv_metric_table_name,
                                       po_v_view_name                => lv_view_name,
                                       po_v_metric_input_file_format => lv_metric_input_file_format,
                                       po_v_metric_input_file_path   => lv_metric_input_file_path,
                                       po_v_column_list              => lv_column_list,
                                       po_v_column_list_date         => lv_fields_list,
                                       po_v_column_datatype_list     => lv_column_datatype_list,
                                       po_v_metric_source_id         => lv_metric_source_id);

    --    --dbms_output.put_line(lv_column_datatype_list);
    --    --dbms_output.put_line(lv_directory_name);
    --    --dbms_output.put_line(lv_metric_source_id);
    --    --dbms_output.put_line(lv_metric_input_file_path);
    BEGIN
      commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE no_such_directory;
    END;

    BEGIN
      SELECT filename
        INTO lv_file_name
        FROM dir_list
       WHERE regexp_like(filename, 'email_count[_0-9-]*.csv$', 'i');

    EXCEPTION
      WHEN no_data_found THEN
        RAISE no_such_file;
      WHEN too_many_rows THEN

        SELECT MAX(filename)
          INTO lv_file_name
          FROM dir_list
         WHERE regexp_like(filename, 'email_count[_0-9-]*.csv$', 'i');

      WHEN OTHERS THEN
        RAISE;
    END;

    -- creating the directory on the specified path
    lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                          fi_metric_name => lv_metric_name);

    -- creating the external table with respect to the directory created

    commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                          pi_directory_name       => lv_directory_name,
                                          pi_file_name            => lv_file_name,
                                          pi_ext_tab_source_flag  => lv_metric_source_id,
                                          pi_fields_list          => lv_fields_list,
                                          pi_metric_name          => lv_metric_name,
                                          pi_file_date            => pi_file_date,
                                          pi_data_center          => 'Datacentre_All',
                                          po_external_table_name  => lv_external_table_name);

    -- insertion in the specified metric table
    lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date)
                                    select ' || lv_column_list || ', CURRENT_DATE
                                    from ' || lv_external_table_name;

    --lv_insert_into_central_table :=
    --                'insert into' || CHR(32) || lv_metric_table_name || '(' ||lv_column_list ||', insert_date)
    --                SELECT'|| CHR(32)||REPLACE(REPLACE(lv_column_list,',SESSIONS_COUNT',',AVG(SESSIONS_COUNT)'),'EVENT_TIME','TRUNC(EVENT_TIME)') || ',CURRENT_DATE'|| CHR(32)||
    --                'FROM'|| CHR(32) || lv_external_table_name || CHR(32) ||
    --                'GROUP BY'|| CHR(32) ||REPLACE(REPLACE(lv_column_list,',SESSIONS_COUNT',''),'EVENT_TIME','TRUNC(EVENT_TIME)') ;
    --
    --          commons_utils.p_error_logging(pi_metric_id    => lv_metric_id,
    --                                    pi_procedure_name => lv_proc_name,
    --                                    pi_error_message  => lv_insert_into_central_table,
    --                                    pi_error_in_code  => SQLCODE);
    EXECUTE IMMEDIATE lv_insert_into_central_table;
    lv_num_processed := SQL%ROWCOUNT;

    commons_utils.p_get_dir_list(p_directory => lv_badroot);
    BEGIN
      SELECT count(*)
        INTO lv_badfile_cnt
        from dir_list
       where filename = 'email_count_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad';

    EXCEPTION
      WHEN OTHERS THEN
        RAISE;

    END;

    if lv_badfile_cnt > 0 then
      raise bad_file_exists;
    end if;

    -- clean the GTT
    DELETE FROM dir_list
     WHERE regexp_like(filename, 'email_count(*)', 'i');
    -- drop the external table
    commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
    -- drop the directory
    commons_utils.p_drop_directory(lv_directory_name);

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO s_email_count;
      -- clean the GTT
      DELETE FROM dir_list
       WHERE regexp_like(filename, 'email_count(*)', 'i');
      -- drop the external table
      commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
      -- drop the directory
      commons_utils.p_drop_directory(lv_directory_name);

      IF SQLCODE = -20010 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20011 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20012 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Bad file email_count_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad' || ' was generated  for Datacentre_All on at the following path ' || lv_badroot,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSE
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Failed at p_email_count with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      END IF;
      RAISE;
  END p_email_count;

  PROCEDURE p_studio_app_time(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_num_processed             PLS_INTEGER;
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN
    lv_metric_name := Upper('studio_app_time');
    lv_proc_name   := Upper('p_studio_app_time');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
    commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                       pi_file_date                  => pi_file_date,
                                       pi_v_metric_name              => lv_metric_name,
                                       pi_data_center_id             => null,
                                       po_v_metric_table_name        => lv_metric_table_name,
                                       po_v_view_name                => lv_view_name,
                                       po_v_metric_input_file_format => lv_metric_input_file_format,
                                       po_v_metric_input_file_path   => lv_metric_input_file_path,
                                       po_v_column_list              => lv_column_list,
                                       po_v_column_list_date         => lv_fields_list,
                                       po_v_column_datatype_list     => lv_column_datatype_list,
                                       po_v_metric_source_id         => lv_metric_source_id);

    --    --dbms_output.put_line(lv_column_datatype_list);
    --    --dbms_output.put_line(lv_directory_name);
    --    --dbms_output.put_line(lv_metric_source_id);
    --    --dbms_output.put_line(lv_metric_input_file_path);
    BEGIN
      commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE no_such_directory;
    END;

    BEGIN
      SELECT filename
        INTO lv_file_name
        FROM dir_list
       WHERE regexp_like(filename, 'studio_app_time[_0-9-]*.csv$', 'i');

    EXCEPTION
      WHEN no_data_found THEN
        RAISE no_such_file;
      WHEN too_many_rows THEN

        SELECT MAX(filename)
          INTO lv_file_name
          FROM dir_list
         WHERE regexp_like(filename, 'studio_app_time[_0-9-]*.csv$', 'i');

      WHEN OTHERS THEN
        RAISE;
    END;

    -- creating the directory on the specified path
    lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                          fi_metric_name => lv_metric_name);

    -- creating the external table with respect to the directory created
    commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                          pi_directory_name       => lv_directory_name,
                                          pi_file_name            => lv_file_name,
                                          pi_ext_tab_source_flag  => lv_metric_source_id,
                                          pi_fields_list          => lv_fields_list,
                                          pi_metric_name          => lv_metric_name,
                                          pi_file_date            => pi_file_date,
                                          pi_data_center          => 'Datacentre_All',
                                          po_external_table_name  => lv_external_table_name);

    -- insertion in the specified metric table
    lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date)
                                     select ' || lv_column_list || ', CURRENT_DATE
                                     from ' || lv_external_table_name;

    EXECUTE IMMEDIATE lv_insert_into_central_table;
    lv_num_processed := SQL%ROWCOUNT;

    commons_utils.p_get_dir_list(p_directory => lv_badroot);
    BEGIN
      SELECT count(*)
        INTO lv_badfile_cnt
        from dir_list
       where filename = 'studio_app_time_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad';

    EXCEPTION
      WHEN OTHERS THEN
        RAISE;

    END;

    if lv_badfile_cnt > 0 then
      raise bad_file_exists;
    end if;

    -- clean the GTT
    DELETE FROM dir_list
     WHERE regexp_like(filename, 'studio_app_time(*)', 'i');
    -- drop the external table
    commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
    -- drop the directory
    commons_utils.p_drop_directory(lv_directory_name);

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO s_studio_app_time;
      -- clean the GTT
      DELETE FROM dir_list
       WHERE regexp_like(filename, 'studio_app_time(*)', 'i');
      -- drop the external table
      commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
      -- drop the directory
      commons_utils.p_drop_directory(lv_directory_name);

      IF SQLCODE = -20010 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20011 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20012 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Bad file studio_app_time_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad' || ' was generated  for Datacentre_All on at the following path ' || lv_badroot,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSE
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Failed at p_studio_app_time with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      END IF;
      RAISE;
  END p_studio_app_time;

  PROCEDURE p_widget_load_count(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_num_processed             PLS_INTEGER;
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := Upper('widget_load_count');
    lv_proc_name   := Upper('p_widget_load_count');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
    commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                       pi_file_date                  => pi_file_date,
                                       pi_v_metric_name              => lv_metric_name,
                                       pi_data_center_id             => null,
                                       po_v_metric_table_name        => lv_metric_table_name,
                                       po_v_view_name                => lv_view_name,
                                       po_v_metric_input_file_format => lv_metric_input_file_format,
                                       po_v_metric_input_file_path   => lv_metric_input_file_path,
                                       po_v_column_list              => lv_column_list,
                                       po_v_column_list_date         => lv_fields_list,
                                       po_v_column_datatype_list     => lv_column_datatype_list,
                                       po_v_metric_source_id         => lv_metric_source_id);

    --    --dbms_output.put_line(lv_column_datatype_list);
    --    --dbms_output.put_line(lv_directory_name);
    --    --dbms_output.put_line(lv_metric_source_id);
    --    --dbms_output.put_line(lv_metric_input_file_path);
    BEGIN
      commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE no_such_directory;
    END;

    BEGIN
      SELECT filename
        INTO lv_file_name
        FROM dir_list
       WHERE regexp_like(filename, 'widget_load_count[_0-9-]*.csv$', 'i');

    EXCEPTION
      WHEN no_data_found THEN
        RAISE no_such_file;
      WHEN too_many_rows THEN

        SELECT MAX(filename)
          INTO lv_file_name
          FROM dir_list
         WHERE regexp_like(filename, 'widget_load_count[_0-9-]*.csv$', 'i');

      WHEN OTHERS THEN
        RAISE;
    END;

    -- creating the directory on the specified path
    lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                          fi_metric_name => lv_metric_name);

    -- creating the external table with respect to the directory created
    commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                          pi_directory_name       => lv_directory_name,
                                          pi_file_name            => lv_file_name,
                                          pi_ext_tab_source_flag  => lv_metric_source_id,
                                          pi_fields_list          => lv_fields_list,
                                          pi_metric_name          => lv_metric_name,
                                          pi_file_date            => pi_file_date,
                                          pi_data_center          => 'Datacentre_All',
                                          po_external_table_name  => lv_external_table_name);

    -- insertion in the specified metric table
    lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date)
                                     select ' || lv_column_list || ', CURRENT_DATE
                                     from ' || lv_external_table_name;

    --           commons_utils.p_error_logging(pi_metric_name    => 'gaurav',
    --                                    pi_procedure_name => 'gauarv',
    --                                    pi_error_message  => lv_insert_into_central_table,
    --                                    pi_error_in_code  => SQLCODE,
    --                                    pi_tel_error_event_date => CURRENT_DATE);
    EXECUTE IMMEDIATE lv_insert_into_central_table;
    lv_num_processed := SQL%ROWCOUNT;

    commons_utils.p_get_dir_list(p_directory => lv_badroot);
    BEGIN
      SELECT count(*)
        INTO lv_badfile_cnt
        from dir_list
       where filename = 'widget_load_count_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad';

    EXCEPTION
      WHEN OTHERS THEN
        RAISE;

    END;

    if lv_badfile_cnt > 0 then
      raise bad_file_exists;
    end if;

    -- clean the GTT
    DELETE FROM dir_list
     WHERE regexp_like(filename, 'widget_load_count(*)', 'i');
    -- drop the external table
    commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
    -- drop the directory
    commons_utils.p_drop_directory(lv_directory_name);


  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO s_widget_load_count;
      -- clean the GTT
      DELETE FROM dir_list
       WHERE regexp_like(filename, 'widget_load_count(*)', 'i');
      -- drop the external table
      commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
      -- drop the directory
      commons_utils.p_drop_directory(lv_directory_name);

      IF SQLCODE = -20010 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20011 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20012 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Bad file widget_load_count_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad' || ' was generated  for Datacentre_All on at the following path ' || lv_badroot,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSE
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Failed at p_widget_load_count with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      END IF;
      RAISE;
  END p_widget_load_count;

  PROCEDURE p_objects_count(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_date_value                date;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;
    

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := upper('Objects_count');
    lv_proc_name   := upper('p_objects_count');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    FOR i IN (SELECT cdc.data_center_id
                FROM config_metric_data_centre_map cmdcm,
                     config_data_centers           cdc, table_load_metrics tlm 
               WHERE cmdcm.metric_id = lv_metric_id
                 and cmdcm.is_enabled = 'Y'
                 and cmdcm.data_centre_id = to_char(cdc.data_center_id)
                 and cdc.data_center_flag = 1
                 and tlm.DATA_CENTRE_ID = cmdcm.data_centre_id
                 and tlm.METRIC_ID = cmdcm.metric_id
                 and tlm.LOADED_DATE = pi_file_date
                 and tlm.LOADED_FLAG = 'N') LOOP

      SAVEPOINT s_objects_count;
      begin
        -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
        commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                           pi_file_date                  => pi_file_date,
                                           pi_v_metric_name              => lv_metric_name,
                                           pi_data_center_id             => i.data_center_id,
                                           po_v_metric_table_name        => lv_metric_table_name,
                                           po_v_view_name                => lv_view_name,
                                           po_v_metric_input_file_format => lv_metric_input_file_format,
                                           po_v_metric_input_file_path   => lv_metric_input_file_path,
                                           po_v_column_list              => lv_column_list,
                                           po_v_column_list_date         => lv_fields_list,
                                           po_v_column_datatype_list     => lv_column_datatype_list,
                                           po_v_metric_source_id         => lv_metric_source_id);

        --    --dbms_output.put_line(lv_column_datatype_list);
        --    --dbms_output.put_line(lv_directory_name);
        --    --dbms_output.put_line(lv_metric_source_id);
        --    --dbms_output.put_line(lv_metric_input_file_path);
        BEGIN
          commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
        EXCEPTION
          WHEN OTHERS THEN
            RAISE no_such_directory;
        END;

        BEGIN
          SELECT filename
            INTO lv_file_name
            FROM dir_list
           WHERE regexp_like(filename, 'Object_usage[_0-9-]*.csv$', 'i');

        EXCEPTION
          WHEN no_data_found THEN
            RAISE no_such_file;
          WHEN too_many_rows THEN

            SELECT MAX(filename)
              INTO lv_file_name
              FROM dir_list
             WHERE regexp_like(filename, 'Object_usage[_0-9-]*.csv$', 'i');

          WHEN OTHERS THEN
            RAISE;
        END;

        -- creating the directory on the specified path
        lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                              fi_metric_name => lv_metric_name);

        -- creating the external table with respect to the directory created

        commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                              pi_directory_name       => lv_directory_name,
                                              pi_file_name            => lv_file_name,
                                              pi_ext_tab_source_flag  => lv_metric_source_id,
                                              pi_fields_list          => lv_fields_list,
                                              pi_metric_name          => lv_metric_name,
                                              pi_file_date            => pi_file_date,
                                              pi_data_center          => i.data_center_id,
                                              po_external_table_name  => lv_external_table_name);
        -- get the event date from the filename to be inserted into the table
        SELECT to_date(regexp_substr(lv_file_name, '[0-9]+-[0-9]+-[0-9]+'), 'YYYY-MM-DD')
          INTO lv_date_value
          FROM dual;

        -- insertion in the specified metric table
        lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date, event_date,ENV_DATA_CENTER_ID)
                                         select ' || lv_column_list || ', CURRENT_DATE, ''' || lv_date_value || ''',' || i.data_center_id || '
                                         from ' ||  lv_external_table_name;

        EXECUTE IMMEDIATE lv_insert_into_central_table;
        

        commons_utils.p_get_dir_list(p_directory => lv_badroot);
        BEGIN
          SELECT count(*)
            INTO lv_badfile_cnt
            from dir_list
           where filename = 'objects_count_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad';

        EXCEPTION
          WHEN OTHERS THEN
            RAISE;

        END;

        if lv_badfile_cnt > 0 then
          raise bad_file_exists;
        end if;

        -- clean the GTT
        DELETE FROM dir_list
         WHERE regexp_like(filename, 'Object_usage(*)', 'i') OR regexp_like(filename, 'objects_count(*)', 'i');
        -- drop the external table
        commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
        -- drop the directory
        commons_utils.p_drop_directory(lv_directory_name);

        UPDATE table_load_metrics
           SET loaded_flag = 'Y'
         WHERE metric_id = 15
           AND loaded_date = pi_file_date
           AND data_centre_id = i.data_center_id;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK TO s_objects_count;
          -- clean the GTT
          DELETE FROM dir_list
           WHERE regexp_like(filename, 'Object_usage(*)', 'i') OR regexp_like(filename, 'objects_count(*)', 'i');
          -- drop the external table
          commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
          -- drop the directory
          commons_utils.p_drop_directory(lv_directory_name);

          IF SQLCODE = -20010 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20011 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20012 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Bad file objects_count_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad' ||  ' was generated for Datacentre_' ||i.data_center_id ||' on at the following path ' || lv_badroot,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSE
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Failed at p_objects_count with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          END IF;
      END;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                    pi_procedure_name       => lv_proc_name,
                                    pi_error_message        => 'Failed at p_objects_count with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                    pi_error_in_code        => SQLCODE,
                                    pi_tel_error_event_date => pi_file_date);
      RAISE;
  END p_objects_count;

  PROCEDURE p_studio_app_count(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_date_value                date;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;
    

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := upper('Studio_App_Count');
    lv_proc_name   := upper('p_studio_app_count');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    FOR i IN (SELECT cdc.data_center_id
                FROM config_metric_data_centre_map cmdcm,
                     config_data_centers           cdc, table_load_metrics tlm 
               WHERE cmdcm.metric_id = lv_metric_id
                 and cmdcm.is_enabled = 'Y'
                 and cmdcm.data_centre_id = to_char(cdc.data_center_id)
                 and cdc.data_center_flag = 1
                 and tlm.DATA_CENTRE_ID = cmdcm.data_centre_id
                 and tlm.METRIC_ID = cmdcm.metric_id
                 and tlm.LOADED_DATE = pi_file_date
                 and tlm.LOADED_FLAG = 'N') LOOP

      SAVEPOINT s_studio_app_count;

      begin
        -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
        commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                           pi_file_date                  => pi_file_date,
                                           pi_v_metric_name              => lv_metric_name,
                                           pi_data_center_id             => i.data_center_id,
                                           po_v_metric_table_name        => lv_metric_table_name,
                                           po_v_view_name                => lv_view_name,
                                           po_v_metric_input_file_format => lv_metric_input_file_format,
                                           po_v_metric_input_file_path   => lv_metric_input_file_path,
                                           po_v_column_list              => lv_column_list,
                                           po_v_column_list_date         => lv_fields_list,
                                           po_v_column_datatype_list     => lv_column_datatype_list,
                                           po_v_metric_source_id         => lv_metric_source_id);

        --    --dbms_output.put_line(lv_column_datatype_list);
        --    --dbms_output.put_line(lv_directory_name);
        --    --dbms_output.put_line(lv_metric_source_id);
        --    --dbms_output.put_line(lv_metric_input_file_path);
        BEGIN
          commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
        EXCEPTION
          WHEN OTHERS THEN
            RAISE no_such_directory;
        END;

        BEGIN
          SELECT filename
            INTO lv_file_name
            FROM dir_list
           WHERE regexp_like(filename, 'Number_of_Studio_Apps[_0-9-]*.csv$', 'i');

        EXCEPTION
          WHEN no_data_found THEN
            RAISE no_such_file;
          WHEN too_many_rows THEN

            SELECT MAX(filename)
              INTO lv_file_name
              FROM dir_list
             WHERE regexp_like(filename, 'Number_of_Studio_Apps[_0-9-]*.csv$', 'i');

          WHEN OTHERS THEN
            RAISE;
        END;

        -- creating the directory on the specified path
        lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                              fi_metric_name => lv_metric_name);

        -- creating the external table with respect to the directory created
        commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                              pi_directory_name       => lv_directory_name,
                                              pi_file_name            => lv_file_name,
                                              pi_ext_tab_source_flag  => lv_metric_source_id,
                                              pi_fields_list          => lv_fields_list,
                                              pi_metric_name          => lv_metric_name,
                                              pi_file_date            => pi_file_date,
                                              pi_data_center          => i.data_center_id,
                                              po_external_table_name  => lv_external_table_name);

        -- get the event date from the filename to be inserted into the table
        SELECT to_date(regexp_substr(lv_file_name, '[0-9]+-[0-9]+-[0-9]+'),'YYYY-MM-DD')
          INTO lv_date_value
          FROM dual;

        -- insertion in the specified metric table
        lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date, event_date,ENV_DATA_CENTER_ID)
                                         select ' || lv_column_list || ', CURRENT_DATE, ''' || lv_date_value || ''',' || i.data_center_id || '
                                         from ' || lv_external_table_name;

        EXECUTE IMMEDIATE lv_insert_into_central_table;
        

        commons_utils.p_get_dir_list(p_directory => lv_badroot);
        BEGIN
          SELECT count(*)
            INTO lv_badfile_cnt
            from dir_list
           where filename = 'studio_app_count_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad';

        EXCEPTION
          WHEN OTHERS THEN
            RAISE;

        END;

        if lv_badfile_cnt > 0 then
          raise bad_file_exists;
        end if;

        -- clean the GTT
        DELETE FROM dir_list
         WHERE regexp_like(filename, 'Number_of_Studio_Apps(*)', 'i') or regexp_like(filename, 'studio_app_count(*)', 'i');
        -- drop the external table
        commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
        -- drop the directory
        commons_utils.p_drop_directory(lv_directory_name);

        UPDATE table_load_metrics
           SET loaded_flag = 'Y'
         WHERE metric_id = 2
           AND loaded_date = pi_file_date
           AND data_centre_id = i.data_center_id;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK TO s_studio_app_count;
          -- clean the GTT
          DELETE FROM dir_list
           WHERE regexp_like(filename, 'Number_of_Studio_Apps(*)', 'i') or regexp_like(filename, 'studio_app_count(*)', 'i');
          -- drop the external table
          commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
          -- drop the directory
          commons_utils.p_drop_directory(lv_directory_name);

          IF SQLCODE = -20010 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20011 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20012 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Bad file studio_app_count_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad' || ' was generated for Datacentre_' ||i.data_center_id ||' on at the following path ' || lv_badroot,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSE
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Failed at p_studio_app_count with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          END IF;
      END;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                    pi_procedure_name       => lv_proc_name,
                                    pi_error_message        => 'Failed at p_studio_app_count with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                    pi_error_in_code        => SQLCODE,
                                    pi_tel_error_event_date => pi_file_date);
      RAISE;
  END p_studio_app_count;

  PROCEDURE p_studio_app_allowed(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_date_value                date;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;
    

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := upper('Studio_App_Allowed');
    lv_proc_name   := upper('p_studio_app_allowed');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    FOR i IN (SELECT cdc.data_center_id
                FROM config_metric_data_centre_map cmdcm,
                     config_data_centers           cdc, table_load_metrics tlm 
               WHERE cmdcm.metric_id = lv_metric_id
                 and cmdcm.is_enabled = 'Y'
                 and cmdcm.data_centre_id = to_char(cdc.data_center_id)
                 and cdc.data_center_flag = 1
                 and tlm.DATA_CENTRE_ID = cmdcm.data_centre_id
                 and tlm.METRIC_ID = cmdcm.metric_id
                 and tlm.LOADED_DATE = pi_file_date
                 and tlm.LOADED_FLAG = 'N') LOOP

      SAVEPOINT s_studio_app_allowed;
      begin
        -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
        commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                           pi_file_date                  => pi_file_date,
                                           pi_v_metric_name              => lv_metric_name,
                                           pi_data_center_id             => i.data_center_id,
                                           po_v_metric_table_name        => lv_metric_table_name,
                                           po_v_view_name                => lv_view_name,
                                           po_v_metric_input_file_format => lv_metric_input_file_format,
                                           po_v_metric_input_file_path   => lv_metric_input_file_path,
                                           po_v_column_list              => lv_column_list,
                                           po_v_column_list_date         => lv_fields_list,
                                           po_v_column_datatype_list     => lv_column_datatype_list,
                                           po_v_metric_source_id         => lv_metric_source_id);

        --    --dbms_output.put_line(lv_column_datatype_list);
        --    --dbms_output.put_line(lv_directory_name);
        --    --dbms_output.put_line(lv_metric_source_id);
        --    --dbms_output.put_line(lv_metric_input_file_path);
        BEGIN
          commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
        EXCEPTION
          WHEN OTHERS THEN
            RAISE no_such_directory;
        END;

        BEGIN
          SELECT filename
            INTO lv_file_name
            FROM dir_list
           WHERE regexp_like(filename, 'Number_of_allowed_Studio_Apps[_0-9-]*.csv$', 'i');

        EXCEPTION
          WHEN no_data_found THEN
          RAISE no_such_file;
          WHEN too_many_rows THEN

            SELECT MAX(filename)
              INTO lv_file_name
              FROM dir_list
             WHERE regexp_like(filename, 'Number_of_allowed_Studio_Apps[_0-9-]*.csv$', 'i');

          WHEN OTHERS THEN
            RAISE;
        END;

        -- creating the directory on the specified path
        lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                              fi_metric_name => lv_metric_name);

        -- creating the external table with respect to the directory created
        commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                              pi_directory_name       => lv_directory_name,
                                              pi_file_name            => lv_file_name,
                                              pi_ext_tab_source_flag  => lv_metric_source_id,
                                              pi_fields_list          => lv_fields_list,
                                              pi_metric_name          => lv_metric_name,
                                              pi_file_date            => pi_file_date,
                                              pi_data_center          => i.data_center_id,
                                              po_external_table_name  => lv_external_table_name);

        -- get the event date from the filename to be inserted into the table
        SELECT to_date(regexp_substr(lv_file_name, '[0-9]+-[0-9]+-[0-9]+'), 'YYYY-MM-DD')
          INTO lv_date_value
          FROM dual;

        -- insertion in the specified metric table
        lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date, event_date,ENV_DATA_CENTER_ID)
                                         select ' || lv_column_list || ', CURRENT_DATE, ''' || lv_date_value || ''',' || i.data_center_id || '
                                         from ' || lv_external_table_name;

        EXECUTE IMMEDIATE lv_insert_into_central_table;
        

        commons_utils.p_get_dir_list(p_directory => lv_badroot);
        BEGIN
          SELECT count(*)
            INTO lv_badfile_cnt
            FROM dir_list
           where filename = 'studio_app_allowed_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad';

        EXCEPTION
          WHEN OTHERS THEN
            RAISE;

        END;

        if lv_badfile_cnt > 0 then
          raise bad_file_exists;
        end if;

        -- clean the GTT
        DELETE FROM dir_list
         WHERE regexp_like(filename, 'Number_of_allowed_Studio_Apps(*)', 'i') or regexp_like(filename, 'studio_app_allowed', 'i');
        -- drop the external table
        commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
        -- drop the directory
        commons_utils.p_drop_directory(lv_directory_name);

        UPDATE table_load_metrics
           SET loaded_flag = 'Y'
         WHERE metric_id = 3
           AND loaded_date = pi_file_date
           AND data_centre_id = i.data_center_id;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK TO s_studio_app_allowed;
          -- clean the GTT
          DELETE FROM dir_list
           WHERE regexp_like(filename, 'Number_of_allowed_Studio_Apps(*)', 'i') or regexp_like(filename, 'studio_app_allowed', 'i');
          -- drop the external table
          commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
          -- drop the directory
          commons_utils.p_drop_directory(lv_directory_name);

          IF SQLCODE = -20010 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20011 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20012 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Bad file studio_app_allowed_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad' || ' was generated for Datacentre_' ||i.data_center_id ||' on at the following path ' || lv_badroot,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSE
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Failed at p_studio_app_allowed with error :- ' || SQLERRM || 'Backtraced: ' ||commons_utils.f_get_exception_backtrace,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          END IF;
      END;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                    pi_procedure_name       => lv_proc_name,
                                    pi_error_message        => 'Failed at p_studio_app_allowed with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                    pi_error_in_code        => SQLCODE,
                                    pi_tel_error_event_date => pi_file_date);
      RAISE;
  END p_studio_app_allowed;

PROCEDURE p_studio_app_licenced(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_num_processed             PLS_INTEGER;
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := upper('studio_app_licenced');
    lv_proc_name   := upper('p_studio_app_licenced');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
    commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                       pi_file_date                  => pi_file_date,
                                       pi_v_metric_name              => lv_metric_name,
                                       pi_data_center_id             => null,
                                       po_v_metric_table_name        => lv_metric_table_name,
                                       po_v_view_name                => lv_view_name,
                                       po_v_metric_input_file_format => lv_metric_input_file_format,
                                       po_v_metric_input_file_path   => lv_metric_input_file_path,
                                       po_v_column_list              => lv_column_list,
                                       po_v_column_list_date         => lv_fields_list,
                                       po_v_column_datatype_list     => lv_column_datatype_list,
                                       po_v_metric_source_id         => lv_metric_source_id);

    --    --dbms_output.put_line(lv_column_datatype_list);
    --    --dbms_output.put_line(lv_directory_name);
    --    --dbms_output.put_line(lv_metric_source_id);
    --    --dbms_output.put_line(lv_metric_input_file_path);
    BEGIN
      commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE no_such_directory;
    END;

    BEGIN
      SELECT filename
        INTO lv_file_name
        FROM dir_list
           WHERE regexp_like(filename, 'Studio_App_Licenced[_0-9-]*.csv$', 'i');

    EXCEPTION
      WHEN no_data_found THEN
        RAISE no_such_file;
      WHEN too_many_rows THEN

        SELECT MAX(filename)
          INTO lv_file_name
          FROM dir_list
             WHERE regexp_like(filename, 'Studio_App_Licenced[_0-9-]*.csv$', 'i');

      WHEN OTHERS THEN
        RAISE;
    END;

    -- creating the directory on the specified path
    lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                          fi_metric_name => lv_metric_name);

    -- creating the external table with respect to the directory created

    commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                          pi_directory_name       => lv_directory_name,
                                          pi_file_name            => lv_file_name,
                                          pi_ext_tab_source_flag  => lv_metric_source_id,
                                          pi_fields_list          => lv_fields_list,
                                          pi_metric_name          => lv_metric_name,
                                          pi_file_date            => pi_file_date,
                                          pi_data_center          => 'Datacentre_All',
                                          po_external_table_name  => lv_external_table_name);

    -- insertion in the specified metric table
    lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date)
                                    select ' || lv_column_list || ', CURRENT_DATE
                                    from ' || lv_external_table_name;

    --lv_insert_into_central_table :=
    --                'insert into' || CHR(32) || lv_metric_table_name || '(' ||lv_column_list ||', insert_date)
    --                SELECT'|| CHR(32)||REPLACE(REPLACE(lv_column_list,',SESSIONS_COUNT',',AVG(SESSIONS_COUNT)'),'EVENT_TIME','TRUNC(EVENT_TIME)') || ',CURRENT_DATE'|| CHR(32)||
    --                'FROM'|| CHR(32) || lv_external_table_name || CHR(32) ||
    --                'GROUP BY'|| CHR(32) ||REPLACE(REPLACE(lv_column_list,',SESSIONS_COUNT',''),'EVENT_TIME','TRUNC(EVENT_TIME)') ;
    --
    --          commons_utils.p_error_logging(pi_metric_id    => lv_metric_id,
    --                                    pi_procedure_name => lv_proc_name,
    --                                    pi_error_message  => lv_insert_into_central_table,
    --                                    pi_error_in_code  => SQLCODE);
    EXECUTE IMMEDIATE lv_insert_into_central_table;
    lv_num_processed := SQL%ROWCOUNT;

    commons_utils.p_get_dir_list(p_directory => lv_badroot);
    BEGIN
      SELECT count(*)
        INTO lv_badfile_cnt
        from dir_list
           where filename = 'studio_app_licenced_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad';

    EXCEPTION
      WHEN OTHERS THEN
        RAISE;

    END;

    if lv_badfile_cnt > 0 then
      raise bad_file_exists;
    end if;

    -- clean the GTT
    DELETE FROM dir_list
         WHERE regexp_like(filename, 'Studio_App_Licenced(*)', 'i');
    -- drop the external table
    commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
    -- drop the directory
    commons_utils.p_drop_directory(lv_directory_name);


  EXCEPTION
    WHEN OTHERS THEN
          ROLLBACK TO s_studio_app_licenced;
      -- clean the GTT
      DELETE FROM dir_list
           WHERE regexp_like(filename, 'Studio_App_Licenced(*)', 'i');
      -- drop the external table
      commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
      -- drop the directory
      commons_utils.p_drop_directory(lv_directory_name);

      IF SQLCODE = -20010 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20011 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20012 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Bad file studio_app_licenced_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad' || ' was generated  for Datacentre_All on at the following path ' || lv_badroot,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSE
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Failed at p_studio_app_licenced with error :- ' || SQLERRM || 'Backtraced: ' ||commons_utils.f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      END IF;
      RAISE;
  END p_studio_app_licenced;


  PROCEDURE p_widget_count(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_date_value                date;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;
    

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := upper('WIDGET_COUNT');
    lv_proc_name   := upper('p_widget_count');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    FOR i IN (SELECT cdc.data_center_id
                FROM config_metric_data_centre_map cmdcm,
                     config_data_centers           cdc, table_load_metrics tlm 
               WHERE cmdcm.metric_id = lv_metric_id
                 and cmdcm.is_enabled = 'Y'
                 and cmdcm.data_centre_id = to_char(cdc.data_center_id)
                 and cdc.data_center_flag = 1
                 and tlm.DATA_CENTRE_ID = cmdcm.data_centre_id
                 and tlm.METRIC_ID = cmdcm.metric_id
                 and tlm.LOADED_DATE = pi_file_date
                 and tlm.LOADED_FLAG = 'N') LOOP

      SAVEPOINT s_widget_count;
      begin
        -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
        commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                           pi_file_date                  => pi_file_date,
                                           pi_v_metric_name              => lv_metric_name,
                                           pi_data_center_id             => i.data_center_id,
                                           po_v_metric_table_name        => lv_metric_table_name,
                                           po_v_view_name                => lv_view_name,
                                           po_v_metric_input_file_format => lv_metric_input_file_format,
                                           po_v_metric_input_file_path   => lv_metric_input_file_path,
                                           po_v_column_list              => lv_column_list,
                                           po_v_column_list_date         => lv_fields_list,
                                           po_v_column_datatype_list     => lv_column_datatype_list,
                                           po_v_metric_source_id         => lv_metric_source_id);

        --    --dbms_output.put_line(lv_column_datatype_list);
        --    --dbms_output.put_line(lv_directory_name);
        --    --dbms_output.put_line(lv_metric_source_id);
        --    --dbms_output.put_line(lv_metric_input_file_path);
        BEGIN
          commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
        EXCEPTION
          WHEN OTHERS THEN
            RAISE no_such_directory;
        END;

        BEGIN
          SELECT filename
            INTO lv_file_name
            FROM dir_list
           WHERE regexp_like(filename, 'WIDGET_COUNT[_0-9-]*.csv$', 'i');

        EXCEPTION
          WHEN no_data_found THEN
            RAISE no_such_file;
          WHEN too_many_rows THEN

            SELECT MAX(filename)
              INTO lv_file_name
              FROM dir_list
             WHERE regexp_like(filename, 'WIDGET_COUNT[_0-9-]*.csv$', 'i');

          WHEN OTHERS THEN
            RAISE;
        END;

        -- creating the directory on the specified path
        lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                              fi_metric_name => lv_metric_name);

        -- creating the external table with respect to the directory created
        commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                              pi_directory_name       => lv_directory_name,
                                              pi_file_name            => lv_file_name,
                                              pi_ext_tab_source_flag  => lv_metric_source_id,
                                              pi_fields_list          => lv_fields_list,
                                              pi_metric_name          => lv_metric_name,
                                              pi_file_date            => pi_file_date,
                                              pi_data_center          => i.data_center_id,
                                              po_external_table_name  => lv_external_table_name);

        -- get the event date from the filename to be inserted into the table
        SELECT to_date(regexp_substr(lv_file_name, '[0-9]+-[0-9]+-[0-9]+'), 'YYYY-MM-DD')
          INTO lv_date_value
          FROM dual;

        -- insertion in the specified metric table
        lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date, event_date,ENV_DATA_CENTER_ID)
                                         select ' || lv_column_list || ', CURRENT_DATE, ''' || lv_date_value || ''',' || i.data_center_id || '
                                         from ' || lv_external_table_name;

        EXECUTE IMMEDIATE lv_insert_into_central_table;
        

        commons_utils.p_get_dir_list(p_directory => lv_badroot);
        BEGIN
          SELECT count(*)
            INTO lv_badfile_cnt
            FROM dir_list
           where filename = 'widget_count_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad';

        EXCEPTION
          WHEN OTHERS THEN
            RAISE;

        END;

        if lv_badfile_cnt > 0 then
          raise bad_file_exists;
        end if;

        -- clean the GTT
        DELETE FROM dir_list
         WHERE regexp_like(filename, 'WIDGET_COUNT(*)', 'i');
        -- drop the external table
        commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
        -- drop the directory
        commons_utils.p_drop_directory(lv_directory_name);

        UPDATE table_load_metrics
           SET loaded_flag = 'Y'
         WHERE metric_id = 5
           AND loaded_date = pi_file_date
           AND data_centre_id = i.data_center_id;

      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK TO s_widget_count;
          -- clean the GTT
          DELETE FROM dir_list
           WHERE regexp_like(filename, 'WIDGET_COUNT(*)', 'i');
          -- drop the external table
          commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
          -- drop the directory
          commons_utils.p_drop_directory(lv_directory_name);

          IF SQLCODE = -20010 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20011 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20012 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Bad file widget_count_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad' || ' was generated for Datacentre_' ||i.data_center_id ||' on at the following path ' || lv_badroot,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSE
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Failed at p_widget_count with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          END IF;
      END;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                    pi_procedure_name       => lv_proc_name,
                                    pi_error_message        => 'Failed at p_widget_count with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                    pi_error_in_code        => SQLCODE,
                                    pi_tel_error_event_date => pi_file_date);
      RAISE;
  END p_widget_count;

  PROCEDURE p_optymyze_version(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_date_value                date;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;
    

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := upper('OPTYMYZE_VERSION');
    lv_proc_name   := upper('p_optymyze_version');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    FOR i IN (SELECT cdc.data_center_id
                FROM config_metric_data_centre_map cmdcm,
                     config_data_centers           cdc
               WHERE cmdcm.metric_id = lv_metric_id
                 and cmdcm.is_enabled = 'Y'
                 and cmdcm.data_centre_id = to_char(cdc.data_center_id)
                 and cdc.data_center_flag = 1) LOOP

      SAVEPOINT s_optymyze_version;
      begin
        -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
        commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                           pi_file_date                  => pi_file_date,
                                           pi_v_metric_name              => lv_metric_name,
                                           pi_data_center_id             => i.data_center_id,
                                           po_v_metric_table_name        => lv_metric_table_name,
                                           po_v_view_name                => lv_view_name,
                                           po_v_metric_input_file_format => lv_metric_input_file_format,
                                           po_v_metric_input_file_path   => lv_metric_input_file_path,
                                           po_v_column_list              => lv_column_list,
                                           po_v_column_list_date         => lv_fields_list,
                                           po_v_column_datatype_list     => lv_column_datatype_list,
                                           po_v_metric_source_id         => lv_metric_source_id);

        --    --dbms_output.put_line(lv_column_datatype_list);
        --    --dbms_output.put_line(lv_directory_name);
        --    --dbms_output.put_line(lv_metric_source_id);
        --    --dbms_output.put_line(lv_metric_input_file_path);
        BEGIN
          commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
        EXCEPTION
          WHEN OTHERS THEN
            RAISE no_such_directory;
        END;

        BEGIN
          SELECT filename
            INTO lv_file_name
            FROM dir_list
           WHERE regexp_like(filename, 'OPTYMYZE_VERSION[_0-9-]*.csv$', 'i');

        EXCEPTION
          WHEN no_data_found THEN
            RAISE no_such_file;
          WHEN too_many_rows THEN

            SELECT MAX(filename)
              INTO lv_file_name
              FROM dir_list
             WHERE regexp_like(filename, 'OPTYMYZE_VERSION[_0-9-]*.csv$', 'i');

          WHEN OTHERS THEN
            RAISE;
        END;

        -- creating the directory on the specified path
        lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                              fi_metric_name => lv_metric_name);

        -- creating the external table with respect to the directory created
        commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                              pi_directory_name       => lv_directory_name,
                                              pi_file_name            => lv_file_name,
                                              pi_ext_tab_source_flag  => lv_metric_source_id,
                                              pi_fields_list          => lv_fields_list,
                                              pi_metric_name          => lv_metric_name,
                                              pi_file_date            => pi_file_date,
                                              pi_data_center          => i.data_center_id,
                                              po_external_table_name  => lv_external_table_name);

        -- get the event date from the filename to be inserted into the table
        SELECT to_date(regexp_substr(lv_file_name, '[0-9]+-[0-9]+-[0-9]+'), 'YYYY-MM-DD')
          INTO lv_date_value
          FROM dual;

        -- insertion in the specified metric table
        lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date, event_date,ENV_DATA_CENTER_ID)
                                         select ' || lv_column_list || ', CURRENT_DATE, ''' || lv_date_value || ''',' || i.data_center_id || '
                                         from ' || lv_external_table_name;

        EXECUTE IMMEDIATE lv_insert_into_central_table;
        

        commons_utils.p_get_dir_list(p_directory => lv_badroot);
        BEGIN
          SELECT count(*)
            INTO lv_badfile_cnt
            FROM dir_list
           where filename = 'optymyze_version_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad';

        EXCEPTION
          WHEN OTHERS THEN
            RAISE;

        END;

        if lv_badfile_cnt > 0 then
          raise bad_file_exists;
        end if;

        -- clean the GTT
        DELETE FROM dir_list
         WHERE regexp_like(filename, 'OPTYMYZE_VERSION(*)', 'i');
        -- drop the external table
        commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
        -- drop the directory
        commons_utils.p_drop_directory(lv_directory_name);

        UPDATE table_load_metrics
           SET loaded_flag = 'Y'
         WHERE metric_id = 22
           AND loaded_date = pi_file_date
           AND data_centre_id = i.data_center_id;

      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK TO s_optymyze_version;
          -- clean the GTT
          DELETE FROM dir_list
           WHERE regexp_like(filename, 'OPTYMYZE_VERSION(*)', 'i');
          -- drop the external table
          commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
          -- drop the directory
          commons_utils.p_drop_directory(lv_directory_name);

          IF SQLCODE = -20010 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20011 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20012 THEN
            commons_utils.p_error_logging(pi_metric_id                => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Bad file optymyze_version_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad' || ' was generated for Datacentre_' ||i.data_center_id ||' on at the following path ' || lv_badroot,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSE
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Failed at p_optymyze_version with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          END IF;
      END;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                    pi_procedure_name       => lv_proc_name,
                                    pi_error_message        => 'Failed at p_optymyze_version with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                    pi_error_in_code        => SQLCODE,
                                    pi_tel_error_event_date => pi_file_date);
      RAISE;
  END p_optymyze_version;

  PROCEDURE p_data_processed_volume(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_date_value                date;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;
    

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := upper('data_processed_volume');
    lv_proc_name   := upper('p_data_processed_volume');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    FOR i IN (SELECT cdc.data_center_id
                FROM config_metric_data_centre_map cmdcm,
                     config_data_centers           cdc, table_load_metrics tlm 
               WHERE cmdcm.metric_id = lv_metric_id
                 and cmdcm.is_enabled = 'Y'
                 and cmdcm.data_centre_id = to_char(cdc.data_center_id)
                 and cdc.data_center_flag = 1
                 and tlm.DATA_CENTRE_ID = cmdcm.data_centre_id
                 and tlm.METRIC_ID = cmdcm.metric_id
                 and tlm.LOADED_DATE = pi_file_date
                 and tlm.LOADED_FLAG = 'N') LOOP

      SAVEPOINT s_data_processed_volume;
      begin
        -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
        commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                           pi_file_date                  => pi_file_date,
                                           pi_v_metric_name              => lv_metric_name,
                                           pi_data_center_id             => i.data_center_id,
                                           po_v_metric_table_name        => lv_metric_table_name,
                                           po_v_view_name                => lv_view_name,
                                           po_v_metric_input_file_format => lv_metric_input_file_format,
                                           po_v_metric_input_file_path   => lv_metric_input_file_path,
                                           po_v_column_list              => lv_column_list,
                                           po_v_column_list_date         => lv_fields_list,
                                           po_v_column_datatype_list     => lv_column_datatype_list,
                                           po_v_metric_source_id         => lv_metric_source_id);

        --    --dbms_output.put_line(lv_column_datatype_list);
        --    --dbms_output.put_line(lv_directory_name);
        --    --dbms_output.put_line(lv_metric_source_id);
        --    --dbms_output.put_line(lv_metric_input_file_path);
        BEGIN
          commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
        EXCEPTION
          WHEN OTHERS THEN
            RAISE no_such_directory;
        END;

        BEGIN
          SELECT filename
            INTO lv_file_name
            FROM dir_list
           WHERE regexp_like(filename, 'data_processed_volume[_0-9-]*.csv$', 'i');

        EXCEPTION
          WHEN no_data_found THEN
            RAISE no_such_file;
          WHEN too_many_rows THEN

            SELECT MAX(filename)
              INTO lv_file_name
              FROM dir_list
             WHERE regexp_like(filename, 'data_processed_volume[_0-9-]*.csv$', 'i');

          WHEN OTHERS THEN
            RAISE;
        END;

        -- creating the directory on the specified path
        lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                              fi_metric_name => lv_metric_name);

        -- creating the external table with respect to the directory created
        commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                              pi_directory_name       => lv_directory_name,
                                              pi_file_name            => lv_file_name,
                                              pi_ext_tab_source_flag  => lv_metric_source_id,
                                              pi_fields_list          => lv_fields_list,
                                              pi_metric_name          => lv_metric_name,
                                              pi_file_date            => pi_file_date,
                                              pi_data_center          => i.data_center_id,
                                              po_external_table_name  => lv_external_table_name);

        -- get the event date from the filename to be inserted into the table
        SELECT to_date(regexp_substr(lv_file_name, '[0-9]+-[0-9]+-[0-9]+'), 'YYYY-MM-DD')
          INTO lv_date_value
          FROM dual;

        -- insertion in the specified metric table
        lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date, event_date,ENV_DATA_CENTER_ID)
                                         select ' || lv_column_list || ', CURRENT_DATE, ''' || lv_date_value || ''',' || i.data_center_id || '
                                         from ' || lv_external_table_name;

        EXECUTE IMMEDIATE lv_insert_into_central_table;
        

        commons_utils.p_get_dir_list(p_directory => lv_badroot);
        BEGIN
          SELECT count(*)
            INTO lv_badfile_cnt
            FROM dir_list
           where filename = 'data_processed_volume_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad';

        EXCEPTION
          WHEN OTHERS THEN
            RAISE;

        END;

        if lv_badfile_cnt > 0 then
          raise bad_file_exists;
        end if;

        -- clean the GTT
        DELETE FROM dir_list
         WHERE regexp_like(filename, 'data_processed_volume(*)', 'i');
        -- drop the external table
        commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
        -- drop the directory
        commons_utils.p_drop_directory(lv_directory_name);

        UPDATE table_load_metrics
           SET loaded_flag = 'Y'
         WHERE metric_id = 11
           AND loaded_date = pi_file_date
           AND data_centre_id = i.data_center_id;
      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK TO s_data_processed_volume;
          -- clean the GTT
          DELETE FROM dir_list
           WHERE regexp_like(filename, 'data_processed_volume(*)', 'i');
          -- drop the external table
          commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
          -- drop the directory
          commons_utils.p_drop_directory(lv_directory_name);

          IF SQLCODE = -20010 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20011 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20012 THEN
            commons_utils.p_error_logging(pi_metric_id                => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Bad file data_processed_volume_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad' || ' was generated for Datacentre_' ||i.data_center_id ||' on at the following path ' || lv_badroot,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSE
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Failed at p_data_processed_volume with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          END IF;
      END;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                    pi_procedure_name       => lv_proc_name,
                                    pi_error_message        => 'Failed at p_data_processed_volume with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                    pi_error_in_code        => SQLCODE,
                                    pi_tel_error_event_date => pi_file_date);
      RAISE;
  END p_data_processed_volume;

  PROCEDURE p_used_space(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_num_processed             PLS_INTEGER;
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_date_value                date;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := Upper('Used_Space');
    lv_proc_name   := upper('p_used_space');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
    commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                       pi_file_date                  => pi_file_date,
                                       pi_v_metric_name              => lv_metric_name,
                                       pi_data_center_id             => null,
                                       po_v_metric_table_name        => lv_metric_table_name,
                                       po_v_view_name                => lv_view_name,
                                       po_v_metric_input_file_format => lv_metric_input_file_format,
                                       po_v_metric_input_file_path   => lv_metric_input_file_path,
                                       po_v_column_list              => lv_column_list,
                                       po_v_column_list_date         => lv_fields_list,
                                       po_v_column_datatype_list     => lv_column_datatype_list,
                                       po_v_metric_source_id         => lv_metric_source_id);

    ----dbms_output.put_line('lv_column_datatype_list---->'||lv_column_datatype_list);
    ----dbms_output.put_line('lv_directory_name'||lv_directory_name);
    ----dbms_output.put_line('lv_metric_source_id'||lv_metric_source_id);
    ----dbms_output.put_line('lv_metric_input_file_path'||lv_metric_input_file_path);

    BEGIN
      commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE no_such_directory;
    END;

    BEGIN
      SELECT filename
        INTO lv_file_name
        FROM dir_list
       WHERE regexp_like(filename, 'Used_Space[_0-9-]*.csv$', 'i');

    EXCEPTION
      WHEN no_data_found THEN
        RAISE no_such_file;
      WHEN too_many_rows THEN

        SELECT MAX(filename)
          INTO lv_file_name
          FROM dir_list
         WHERE regexp_like(filename, 'Used_Space[_0-9-]*.csv$', 'i');

      WHEN OTHERS THEN
        RAISE;
    END;

    -- creating the directory on the specified path
    lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                              fi_metric_name => lv_metric_name);

    ----dbms_output.put_line('lv_directory_name ' || lv_directory_name);

    -- creating the external table with respect to the directory created

    commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                          pi_directory_name       => lv_directory_name,
                                          pi_file_name            => lv_file_name,
                                          pi_ext_tab_source_flag  => lv_metric_source_id,
                                          pi_fields_list          => lv_fields_list,
                                          pi_metric_name          => lv_metric_name,
                                          pi_file_date            => pi_file_date,
                                          pi_data_center          => 'Datacentre_All',
                                          po_external_table_name  => lv_external_table_name);

    -- get the event date from the filename to be inserted into the table
    SELECT to_date(regexp_substr(lv_file_name, '[0-9]+-[0-9]+-[0-9]+'), 'YYYY-MM-DD')
      INTO lv_date_value
      FROM dual;
     -- dbms_output.put_line(lv_insert_into_central_table);
    -- insertion in the specified metric table
    lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date)
                                    select ' || lv_column_list || ', CURRENT_DATE
                                    from ' || lv_external_table_name;
                                          dbms_output.put_line(lv_insert_into_central_table);


    ----dbms_output.put_line(lv_insert_into_central_table);

    EXECUTE IMMEDIATE lv_insert_into_central_table;
    lv_num_processed := SQL%ROWCOUNT;

    commons_utils.p_get_dir_list(p_directory => lv_badroot);
    BEGIN
      SELECT count(*)
        INTO lv_badfile_cnt
        FROM dir_list
       where filename = 'used_space_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad';

    EXCEPTION
      WHEN OTHERS THEN
        RAISE;

    END;

    if lv_badfile_cnt > 0 then
      raise bad_file_exists;
    end if;

    -- clean the GTT
    DELETE FROM dir_list WHERE regexp_like(filename, 'Used_Space(*)', 'i');

    -- drop the external table
    commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
    -- drop the directory
    commons_utils.p_drop_directory(lv_directory_name);

  EXCEPTION
    WHEN OTHERS THEN
            execute immediate 'ROLLBACK TO S_'||lv_metric_id ;
      -- clean the GTT
      DELETE FROM dir_list
       WHERE regexp_like(filename, 'Used_Space(*)', 'i');
      -- drop the external table
      commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
      -- drop the directory
      commons_utils.p_drop_directory(lv_directory_name);
      IF SQLCODE = -20010 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20011 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20012 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Bad file used_space_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad' || ' was generated for Datacentre_All on at the following path ' || lv_badroot,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
     ELSIF SQLCODE = -00001 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Failed at p_used_space because of the duplicity at the source with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSE
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Failed at p_used_space with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      END IF;
      RAISE;

  END p_used_space;

  PROCEDURE p_backup_size_time(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_num_processed             PLS_INTEGER;
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name        := Upper('backup_size_time');
    lv_proc_name          := Upper('p_backup_size_time');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;



   ----dbms_output.put_line('lv_loader_seq_currval--->'||lv_loader_seq_currval);



    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
    commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                       pi_file_date                  => pi_file_date,
                                       pi_v_metric_name              => lv_metric_name,
                                       pi_data_center_id             => null,
                                       po_v_metric_table_name        => lv_metric_table_name,
                                       po_v_view_name                => lv_view_name,
                                       po_v_metric_input_file_format => lv_metric_input_file_format,
                                       po_v_metric_input_file_path   => lv_metric_input_file_path,
                                       po_v_column_list              => lv_column_list,
                                       po_v_column_list_date         => lv_fields_list,
                                       po_v_column_datatype_list     => lv_column_datatype_list,
                                       po_v_metric_source_id         => lv_metric_source_id);

    --    --dbms_output.put_line(lv_column_datatype_list);
    --    --dbms_output.put_line(lv_directory_name);
    --    --dbms_output.put_line(lv_metric_source_id);
    --    --dbms_output.put_line(lv_metric_input_file_path);

    BEGIN
      commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE no_such_directory;
    END;

    BEGIN
      SELECT filename
        INTO lv_file_name
        FROM dir_list
       WHERE regexp_like(filename, 'backup_size_time[_0-9-]*.csv$', 'i');

    EXCEPTION
      WHEN no_data_found THEN
        RAISE no_such_file;
      WHEN too_many_rows THEN

        SELECT MAX(filename)
          INTO lv_file_name
          FROM dir_list
         WHERE regexp_like(filename, 'backup_size_time[_0-9-]*.csv$', 'i');

      WHEN OTHERS THEN
        RAISE;
    END;

    -- creating the directory on the specified path
    lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                          fi_metric_name => lv_metric_name);

    -- creating the external table with respect to the directory created

    commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                          pi_directory_name       => lv_directory_name,
                                          pi_file_name            => lv_file_name,
                                          pi_ext_tab_source_flag  => lv_metric_source_id,
                                          pi_fields_list          => lv_fields_list,
                                          pi_metric_name          => lv_metric_name,
                                          pi_file_date            => pi_file_date,
                                          pi_data_center          => 'Datacentre_All',
                                          po_external_table_name  => lv_external_table_name);

    -- insertion in the specified metric table
    lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date)
                                    select ' || lv_column_list || ', CURRENT_DATE
                                    from ' || lv_external_table_name;

    --lv_insert_into_central_table :=
    --                'insert into' || CHR(32) || lv_metric_table_name || '(' ||lv_column_list ||', insert_date)
    --                SELECT'|| CHR(32)||REPLACE(REPLACE(lv_column_list,',SESSIONS_COUNT',',AVG(SESSIONS_COUNT)'),'EVENT_TIME','TRUNC(EVENT_TIME)') || ',CURRENT_DATE'|| CHR(32)||
    --                'FROM'|| CHR(32) || lv_external_table_name || CHR(32) ||
    --                'GROUP BY'|| CHR(32) ||REPLACE(REPLACE(lv_column_list,',SESSIONS_COUNT',''),'EVENT_TIME','TRUNC(EVENT_TIME)') ;
    --
    --          commons_utils.p_error_logging(pi_metric_id    => lv_metric_id,
    --                                    pi_procedure_name => lv_proc_name,
    --                                    pi_error_message  => lv_insert_into_central_table,
    --                                    pi_error_in_code  => SQLCODE);
    --    --dbms_output.put_line(lv_insert_into_central_table);

    EXECUTE IMMEDIATE lv_insert_into_central_table;
    lv_num_processed := SQL%ROWCOUNT;

    --badfilename := 'backup_size_time_' || to_char(pi_file_date, 'ddmmyyyy') || '_' || lv_loader_seq_currval || '.bad';
    -- --dbms_output.put_line('badfilename--->'||badfilename);

    commons_utils.p_get_dir_list(p_directory => lv_badroot);
    BEGIN
    /* select filename into badfilename  from dir_list
     where filename = 'backup_size_time_' || to_char(pi_file_date, 'ddmmyyyy') || '_' || lv_loader_seq_currval || '.bad';

     --dbms_output.put_line('badfilename--->'||badfilename);

    */
      SELECT count(*)
        INTO lv_badfile_cnt
        FROM dir_list
       where filename = 'backup_size_time_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad';

    EXCEPTION
      WHEN OTHERS THEN
        RAISE;

    END;

    if lv_badfile_cnt > 0 then
      raise bad_file_exists;
    end if;

    -- clean the GTT
    DELETE FROM dir_list
     WHERE regexp_like(filename, 'backup_size_time(*)', 'i');

    -- drop the external table
    commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
    -- drop the directory
    commons_utils.p_drop_directory(lv_directory_name);


  EXCEPTION
    WHEN OTHERS THEN

      ROLLBACK TO s_backup_size_time; ----s_backup_size_time
      -- clean the GTT
      DELETE FROM dir_list
       WHERE regexp_like(filename, 'backup_size_time(*)', 'i');

      -- drop the external table
      commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
      -- drop the directory
      commons_utils.p_drop_directory(lv_directory_name);

      IF SQLCODE = -20010 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20011 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20012 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Bad file backup_size_time_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad' || ' was generated for Datacentre_All on at the following path ' || lv_badroot,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSE
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Failed at p_backup_size_time with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      END IF;
      RAISE;
  END p_backup_size_time;

  PROCEDURE p_languages_per_client_count(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_date_value                date;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;
    

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := upper('languages_per_client_count');
    lv_proc_name   := upper('p_languages_per_client_count');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;
    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    FOR i IN (SELECT cdc.data_center_id
                FROM config_metric_data_centre_map cmdcm,
                     config_data_centers           cdc, table_load_metrics tlm 
               WHERE cmdcm.metric_id = lv_metric_id
                 and cmdcm.is_enabled = 'Y'
                 and cmdcm.data_centre_id = to_char(cdc.data_center_id)
                 and cdc.data_center_flag = 1
                 and tlm.DATA_CENTRE_ID = cmdcm.data_centre_id
                 and tlm.METRIC_ID = cmdcm.metric_id
                 and tlm.LOADED_DATE = pi_file_date
                 and tlm.LOADED_FLAG = 'N') LOOP

   SAVEPOINT s_languages_per_client_count;
      begin
        -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
        commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                           pi_file_date                  => pi_file_date,
                                           pi_v_metric_name              => lv_metric_name,
                                           pi_data_center_id             => i.data_center_id,
                                           po_v_metric_table_name        => lv_metric_table_name,
                                           po_v_view_name                => lv_view_name,
                                           po_v_metric_input_file_format => lv_metric_input_file_format,
                                           po_v_metric_input_file_path   => lv_metric_input_file_path,
                                           po_v_column_list              => lv_column_list,
                                           po_v_column_list_date         => lv_fields_list,
                                           po_v_column_datatype_list     => lv_column_datatype_list,
                                           po_v_metric_source_id         => lv_metric_source_id);

        --    --dbms_output.put_line(lv_column_datatype_list);
        --    --dbms_output.put_line(lv_directory_name);
        --    --dbms_output.put_line(lv_metric_source_id);
        --    --dbms_output.put_line(lv_metric_input_file_path);
        BEGIN
          commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
        EXCEPTION
          WHEN OTHERS THEN
            RAISE no_such_directory;
        END;

        BEGIN
          SELECT filename
            INTO lv_file_name
            FROM dir_list
           where regexp_like(filename, 'Number_of_languages_used_per_client[_0-9-]*.csv$', 'i');
           ----dbms_output.put_line(lv_file_name);

        EXCEPTION
          WHEN no_data_found THEN
            RAISE no_such_file;
          WHEN too_many_rows THEN

            SELECT MAX(filename)
              INTO lv_file_name
              FROM dir_list
             WHERE regexp_like(filename, 'Number_of_languages_used_per_client[_0-9-]*.csv$', 'i');

          WHEN OTHERS THEN
            RAISE;
        END;

        -- creating the directory on the specified path
        lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                              fi_metric_name => lv_metric_name);

        -- creating the external table with respect to the directory created
        commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                              pi_directory_name       => lv_directory_name,
                                              pi_file_name            => lv_file_name,
                                              pi_ext_tab_source_flag  => lv_metric_source_id,
                                              pi_fields_list          => lv_fields_list,
                                              pi_metric_name          => lv_metric_name,
                                              pi_file_date            => pi_file_date,
                                              pi_data_center          => i.data_center_id,
                                              po_external_table_name  => lv_external_table_name);

        -- get the event date from the filename to be inserted into the table
        SELECT to_date(regexp_substr(lv_file_name, '[0-9]+-[0-9]+-[0-9]+'), 'YYYY-MM-DD')
          INTO lv_date_value
          FROM dual;

        -- insertion in the specified metric table
        lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date, event_date,ENV_DATA_CENTER_ID)
                                         select ' || lv_column_list || ', CURRENT_DATE, ''' || lv_date_value || ''',' || i.data_center_id || '
                                         from ' || lv_external_table_name;

        EXECUTE IMMEDIATE lv_insert_into_central_table;
        

        commons_utils.p_get_dir_list(p_directory => lv_badroot);
        BEGIN
          SELECT count(*)
            INTO lv_badfile_cnt
            from dir_list
           where filename = 'languages_per_client_count_' || to_char(pi_file_date, 'ddmmyyyy') ||'_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad';

        EXCEPTION
          WHEN OTHERS THEN
            RAISE;

        END;

        if lv_badfile_cnt > 0 then
          raise bad_file_exists;
        end if;

        -- clean the GTT
        delete from dir_list
         WHERE  regexp_like(filename, 'Number_of_languages_used_per_client(*)', 'i') or regexp_like(filename, 'languages_per_client_count(*)', 'i');
        -- drop the external table
        commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
        -- drop the directory
        commons_utils.p_drop_directory(lv_directory_name);

        UPDATE table_load_metrics
           SET loaded_flag = 'Y'
         WHERE metric_id = 29
           AND loaded_date = pi_file_date
           AND data_centre_id = i.data_center_id;

      EXCEPTION
        WHEN OTHERS THEN
        ROLLBACK TO s_Languages_Per_Client_Count;
        -- clean the GTT
        delete from dir_list
         WHERE  regexp_like(filename, 'Number_of_languages_used_per_client(*)', 'i') or regexp_like(filename, 'languages_per_client_count(*)', 'i');
          -- drop the external table
          commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
          -- drop the directory
          commons_utils.p_drop_directory(lv_directory_name);

          IF SQLCODE = -20010 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20011 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20012 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Bad file languages_per_client_count_' || to_char(pi_file_date, 'ddmmyyyy') ||'_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad' || ' was generated for Datacentre_' ||i.data_center_id ||' on at the following path ' || lv_badroot,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSE
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Failed at p_languages_per_client_count with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          END IF;
      END;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                    pi_procedure_name       => lv_proc_name,
                                    pi_error_message        => 'Failed at p_languages_per_client_count with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                    pi_error_in_code        => SQLCODE,
                                    pi_tel_error_event_date => pi_file_date);
    RAISE;
    END p_languages_per_client_count;

    PROCEDURE p_user_languages(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_date_value                date;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;
    

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := upper('USER_LANGUAGES');
    lv_proc_name   := upper('p_user_languages');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;
    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    FOR i IN (SELECT cdc.data_center_id
                FROM config_metric_data_centre_map cmdcm,
                     config_data_centers           cdc, table_load_metrics tlm 
               WHERE cmdcm.metric_id = lv_metric_id
                 and cmdcm.is_enabled = 'Y'
                 and cmdcm.data_centre_id = to_char(cdc.data_center_id)
                 and cdc.data_center_flag = 1
                 and tlm.DATA_CENTRE_ID = cmdcm.data_centre_id
                 and tlm.METRIC_ID = cmdcm.metric_id
                 and tlm.LOADED_DATE = pi_file_date
                 and tlm.LOADED_FLAG = 'N') LOOP

   SAVEPOINT s_user_languages;
      begin
        -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
        commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                           pi_file_date                  => pi_file_date,
                                           pi_v_metric_name              => lv_metric_name,
                                           pi_data_center_id             => i.data_center_id,
                                           po_v_metric_table_name        => lv_metric_table_name,
                                           po_v_view_name                => lv_view_name,
                                           po_v_metric_input_file_format => lv_metric_input_file_format,
                                           po_v_metric_input_file_path   => lv_metric_input_file_path,
                                           po_v_column_list              => lv_column_list,
                                           po_v_column_list_date         => lv_fields_list,
                                           po_v_column_datatype_list     => lv_column_datatype_list,
                                           po_v_metric_source_id         => lv_metric_source_id);

        --    --dbms_output.put_line(lv_column_datatype_list);
        --    --dbms_output.put_line(lv_directory_name);
        --    --dbms_output.put_line(lv_metric_source_id);
        --    --dbms_output.put_line(lv_metric_input_file_path);
        BEGIN
          commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
        EXCEPTION
          WHEN OTHERS THEN
            RAISE no_such_directory;
        END;

        BEGIN
          SELECT filename
            INTO lv_file_name
            FROM dir_list
           WHERE regexp_like(filename, 'USER_LANGUAGES[_0-9-]*.csv$', 'i');

        EXCEPTION
          WHEN no_data_found THEN
            RAISE no_such_file;
          WHEN too_many_rows THEN

            SELECT MAX(filename)
              INTO lv_file_name
              FROM dir_list
             WHERE regexp_like(filename, 'USER_LANGUAGES[_0-9-]*.csv$', 'i');

          WHEN OTHERS THEN
            RAISE;
        END;

        -- creating the directory on the specified path
        lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                              fi_metric_name => lv_metric_name);

        -- creating the external table with respect to the directory created
        commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                              pi_directory_name       => lv_directory_name,
                                              pi_file_name            => lv_file_name,
                                              pi_ext_tab_source_flag  => lv_metric_source_id,
                                              pi_fields_list          => lv_fields_list,
                                              pi_metric_name          => lv_metric_name,
                                              pi_file_date            => pi_file_date,
                                              pi_data_center          => i.data_center_id,
                                              po_external_table_name  => lv_external_table_name);

        -- get the event date from the filename to be inserted into the table
        SELECT to_date(regexp_substr(lv_file_name, '[0-9]+-[0-9]+-[0-9]+'), 'YYYY-MM-DD')
          INTO lv_date_value
          FROM dual;

        -- insertion in the specified metric table
        lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date, event_date,ENV_DATA_CENTER_ID)
                                         select ' || lv_column_list || ', CURRENT_DATE, ''' || lv_date_value || ''',' || i.data_center_id || '
                                         from ' || lv_external_table_name;

        EXECUTE IMMEDIATE lv_insert_into_central_table;
        

        commons_utils.p_get_dir_list(p_directory => lv_badroot);
        BEGIN
          SELECT count(*)
            INTO lv_badfile_cnt
            FROM dir_list
           where filename = 'user_languages_' || to_char(pi_file_date, 'ddmmyyyy') ||'_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad';

        EXCEPTION
          WHEN OTHERS THEN
            RAISE;

        END;

        if lv_badfile_cnt > 0 then
          raise bad_file_exists;
        end if;

        -- clean the GTT
        DELETE FROM dir_list
         WHERE regexp_like(filename, 'USER_LANGUAGES(*)', 'i');
        -- drop the external table
        commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
        -- drop the directory
        commons_utils.p_drop_directory(lv_directory_name);

        UPDATE table_load_metrics
           SET loaded_flag = 'Y'
         WHERE metric_id = 28
           AND loaded_date = pi_file_date
           AND data_centre_id = i.data_center_id;

      EXCEPTION
        WHEN OTHERS THEN
        ROLLBACK TO s_user_languages;
          -- clean the GTT
          DELETE FROM dir_list
           WHERE regexp_like(filename, 'USER_LANGUAGES(*)', 'i');
          -- drop the external table
          commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
          -- drop the directory
          commons_utils.p_drop_directory(lv_directory_name);

          IF SQLCODE = -20010 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20011 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20012 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Bad file user_languages_' || to_char(pi_file_date, 'ddmmyyyy') ||'_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad' || ' was generated for Datacentre_' ||i.data_center_id ||' on at the following path ' || lv_badroot,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSE
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Failed at p_user_languages with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          END IF;
      END;

    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                    pi_procedure_name       => lv_proc_name,
                                    pi_error_message        => 'Failed at p_user_languages with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                    pi_error_in_code        => SQLCODE,
                                    pi_tel_error_event_date => pi_file_date);
    RAISE;
  END p_user_languages;
/*
PROCEDURE p_object_used_space(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_date_value                date;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;
    

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := upper('object_used_space');
    lv_proc_name   := upper('p_object_used_space');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    FOR i IN (SELECT cdc.data_center_id
                FROM config_metric_data_centre_map cmdcm,
                     config_data_centers           cdc
               WHERE cmdcm.metric_id = lv_metric_id
                 and cmdcm.is_enabled = 'Y'
                 and cmdcm.data_centre_id = to_char(cdc.data_center_id)
                 and cdc.data_center_flag = 1) LOOP

      SAVEPOINT s_object_used_space;
      begin
        -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
        commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                           pi_file_date                  => pi_file_date,
                                           pi_v_metric_name              => lv_metric_name,
                                           pi_data_center_id             => i.data_center_id,
                                           po_v_metric_table_name        => lv_metric_table_name,
                                           po_v_view_name                => lv_view_name,
                                           po_v_metric_input_file_format => lv_metric_input_file_format,
                                           po_v_metric_input_file_path   => lv_metric_input_file_path,
                                           po_v_column_list              => lv_column_list,
                                           po_v_column_list_date         => lv_fields_list,
                                           po_v_column_datatype_list     => lv_column_datatype_list,
                                           po_v_metric_source_id         => lv_metric_source_id);

        --    --dbms_output.put_line(lv_column_datatype_list);
        --    --dbms_output.put_line(lv_directory_name);
        --    --dbms_output.put_line(lv_metric_source_id);
        --    --dbms_output.put_line(lv_metric_input_file_path);
        BEGIN
          commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
        EXCEPTION
          WHEN OTHERS THEN
            RAISE no_such_directory;
        END;

        BEGIN
          SELECT filename
            INTO lv_file_name
            FROM dir_list
           WHERE regexp_like(filename, 'object_used_space[_0-9-]*.csv$', 'i');

        EXCEPTION
          WHEN no_data_found THEN
            RAISE no_such_file;
          WHEN too_many_rows THEN

            SELECT MAX(filename)
              INTO lv_file_name
              FROM dir_list
             WHERE regexp_like(filename, 'object_used_space[_0-9-]*.csv$', 'i');

          WHEN OTHERS THEN
            RAISE;
        END;

        -- creating the directory on the specified path
        lv_directory_name := commons_utils.f_create_directory(pi_path        => lv_metric_input_file_path,
                                                              pi_metric_name => lv_metric_name);

        -- creating the external table with respect to the directory created
        commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                              pi_directory_name       => lv_directory_name,
                                              pi_file_name            => lv_file_name,
                                              pi_ext_tab_source_flag  => lv_metric_source_id,
                                              pi_fields_list          => lv_fields_list,
                                              pi_metric_name          => lv_metric_name,
                                              pi_file_date            => pi_file_date,
                                              pi_data_center          => i.data_center_id,
                                              po_external_table_name  => lv_external_table_name);

        -- get the event date from the filename to be inserted into the table
        SELECT to_date(regexp_substr(lv_file_name, '[0-9]+-[0-9]+-[0-9]+'), 'YYYY-MM-DD')
          INTO lv_date_value
          FROM dual;

        -- insertion in the specified metric table
        lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date, event_date,ENV_DATA_CENTER_ID)
                                         select ' || lv_column_list || ', CURRENT_DATE, ''' || lv_date_value || ''',' || i.data_center_id || '
                                         from ' || lv_external_table_name;

        EXECUTE IMMEDIATE lv_insert_into_central_table;
        

        commons_utils.p_get_dir_list(p_directory => lv_badroot);
        BEGIN
          SELECT count(*)
            INTO lv_badfile_cnt
            FROM dir_list
           where filename = 'object_used_space_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad';

        EXCEPTION
          WHEN OTHERS THEN
            RAISE;

        END;

        if lv_badfile_cnt > 0 then
          raise bad_file_exists;
        end if;

        -- clean the GTT
        DELETE FROM dir_list
         WHERE regexp_like(filename, 'object_used_space(*)', 'i');
        -- drop the external table
        commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
        -- drop the directory
        commons_utils.p_drop_directory(lv_directory_name);

        UPDATE table_load_metrics
           SET loaded_flag = 'Y'
         WHERE metric_id = 32
           AND loaded_date = pi_file_date
           AND data_centre_id = i.data_center_id;

      EXCEPTION
        WHEN OTHERS THEN
          ROLLBACK TO s_object_used_space;
          -- clean the GTT
          DELETE FROM dir_list
           WHERE regexp_like(filename, 'object_used_space(*)', 'i');
          -- drop the external table
          commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
          -- drop the directory
          commons_utils.p_drop_directory(lv_directory_name);

          IF SQLCODE = -20010 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20011 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSIF SQLCODE = -20012 THEN
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Bad file object_used_space_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_'||i.data_center_id||'_'|| lv_loader_seq_currval || '.bad' || ' was generated for Datacentre_' ||i.data_center_id ||' on at the following path ' || lv_badroot,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          ELSE
            commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                          pi_procedure_name       => lv_proc_name,
                                          pi_error_message        => 'Failed at p_object_used_space with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                          pi_error_in_code        => SQLCODE,
                                          pi_tel_error_event_date => pi_file_date);
          END IF;
      END;

    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                    pi_procedure_name       => lv_proc_name,
                                    pi_error_message        => 'Failed at p_object_used_space with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                    pi_error_in_code        => SQLCODE,
                                    pi_tel_error_event_date => pi_file_date);
      RAISE;
  END p_object_used_space;*/
  
PROCEDURE p_lang_per_client_count_ws(pi_file_date IN DATE) IS
    lv_insert_into_central_table CLOB;
    lv_column_list               VARCHAR2(4001 CHAR);
    lv_column_datatype_list      VARCHAR2(4001 CHAR);
    lv_fields_list               VARCHAR2(4001 CHAR);
    lv_directory_name            VARCHAR2(4001 CHAR);
    lv_file_name                 VARCHAR2(4001 CHAR);
    lv_metric_table_name         VARCHAR2(4001 CHAR);
    lv_view_name                 VARCHAR2(4001 CHAR);
    lv_metric_name               VARCHAR2(4001 CHAR);
    lv_metric_id                 VARCHAR2(4001 CHAR);
    lv_metric_input_file_format  VARCHAR2(4001 CHAR);
    lv_metric_input_file_path    VARCHAR2(4001 CHAR);
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_root                      VARCHAR2(4001 CHAR);
    lv_external_table_name       VARCHAR2(4001 CHAR);
    lv_num_processed             PLS_INTEGER;
    lv_proc_name                 VARCHAR2(4001 CHAR);
    lv_metric_source_id          PLS_INTEGER;
    lv_badroot                   VARCHAR2(4001 CHAR);
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;

    no_such_directory EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_directory, -20010);

    no_such_file EXCEPTION;
    PRAGMA EXCEPTION_INIT(no_such_file, -20011);

    bad_file_exists EXCEPTION;
    PRAGMA EXCEPTION_INIT(bad_file_exists, -20012);

  BEGIN

    lv_metric_name := Upper('Languages_Per_Client_WS');
    lv_proc_name   := Upper('p_lang_per_client_count_ws');
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_currval from dual;

    --selecting metric_id from config_metrics
    SELECT metric_id
      INTO lv_metric_id
      FROM config_metrics
     WHERE upper(metric_name) = lv_metric_name;

    -- selecting the root path from properties table
    SELECT pr_value
      INTO lv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';

    SELECT pr_value
      INTO lv_badroot
      FROM properties
     WHERE pr_name = 'Logging_path';

    -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
    commons_utils.p_get_metric_details(pi_root                       => lv_root,
                                       pi_file_date                  => pi_file_date,
                                       pi_v_metric_name              => lv_metric_name,
                                       pi_data_center_id             => null,
                                       po_v_metric_table_name        => lv_metric_table_name,
                                       po_v_view_name                => lv_view_name,
                                       po_v_metric_input_file_format => lv_metric_input_file_format,
                                       po_v_metric_input_file_path   => lv_metric_input_file_path,
                                       po_v_column_list              => lv_column_list,
                                       po_v_column_list_date         => lv_fields_list,
                                       po_v_column_datatype_list     => lv_column_datatype_list,
                                       po_v_metric_source_id         => lv_metric_source_id);

    --    --dbms_output.put_line(lv_column_datatype_list);
    --    --dbms_output.put_line(lv_directory_name);
    --    --dbms_output.put_line(lv_metric_source_id);
        --dbms_output.put_line(lv_metric_input_file_path);
    BEGIN
      commons_utils.p_get_dir_list(p_directory => lv_metric_input_file_path);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE no_such_directory;
    END;

    BEGIN
      SELECT filename
        INTO lv_file_name
        FROM dir_list
       WHERE regexp_like(filename, 'Languages_Per_Client_WS_DW_INPUT_[_0-9-]*.csv$', 'i');

    EXCEPTION
      WHEN no_data_found THEN
        RAISE no_such_file;
      WHEN too_many_rows THEN

        SELECT MAX(filename)
          INTO lv_file_name
          FROM dir_list
         WHERE regexp_like(filename, 'Languages_Per_Client_WS_DW_INPUT_[_0-9-]*.csv$', 'i');

      WHEN OTHERS THEN
        RAISE;
    END;

    -- creating the directory on the specified path
    lv_directory_name := commons_utils.f_create_directory(fi_path        => lv_metric_input_file_path,
                                                              fi_metric_name => lv_metric_name);

    -- creating the external table with respect to the directory created

    commons_utils.p_create_external_table(pi_column_datatype_list => lv_column_datatype_list,
                                          pi_directory_name       => lv_directory_name,
                                          pi_file_name            => lv_file_name,
                                          pi_ext_tab_source_flag  => lv_metric_source_id,
                                          pi_fields_list          => lv_fields_list,
                                          pi_metric_name          => lv_metric_name,
                                          pi_file_date            => pi_file_date,
                                          pi_data_center          => 'Datacentre_All',
                                          po_external_table_name  => lv_external_table_name);
    -- insertion in the specified metric table
    lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' || lv_column_list || ', insert_date,event_time)
                                     select ' || lv_column_list || ', CURRENT_DATE ,'''||pi_file_date||'''
                                     from ' || lv_external_table_name;
    --dbms_output.put_line('lv_insert_into_central_table'||lv_insert_into_central_table||chr(32)||'Directory'||lv_directory_name);                                 
    EXECUTE IMMEDIATE lv_insert_into_central_table;
    lv_num_processed := SQL%ROWCOUNT;

    commons_utils.p_get_dir_list(p_directory => lv_badroot);
    BEGIN
      SELECT count(*)
        INTO lv_badfile_cnt
        from dir_list
       where filename = 'languages_per_client_ws_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad';
       
    EXCEPTION
      WHEN OTHERS THEN
        RAISE;
    END;

    if lv_badfile_cnt > 0 then
      raise bad_file_exists;
    end if;

    -- clean the GTT
    DELETE FROM dir_list
     WHERE regexp_like(filename, 'Languages_Per_Client_WS_DW_INPUT_(*)', 'i');
    -- drop the external table
    commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
    -- drop the directory
    commons_utils.p_drop_directory(lv_directory_name);

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO s_lang_per_client_count_ws;
      -- clean the GTT
      DELETE FROM dir_list
       WHERE regexp_like(filename, 'Languages_Per_Client_WS_DW_INPUT_(*)', 'i');
      -- drop the external table
      commons_utils.p_drop_external_table(pi_table_name => lv_external_table_name);
      -- drop the directory
      commons_utils.p_drop_directory(lv_directory_name);

      IF SQLCODE = -20010 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Directory does not exist or read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20011 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = -20012 THEN
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Bad file languages_per_client_ws_' || to_char(pi_file_date, 'ddmmyyyy') || '_datacentre_datacentre_all_'|| lv_loader_seq_currval || '.bad' || ' was generated for Datacentre_All on at the following path ' || lv_badroot,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSE
        commons_utils.p_error_logging(pi_metric_id            => lv_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Failed at p_lang_per_client_count_ws with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils.f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      END IF;
      RAISE;
  END p_lang_per_client_count_ws;
  
end telemetry;
/

