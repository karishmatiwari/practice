create PACKAGE commons_utils_new AS

-- *******************************    PUBLIC TYPES CONSTANTS EXCEPTIONS START       *******************************
  gv_processing_date date; 
  gv_loggingroot commons_utils.optimizedvarchar2;   
-- *******************************    PUBLIC TYPES CONSTANTS EXCEPTIONS END         *******************************
-- *******************************    PUBLIC PROCEDURES  START       *******************************
  PROCEDURE p_SQS_metrics_wrapper(P_check_flag varchar2 default 'N');
  procedure p_load_SQS_wrapper(pin_processing_date date);
-- *******************************    PUBLIC PROCEDURES  END         *******************************

-- *******************************    PUBLIC PROCEDURES ONE TIME SETUP REQUIRED IF DB MIGRATED START       *******************************
  procedure p_create_contexts ;
-- *******************************    PUBLIC PROCEDURES ONE TIME SETUP REQUIRED IF DB MIGRATED END       *******************************
end commons_utils_new;
/

