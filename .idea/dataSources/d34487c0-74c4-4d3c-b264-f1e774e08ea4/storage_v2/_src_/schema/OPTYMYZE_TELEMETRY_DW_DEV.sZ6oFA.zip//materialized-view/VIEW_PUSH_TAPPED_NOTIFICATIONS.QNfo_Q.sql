create materialized view VIEW_PUSH_TAPPED_NOTIFICATIONS
refresh complete on demand
  as
    with dates_between as
 (select last_day(add_months(trunc(sysdate), -2)) + 1 first_date,
         last_day(add_months(trunc(sysdate), -1)) last_date
    from dual),
     max_date AS
  (SELECT MAX(EVENT_TIME) max_date
  FROM TABLE_PUSH_NOTIFICATION_TAPPED
  CROSS JOIN dates_between
  WHERE EVENT_TIME BETWEEN TRUNC(dates_between.first_date) AND TRUNC(dates_between.last_date)
  )
SELECT A.ENVIRONMENT_UUID ENVIRONMENT_UUID,
       CE.ENV_ID ENVIRONMENT_ID,
       CE.ENV_NAME ENVIRONMENT_NAME,
       CCP.CP_ID CLIENT_PROJECT_ID,
       to_char(CCP.CP_CLIENT_ID) CLIENT_ID,
       to_char(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
       ccp.cp_client_name client_name,
       CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
       to_char(max_date.max_date, 'DD-MM-YYYY') METRIC_DATE,
       TRIM(to_CHAR(max_date.max_date, 'Month')) || ' ' ||
       to_CHAR(max_date.max_date, 'YYYY') METRIC_MONTH,
       A.DEVICE_ID DEVICE_ID,
       b.notification_count,
       a.COUNT_NOTIFICATION_ID,
       (100 * (a.COUNT_NOTIFICATION_ID / b.notification_count)) Tapped_Percent
  from (SELECT count(TPNT.NOTIFICATION_ID) COUNT_NOTIFICATION_ID,
               TPNT.DEVICE_ID,
               TPNT.environment_uuid
          from TABLE_PUSH_NOTIFICATION_TAPPED TPNT
         cross join dates_between
         where trunc(TPNT.EVENT_TIME) between
               trunc(dates_between.first_date) and
               trunc(dates_between.last_date)
         group by TPNT.environment_uuid, TPNT.DEVICE_ID) A
  left join (select count(NVL(TPNU.notification_number, 0)) notification_count,
                    TPNU.DEVICE_ID
               FROM TABLE_PUSH_NOTIFICATION_UNIQUE TPNU
              cross join dates_between
              where trunc(TPNU.EVENT_TIME) between
                    trunc(dates_between.first_date) and
                    trunc(dates_between.last_date)
                and TPNU.SEND_STATUS = 'SUCCESSFUL'
              GROUP BY DEVICE_ID) B
    ON A.DEVICE_ID = B.DEVICE_ID
 cross join dates_between
 CROSS JOIN max_date
  JOIN CONFIG_ENVIRONMENTS CE
    ON A.ENVIRONMENT_UUID = CE.ENV_UUID
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON CCP.CP_ID = CE.ENV_CP_ID
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
/

