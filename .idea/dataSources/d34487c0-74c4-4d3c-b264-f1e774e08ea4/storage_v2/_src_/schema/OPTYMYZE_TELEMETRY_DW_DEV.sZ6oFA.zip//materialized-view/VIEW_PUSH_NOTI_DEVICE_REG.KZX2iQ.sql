create materialized view VIEW_PUSH_NOTI_DEVICE_REG
refresh force on demand
  as
    with dates_between as
(select last_day(add_months(trunc(sysdate), -2)) + 1 first_date,
         last_day(add_months(trunc(sysdate), -1)) last_date
    from dual)
SELECT TPNDR.ENVIRONMENT_UUID                                    ENVIRONMENT_UUID,
       CE.ENV_ID                                       ENVIRONMENT_ID,
       CE.ENV_NAME                                     ENVIRONMENT_NAME,
       CCP.CP_ID                                       CLIENT_PROJECT_ID,
        to_char(CCP.CP_CLIENT_ID)                              CLIENT_ID,
       to_char(CCP.CP_SUB_PROJECT_ID)                 SUB_PROJECT_ID,
       ccp.cp_client_name                              client_name,
       CET.ENV_TYPE_VALUE                              ENVIRONMENT_TYPE,
       to_char(dates_between.last_date, 'DD-MM-YYYY') METRIC_DATE,
       TRIM(to_CHAR(dates_between.last_date, 'Month')) ||' '||to_CHAR(dates_between.last_date, 'YYYY') METRIC_MONTH,
       DEVICE_ID                       DEVICE_ID,
count (DEVICE_ID) Active_device_COUNT
  FROM TABLE_PUSH_NOTI_DEVICE_REG TPNDR
  JOIN CONFIG_ENVIRONMENTS CE
    ON TPNDR.ENVIRONMENT_UUID = CE.ENV_UUID
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON CCP.CP_ID = CE.ENV_CP_ID
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
cross join dates_between
where trunc(EVENT_TIME) between  trunc(dates_between.first_date) and  trunc(dates_between.last_date)
group by
        TPNDR.environment_uuid         ,
        TPNDR.DEVICE_ID                ,
        CE.ENV_ID                     ,
        CE.ENV_NAME                   ,
        CCP.CP_ID                     ,
        to_char(CCP.CP_CLIENT_ID)     ,
        TO_CHAR(CCP.CP_SUB_PROJECT_ID),
        ccp.cp_client_name            ,
        CET.ENV_TYPE_VALUE            ,
        to_char(dates_between.last_date, 'DD-MM-YYYY') ,
        TRIM(to_CHAR(dates_between.last_date, 'Month')) ||' '||to_CHAR(dates_between.last_date, 'YYYY')
/

