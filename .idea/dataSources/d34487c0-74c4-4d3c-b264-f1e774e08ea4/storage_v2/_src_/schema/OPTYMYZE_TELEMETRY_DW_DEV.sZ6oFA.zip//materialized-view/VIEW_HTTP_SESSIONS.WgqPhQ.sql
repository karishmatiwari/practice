create materialized view VIEW_HTTP_SESSIONS
refresh complete on demand
  as
    with dates_between as
(select last_day(add_months(trunc(sysdate), -2)) + 1 first_date,
         last_day(add_months(trunc(sysdate), -1)) last_date
    from dual)
SELECT THS.ENVIRONMENT_UUID                                    ENVIRONMENT_UUID,
       CE.ENV_ID                                       ENVIRONMENT_ID,
       CE.ENV_NAME                                     ENVIRONMENT_NAME,
       CCP.CP_ID                                       CLIENT_PROJECT_ID,
        to_char(CCP.CP_CLIENT_ID)                              CLIENT_ID,
       to_char(CCP.CP_SUB_PROJECT_ID)                 SUB_PROJECT_ID,
       ccp.cp_client_name                              client_name,
       CET.ENV_TYPE_VALUE                              ENVIRONMENT_TYPE,
       to_char(dates_between.last_date, 'DD-MM-YYYY') METRIC_DATE,
       TRIM(to_CHAR(dates_between.last_date, 'Month')) ||' '||to_CHAR(dates_between.last_date, 'YYYY') METRIC_MONTH,
       AVG(THS.SESSIONS_COUNT) AVG_SESSIONS_COUNT ,
       max(THS.SESSIONS_COUNT) MAX_SESSIONS_COUNT
  FROM table_http_sessions THS
  JOIN CONFIG_ENVIRONMENTS CE
    ON THS.ENVIRONMENT_UUID = CE.ENV_UUID
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
cross join dates_between
where trunc(EVENT_TIME) between  trunc(dates_between.first_date) and  trunc(dates_between.last_date)
and   CE.STATUS='Y' and CCP.CP_IS_DELETED=0
group by 
       ths.environment_uuid ,
       ths.event_time,
          CE.ENV_ID  ,                   
          CE.ENV_NAME ,                  
          CCP.CP_ID                     ,
          to_char(CCP.CP_CLIENT_ID)     ,
          TO_CHAR(CCP.CP_SUB_PROJECT_ID),
          ccp.cp_client_name            ,
          CET.ENV_TYPE_VALUE        ,
           to_char(dates_between.last_date, 'DD-MM-YYYY') ,
       TRIM(to_CHAR(dates_between.last_date, 'Month')) ||' '||to_CHAR(dates_between.last_date, 'YYYY')
/

