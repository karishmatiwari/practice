create materialized view VIEW_DATA_TABLES_WS
refresh force on demand
  as
    SELECT CE.ENV_UUID ENVIRONMENT_UUID,
  CE.ENV_ID ENVIRONMENT_ID,
  CE.ENV_NAME ENVIRONMENT_NAME,
  cdc.data_center_name,
  CCP.CP_ID CLIENT_PROJECT_ID,
  CCP.CP_CLIENT_ID CLIENT_ID,
  TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
  ccp.cp_client_name client_name,
  CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
  trunc(sysdate-1) METRIC_DATE,
  TRIM(TO_CHAR(trunc(sysdate-1), 'Month'))
  ||' '
  ||TO_CHAR(trunc(sysdate-1), 'YYYY') metric_month,
  DT.DATA_TABLE_NAME,
  DT.DATA_TABLE_FOLDER_NAME,
  DT.DATA_TABLE_DESCRIPTION,
  DT.DATA_TABLE_KEY_FIELDS,
  regexp_count(DT.DATA_TABLE_KEY_FIELDS, ',')+1 KEY_FIELDS_COUNT,
  DT.NUMBER_OF_FIELDS,
  DT.NUMBER_OF_ENTITIES,
  DT.DATA_TABLE_IS_CORE,
  DT.DATA_TABLE_CREATED_DATE,
  --DT.DATA_TABLE_CREATED_BY,
  nvl(ro.login_id, DT.DATA_TABLE_CREATED_BY) DATA_TABLE_CREATED_BY,
  DT.NUMBER_OF_RECORDS,
  round((decode(Dt.Table_Size,-99999999999999999999,null,Dt.Table_Size)/1024/1024),3) Table_Size  ,         -- in MB
  round((decode(Dt.Index_Size,-99999999999999999999,NULL,Dt.Index_Size)/1024/1024),3) Index_Size,
  ce.ENV_VERSION,
       ce.release_year,
       ce.release_month,
       ce.branch_number,
       ce.build_number
FROM TABLE_DATA_TABLES_WS DT
JOIN CONFIG_ENVIRONMENTS CE
ON TRIM(DT.ENV_UUID)    = TRIM(CE.ENV_UUID)
JOIN CONFIG_CLIENT_PROJECTS CCP
ON (CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
JOIN config_data_centers cdc
ON ce.env_data_center_id = cdc.data_center_id
JOIN CONFIG_ENVIRONMENT_TYPES CET
ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
left outer join table_role_wise_user_ws ro
on to_char(ro.user_id)=dt.data_table_created_by
and trunc(ro.event_time)=TRUNC(DT.event_time)
and ro.env_uuid=dt.env_uuid
WHERE TRUNC(DT.event_time) = trunc(sysdate-1)
AND CE.STATUS='Y' and CCP.CP_IS_DELETED=0
and DT.Supported=0
/

