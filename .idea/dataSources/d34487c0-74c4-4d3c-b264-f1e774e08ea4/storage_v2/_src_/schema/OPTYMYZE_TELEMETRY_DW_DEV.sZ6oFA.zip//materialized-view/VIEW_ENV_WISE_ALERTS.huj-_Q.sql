create materialized view VIEW_ENV_WISE_ALERTS
refresh force on demand
  as
    select   outer_ce.env_uuid environment_uuid,
            fm.metric_or_group_name metric_name,
            cmv.cmv_mv_name mview_name,
           'Environment unavailable' error_message,
           trunc(sysdate - 1) METRIC_DATE,4- 1 ITERATION_NUMBER
      from config_environments_history outer_ce,
       config_materialized_views   cmv,
       table_fetch_metrics       fm
 where fm.metric_id = cmv.cmv_linked_metric_id
   and cmv.cmv_iteration_number = outer_ce.iteration_number
   and trunc(outer_ce.time_stamp) = trunc(sysdate - 1)
   and outer_ce.status = 'N'
   and trunc(fm.fetched_date) = trunc(sysdate - 2)
   and fm.fetched_flag = 2
       and not exists
     (select *
              from config_client_projects outer_cp
             where exists
             (select cp_client_id
                      from (SELECT row_number() over(partition BY cp_client_id order by NULL) rn,
                                   a.*
                              FROM config_client_projects a
                             WHERE cp_is_deleted = 0 --and cp_client_id = 336
                            )
                     inner where rn > 1
                             and inner.cp_client_id = outer_cp.cp_client_id)
               and CP_IS_DELETED = 0
               and outer_cp.cp_id = outer_ce.ENV_CP_ID)
    union all

    SELECT tel_env_id,
           tel_metric_name,
           CMV_MV_NAME,
           tel_error_message,
           trunc(sysdate - 1),
            4- 1 ITERATION_NUMBER
      FROM (SELECT er.tel_env_id,
                   er.tel_metric_name,
                   CM.CMV_MV_NAME,
                   er.tel_error_message,
                   trunc(er.tel_error_log_date),
                   row_number() over(partition BY trunc(er.tel_error_log_date), er.tel_env_id, er.tel_metric_name order by er.tel_error_log_date desc) rn
              FROM telemetry_error_logs er
              JOIN CONFIG_MATERIALIZED_VIEWS CM
              ON CM.CMV_LINKED_METRIC_ID=ER.TEL_METRIC_ID
             where trunc(er.tel_error_log_date) between trunc(sysdate - 1) and
                   trunc(sysdate)
               and er.tel_iteration_number = 4- 1
               and er.tel_procedure_name =
                   'TelemetryCsvUtility of webservices'
               and er.tel_error_code = '-20019')
     where rn = 1
/

