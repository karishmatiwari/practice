create materialized view VIEW_OPTYMYZE_VERSION
refresh force on demand
  as
    SELECT CE.ENV_UUID                                     ENVIRONMENT_UUID,
       CE.ENV_ID                                       ENVIRONMENT_ID,
       CE.ENV_NAME                                     ENVIRONMENT_NAME,
       CDC.DATA_CENTER_NAME                            DATA_CENTER_NAME,
       CCP.CP_ID                                       CLIENT_PROJECT_ID,
       to_char(CCP.CP_CLIENT_ID)                       CLIENT_ID,
       to_char(CCP.CP_SUB_PROJECT_ID)                  SUB_PROJECT_ID,
       ccp.cp_client_name                              client_name,
       CET.ENV_TYPE_VALUE                              ENVIRONMENT_TYPE,
       to_date(to_char(sysdate-1, 'DD-MM-YYYY'),'DD-MM-YYYY')  METRIC_DATE,
       TRIM(to_CHAR(sysdate, 'Month')) ||' '||to_CHAR(last_day(add_months(trunc(sysdate), -1)), 'YYYY') METRIC_MONTH,
       CE.ENV_VERSION VERSION,
       decode(substr(CE.ENV_VERSION,6,1),'0','No','Yes') SERVICE_PACK,
       ce.release_year,
       ce.release_month,
       ce.branch_number,
       ce.build_number
 FROM
  CONFIG_ENVIRONMENTS CE
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
  JOIN CONFIG_DATA_CENTERS CDC
    ON CDC.DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID
AND CE.STATUS='Y' AND CCP.CP_IS_DELETED=0
/

