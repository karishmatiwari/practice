create materialized view VIEW_USER_LANGUAGES
refresh complete on demand
  as
    WITH dates_between AS
  (SELECT last_day(add_months(TRUNC(sysdate), -2)) + 1 first_date,
    last_day(add_months(TRUNC(sysdate),       -1)) last_date
  FROM dual
  ),
max_date AS
(SELECT MAX(event_date) max_date 
FROM TABLE_USER_LANGUAGES 
cross join dates_between 
where   event_date between  trunc(dates_between.first_date) and  trunc(dates_between.last_date) 
) 
SELECT CE.ENV_UUID ENVIRONMENT_UUID,
  CE.ENV_ID ENVIRONMENT_ID,
  CE.ENV_NAME ENVIRONMENT_NAME,
  cdc.data_center_name,
  CCP.CP_ID CLIENT_PROJECT_ID,
  CCP.CP_CLIENT_ID CLIENT_ID,
  TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
  ccp.cp_client_name client_name,
  CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
  dates_between.last_date METRIC_DATE,
  TRIM(TO_CHAR(dates_between.last_date, 'Month'))
  ||' '
  ||TO_CHAR(dates_between.last_date, 'YYYY') METRIC_MONTH,
  TUL.language_name ,
  TUL.is_default_language,
  NVL(TUL.users_count,0) users_count
FROM TABLE_USER_LANGUAGES TUL
JOIN CONFIG_ENVIRONMENTS CE
ON ( TRIM(TUL.env_name)    = TRIM(CE.env_name)
AND TUL.ENV_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
JOIN CONFIG_CLIENT_PROJECTS CCP
ON ( CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID) 
JOIN config_data_centers cdc
ON ce.env_data_center_id = cdc.data_center_id
JOIN CONFIG_ENVIRONMENT_TYPES CET
ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
CROSS JOIN dates_between
cross join max_date
WHERE TRUNC(event_date) = TRUNC(max_date.max_date)
and CCP.CP_IS_DELETED=0 AND CE.STATUS ='Y'
/

