create materialized view VIEW_BACKUP_SIZE_TIME
refresh complete on demand
  as
    WITH dates_between AS
  (SELECT last_day(add_months(TRUNC(sysdate), -2)) + 1 first_date,
    last_day(add_months(TRUNC(sysdate),       -1)) last_date
  FROM dual
  ),
  max_date AS
  (SELECT MAX(event_date) max_date
  FROM table_backup_size_time
  CROSS JOIN dates_between
  WHERE event_date BETWEEN TRUNC(dates_between.first_date) AND TRUNC(dates_between.last_date)
  )
SELECT tus.uuid                               ENVIRONMENT_UUID,
       CE.ENV_ID                                       ENVIRONMENT_ID,
       CE.ENV_NAME                                     ENVIRONMENT_NAME,
       CDC.DATA_CENTER_NAME                            DATA_CENTER_NAME,
       CCP.CP_ID                              CLIENT_PROJECT_ID,
       to_char(CCP.CP_CLIENT_ID)                       CLIENT_ID,
       TO_CHAR(CCP.CP_SUB_PROJECT_ID)                  SUB_PROJECT_ID,
       ccp.cp_client_name                              client_name,
       CET.ENV_TYPE_VALUE                              ENVIRONMENT_TYPE,
       to_char(to_date(event_date, 'DD-MM-YYYY')) METRIC_DATE,
       TRIM(to_CHAR(dates_between.last_date, 'Month')) ||' '||to_CHAR(dates_between.last_date, 'YYYY') METRIC_MONTH,
       TUS.BACKUP_SIZE as BACKUP_SIZE,
       TUS.BACKUP_TIME as BACKUP_TIME
 FROM table_backup_size_time tus
  JOIN CONFIG_ENVIRONMENTS CE
    ON (TRIM(tus.uuid) = TRIM(CE.ENV_UUID))
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
     JOIN CONFIG_DATA_CENTERS CDC
    ON CDC.DATA_CENTER_ID=CE.ENV_DATA_CENTER_ID
cross join dates_between
CROSS JOIN max_date
WHERE TRUNC(event_date) = TRUNC(max_date.max_date)
and CE.STATUS='Y' and CCP.CP_IS_DELETED=0
/

