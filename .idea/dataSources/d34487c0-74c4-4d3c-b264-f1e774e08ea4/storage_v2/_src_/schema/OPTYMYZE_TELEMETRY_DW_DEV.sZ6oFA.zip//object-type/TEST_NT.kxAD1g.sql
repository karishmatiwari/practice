create TYPE                             "TEST_NT" is table of my_obj;
/

