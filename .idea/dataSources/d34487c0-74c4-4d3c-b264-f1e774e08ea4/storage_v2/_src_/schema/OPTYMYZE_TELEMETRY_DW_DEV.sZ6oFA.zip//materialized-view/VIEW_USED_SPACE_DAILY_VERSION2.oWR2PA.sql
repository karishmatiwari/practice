create materialized view VIEW_USED_SPACE_DAILY_VERSION2
refresh complete on demand
  as
    select
a.ENVIRONMENT_UUID,ENVIRONMENT_ID,ENVIRONMENT_NAME,DATA_CENTER_NAME,CLIENT_PROJECT_ID,CLIENT_ID,SUB_PROJECT_ID,CLIENT_NAME,ENVIRONMENT_TYPE,METRIC_DATE,METRIC_MONTH,DB_TOTAL_ALLOCATED_SPACE,DB_USED_SIZE,PROJECT_FILE_ALLOCATED_SPACE,PROJECT_FILE_USED_SIZE,PROJECT_FILE_FREE_SIZE,CONTRACTUAL_SPACE,BILLABLE_SPACE,metric_event_date
  from
  (SELECT tus.PROJECT_UUID ENVIRONMENT_UUID,
      CE.ENV_ID ENVIRONMENT_ID,
      CE.ENV_NAME ENVIRONMENT_NAME,
      CDC.DATA_CENTER_NAME DATA_CENTER_NAME,
      CCP.CP_ID CLIENT_PROJECT_ID,
    TO_CHAR(CCP.CP_CLIENT_ID) CLIENT_ID,
      TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
      ccp.cp_client_name client_name,
      CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
      TO_CHAR(to_Date(trunc(sysdate-1)),'dd-Mon-yyyy') METRIC_DATE,
     TRIM(TO_CHAR(sysdate   - 1, 'Month'))
    ||' '
      ||TO_CHAR(sysdate - 1, 'YYYY') METRIC_MONTH,
    tus.db_total_allocated_space db_total_allocated_space,
    tus.project_file_allocated_space project_file_allocated_space,
      tus.project_file_used_size project_file_used_size,
    tus.project_file_free_size project_file_free_size,
    tus.contractual_space contractual_space,
    trunc(sysdate-1) metric_event_date
  FROM TABLE_USED_SPACE tus
  JOIN CONFIG_ENVIRONMENTS CE
  ON (TRIM(tus.PROJECT_UUID) = TRIM(CE.ENV_UUID))
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID )
  JOIN CONFIG_ENVIRONMENT_TYPES CET
  ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
    JOIN CONFIG_DATA_CENTERS CDC
  ON CDC.DATA_CENTER_ID   =CE.ENV_DATA_CENTER_ID
    WHERE TRUNC(event_date) = TRUNC(sysdate-1)
  AND CE.STATUS           ='Y' and CCP.CP_IS_DELETED=0
  ) A  left outer join
    (
    SELECT ENV_UUID ENVIRONMENT_UUID,
            trunc(event_date) event_date,
              sum(decode(substr(TDPV.TABLESPACE_NAME,-4,4), '_MTD', TDPV.NO_OF_BYTES_IN_TABLESPACE,'_DTS', TDPV.NO_OF_BYTES_IN_TABLESPACE, '_IND', TDPV.NO_OF_BYTES_IN_TABLESPACE,'_OUT', TDPV.NO_OF_BYTES_IN_TABLESPACE,0))/(1024*1024*1024) DB_USED_SIZE,
              sum(decode(substr(TDPV.TABLESPACE_NAME,-4,4), '_MTD', TDPV.NO_OF_BYTES_IN_TABLESPACE,'_DTS', TDPV.NO_OF_BYTES_IN_TABLESPACE, '_IND', TDPV.NO_OF_BYTES_IN_TABLESPACE,0))/(1024*1024*1024)  Billable_space
      --      sum(decode(substr(TABLESPACE_NAME,-3,3), 'OUT', -TDPV.NO_OF_BYTES_IN_TABLESPACE,TDPV.NO_OF_BYTES_IN_TABLESPACE))/(1024*1024*1024)  Billable_space_09
              FROM TABLE_DATA_PROCESSED_VOLUME TDPV JOIN CONFIG_ENVIRONMENTS CE
          ON (TRIM(TDPV.ENV_NAME) = TRIM(CE.ENV_NAME))
            where  TRUNC(event_date)  =TRUNC(SYSDATE-1)
            and decode(substr(TABLESPACE_NAME,-8,4), '_SPM',1,'_PAR',1,'_RDS',1,'_EDD',1,'_OA_',1,'_PLA',1,0) =1
              AND CE.STATUS           ='Y'
            group by ENV_UUID,trunc(event_date)
      ) B
on (A.ENVIRONMENT_UUID = B.ENVIRONMENT_UUID and trunc(to_date(A.METRIC_DATE)) = B.event_date )
/

