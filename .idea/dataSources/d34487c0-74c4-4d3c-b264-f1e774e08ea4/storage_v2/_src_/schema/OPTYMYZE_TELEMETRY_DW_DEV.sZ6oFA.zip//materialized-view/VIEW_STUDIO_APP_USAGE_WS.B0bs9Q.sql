create materialized view VIEW_STUDIO_APP_USAGE_WS
refresh force on demand
  as
    SELECT Y.ENVIRONMENT_UUID, Y.ENVIRONMENT_ID, Y.ENVIRONMENT_NAME, Y.data_center_name, Y.CLIENT_PROJECT_ID, Y.CLIENT_ID, Y.SUB_PROJECT_ID,
       Y.client_name, Y.ENVIRONMENT_TYPE, Y.METRIC_DATE, Y.metric_month, Y.login_id, Y.studio_app_name, Y.app_item_name, Y.app_item_label, Y.page_name,
       Y.page_label, Y.date_time, Y.visit_count FROM
(SELECT x.*,
       ROW_NUMBER() OVER(PARTITION BY x.ENVIRONMENT_UUID, x.ENVIRONMENT_ID, x.ENVIRONMENT_NAME, x.data_center_name, x.CLIENT_PROJECT_ID, x.CLIENT_ID, x.SUB_PROJECT_ID,
       x.client_name, x.ENVIRONMENT_TYPE, x.login_id, x.studio_app_name, x.app_item_name, x.app_item_label, x.page_name,
       x.page_label, x.date_time ORDER BY x.INSERT_DATE DESC) rn from
    (SELECT CE.ENV_UUID ENVIRONMENT_UUID,
       CE.ENV_ID ENVIRONMENT_ID,
       CE.ENV_NAME ENVIRONMENT_NAME,
       cdc.data_center_name,
       CCP.CP_ID CLIENT_PROJECT_ID,
       CCP.CP_CLIENT_ID CLIENT_ID,
       TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
       ccp.cp_client_name client_name,
       CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
       trunc(SAU.date_time) METRIC_DATE,
       TRIM(TO_CHAR(trunc(SAU.date_time), 'Month')) || ' ' ||
       TO_CHAR(trunc(SAU.date_time), 'YYYY') metric_month,
       SAU.login_id,
       SAU.studio_app_name,
       SAU.app_item_name,
       SAU.app_item_label,
       SAU.page_name,
       SAU.page_label,
       trunc(SAU.date_time) date_time,
       trunc(sau.insert_date) insert_date,
       count(1) visit_count
  FROM TABLE_STUDIO_APP_USAGE_WS SAU
  JOIN CONFIG_ENVIRONMENTS CE
    ON TRIM(SAU.ENV_UUID) = TRIM(CE.ENV_UUID)
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID and
       ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
  JOIN config_data_centers cdc
    ON ce.env_data_center_id = cdc.data_center_id
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
 WHERE TRUNC(SAU.date_time) = trunc(sysdate - 2)
   AND CE.STATUS = 'Y'
   and CCP.CP_IS_DELETED = 0
   and SAU.Supported = 0
 group by CE.ENV_UUID,
          CE.ENV_ID,
          CE.ENV_NAME,
          cdc.data_center_name,
          CCP.CP_ID,
          CCP.CP_CLIENT_ID,
          TO_CHAR(CCP.CP_SUB_PROJECT_ID),
          ccp.cp_client_name,
          CET.ENV_TYPE_VALUE,
          SAU.login_id,
          SAU.studio_app_name,
          SAU.app_item_name,
          SAU.app_item_label,
          SAU.page_name,
          SAU.page_label,
          trunc(SAU.date_time),
          trunc(sau.insert_date))x) Y where rn=1
/

