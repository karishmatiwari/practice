create materialized view VIEW_OBJECT_USAGE_WS
refresh complete on demand
  as
    with dates_between as
(select NEXT_DAY(sysdate, 'MONDAY') - 14 first_date,
       NEXT_DAY(sysdate, 'SUNDAY') - 7 last_date
  from dual),
max_date as
(select max(event_time) max_date from TABLE_OBJECT_USAGE_WS cross join dates_between where  event_time <= trunc(dates_between.last_date))
SELECT CE.ENV_UUID                               ENVIRONMENT_UUID,
       CE.ENV_ID                                       ENVIRONMENT_ID,
       CE.ENV_NAME                                     ENVIRONMENT_NAME,
       CCP.CP_ID                                       CLIENT_PROJECT_ID,
       CCP.CP_CLIENT_ID                                CLIENT_ID,
       to_char(CCP.CP_SUB_PROJECT_ID)                 SUB_PROJECT_ID,
       ccp.cp_client_name                              client_name,
     --  CET.ENV_TYPE_VALUE                              ENVIRONMENT_TYPE,
       to_char(dates_between.last_date, 'DD-MM-YYYY') METRIC_DATE,
       TRIM(to_CHAR(dates_between.last_date, 'Month')) ||' '||to_CHAR(dates_between.last_date, 'YYYY') METRIC_MONTH,
    TABLE_INTERNAL_NAME,
     TABLE_NAME,
      TABLE_BUSINESS_NAME,
       TABLE_TYPE,
       INDEX_SIZE,
       TABLE_SIZE
  FROM(
SELECT  ENV_UUID,
ENV_ID,
  ENV_NAME,
   SUPPORTED,
    TABLE_INTERNAL_NAME,
     TABLE_NAME,
      TABLE_BUSINESS_NAME,
       TABLE_TYPE,
       INDEX_SIZE,
       TABLE_SIZE,
       EVENT_TIME
        FROM (
SELECT
ENV_UUID,
ENV_ID,
  ENV_NAME,
   SUPPORTED,
    TABLE_INTERNAL_NAME,
     TABLE_NAME,
      TABLE_BUSINESS_NAME,
       TABLE_TYPE,
       TRUNC(EVENT_TIME),
        replace( replace (CATEGORY,'LOBINDEX','INDEX'),'NESTED TABLE','TABLE')DBA_CATEGORY,
        SUM(SPACE_OCCUPIED) SPACE_OCCUPIED,
TRUNC(EVENT_TIME) EVENT_TIME
FROM TABLE_OBJECT_USAGE_WS
  group by
  ENV_UUID, ENV_ID, ENV_NAME, SUPPORTED,
 TRUNC(EVENT_TIME),
TABLE_INTERNAL_NAME,
TABLE_NAME,
TABLE_BUSINESS_NAME,
TABLE_TYPE,
replace( replace (CATEGORY,'LOBINDEX','INDEX'),'NESTED TABLE','TABLE'))RES_IN
 PIVOT
(
  sum(RES_IN.SPACE_OCCUPIED)
  FOR DBA_CATEGORY IN ('INDEX' as INDEX_SIZE,'TABLE' as TABLE_SIZE)) )RES_OUT
   JOIN CONFIG_ENVIRONMENTS CE
    ON (TRIM(RES_OUT.ENV_UUID) = TRIM(CE.ENV_UUID))
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON CCP.CP_ID = CE.ENV_CP_ID
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
   cross join dates_between
cross join max_date
where trunc(RES_OUT.event_time) = trunc(max_date.max_date)
/

