create materialized view VIEW_UNIQUE_USERS
refresh complete on demand
  as
    with dates_between as
(select last_day(add_months(trunc(sysdate), -2)) + 1 first_date,
         last_day(add_months(trunc(sysdate), -1)) last_date
    from dual),
max_date as
(select max(event_time) max_date from table_parallel_session cross join dates_between where  event_time <= trunc(dates_between.last_date) )
SELECT tps.environment_uuid                            ENVIRONMENT_UUID,
       CE.ENV_ID                                       ENVIRONMENT_ID,
       CE.ENV_NAME                                     ENVIRONMENT_NAME,
       CDC.DATA_CENTER_NAME                            DATA_CENTER_NAME,
       CCP.CP_ID                              CLIENT_PROJECT_ID,
       to_char(CCP.CP_CLIENT_ID)                       CLIENT_ID,
       TO_CHAR(CCP.CP_SUB_PROJECT_ID)                  SUB_PROJECT_ID,
       ccp.cp_client_name                              client_name,
       CET.ENV_TYPE_VALUE                              ENVIRONMENT_TYPE,
       to_char(to_date(event_time, 'DD-MM-YYYY')) METRIC_DATE,
       TRIM(to_CHAR(dates_between.last_date, 'Month')) ||' '||to_CHAR(dates_between.last_date, 'YYYY') METRIC_MONTH,
       tps.user_id                  USER_ID,       
       count(*)                                     USER_COUNT
     
 FROM table_parallel_session tps
  JOIN CONFIG_ENVIRONMENTS CE
    ON (TRIM(tps.environment_uuid) = TRIM(CE.ENV_UUID))
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
     JOIN CONFIG_DATA_CENTERS CDC
    ON CDC.DATA_CENTER_ID=CE.ENV_DATA_CENTER_ID
cross join dates_between
cross join max_date
where event_time between dates_between.first_date and dates_between.last_date AND tps.EVENT_TYPE=1 and CE.STATUS='Y' and CCP.CP_IS_DELETED=0
group by  tps.environment_uuid ,tps.user_id,
          CE.ENV_ID  ,                   
          CE.ENV_NAME ,                  
          CDC.DATA_CENTER_NAME          ,
          CCP.CP_ID                     ,
          to_char(CCP.CP_CLIENT_ID)     ,
          TO_CHAR(CCP.CP_SUB_PROJECT_ID),
          ccp.cp_client_name            ,
          CET.ENV_TYPE_VALUE        ,
           to_char(to_date(event_time, 'DD-MM-YYYY')) ,
         TRIM(to_CHAR(dates_between.last_date, 'Month')) ||' '||to_CHAR(dates_between.last_date, 'YYYY')
/

