create procedure LOAD_TEST( P_check_flag in varchar2)
as

begin
for i in 1 ..1000
loop
insert into TEST_LOAD
values (i,'name_'||i);
end loop;
commit;
end ;
/

