create procedure p_create_table( pi_metric_id IN config_metrics.metric_id%type )
  is
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Creates the table 
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
      lv_execute_ddl commons_utils.maxvarchar2;
      lv_external_tab_column_list  commons_utils.optimizedvarchar2;
      lv_staging_tab_column_list   commons_utils.optimizedvarchar2;
      lv_ext_tab_col_nam_datatype  commons_utils.optimizedvarchar2;
      lv_access_parameter_col_list commons_utils.optimizedvarchar2;
      lv_directory_name            commons_utils.optimizedvarchar2;
      lv_file_name                 commons_utils.optimizedvarchar2;
      lv_metric_table_name         commons_utils.optimizedvarchar2;
      lv_view_name                 commons_utils.optimizedvarchar2;
      lv_metric_name               commons_utils.optimizedvarchar2;
      lv_metric_input_file_path    commons_utils.optimizedvarchar2;
      lv_proc_name                 commons_utils.optimizedvarchar2;
      lv_metric_source_id          PLS_INTEGER;
      lv_badfile_cnt               PLS_INTEGER;
      lv_loader_seq_currval        PLS_INTEGER;
      lv_csv_file_name             commons_utils.optimizedvarchar2;
      lv_bad_file_name             commons_utils.optimizedvarchar2;
      lv_external_tab_name         commons_utils.optimizedvarchar2;
      lv_field_delimiter           commons_utils.optimizedvarchar2;
      lv_data_centre_id            commons_utils.optimizedvarchar2;
  
      lv_metric_table_nam commons_utils.optimizedvarchar2;
      lv_staging_tab_col_nam_datatyp commons_utils.optimizedvarchar2;
      lv_check number;
      ex_invalid_metric_name exception;
      pragma exception_init(ex_invalid_metric_name,-20011);
  begin
  lv_proc_name := 'p_create_table';
  lv_loader_seq_currval := 1;
  lv_data_centre_id :='Datacentre_All';
  
          -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
          commons_utils.p_fetch_metric_details(pi_root                       => commons_utils.gv_root,
                                               pi_file_date                  => trunc(sysdate-1),
                                               pi_metric_id                  => pi_metric_id,
                                               pi_data_center_id             => lower(lv_data_centre_id),
                                               pi_loader_seq_currval         => lv_loader_seq_currval,
                                               pi_attach_string_to_filenam   => 'NOT REQUIRED',
                                               po_metric_table_name        => lv_metric_table_name,
                                               po_view_name                => lv_view_name,
                                               po_metric_input_file_path   => lv_metric_input_file_path,
                                               po_external_tab_column_list => lv_external_tab_column_list,
                                               po_staging_tab_column_list  => lv_staging_tab_column_list,
                                               po_access_parameter_col_list=> lv_access_parameter_col_list,
                                               po_ext_tab_col_nam_datatype => lv_ext_tab_col_nam_datatype,
                                               po_staging_tab_col_nam_datatyp=>lv_staging_tab_col_nam_datatyp ,
                                               po_metric_source_id         => lv_metric_source_id,
                                               po_csv_file_name            => lv_csv_file_name,
                                               po_bad_file_name            => lv_bad_file_name,
                                               po_metric_external_table_nam => lv_external_tab_name,
                                               po_metric_name               => lv_metric_name,
                                               po_metric_default_dir_name =>lv_directory_name,
                                               po_field_delimiter           => lv_field_delimiter);
  
       lv_execute_ddl:= q'$ CREATE TABLE $'||lv_metric_table_name||q'$ ( $'||lv_staging_tab_col_nam_datatyp||q'$ )$';
       execute immediate lv_execute_ddl;
       dbms_output.put_line(lv_execute_ddl);
  exception
  when others then
  null;
--          commons_utils.p_error_logging(pi_metric_id            => pi_metric_id,
--                                        pi_procedure_name       => lv_proc_name,
--                                        pi_error_message        => 'Failed at '||lv_proc_name||' for metric '||lv_metric_name|| ' with error :- ' || SQLERRM || 'Backtraced: ' || f_get_exception_backtrace,
--                                        pi_error_in_code        => SQLCODE,
--                                        pi_tel_error_event_date => pi_file_date);
                                        raise;
  
  end p_create_table;
/

