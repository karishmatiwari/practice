create TYPE                             "TY_CONFIG_DATA_CENTERS" is table of obj_config_data_centers ;
/

