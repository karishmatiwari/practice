create PROCEDURE p_job_delete_fetch_sqs_metrics IS
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Wrapper procedure that deletes jobs that are required for fetching application metrics
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    exists_cnt pls_integer;
  BEGIN

    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_PROGRAMS
    WHERE PROGRAM_NAME = 'FETCH_SQS_METRIC_PROG';

    IF exists_cnt      =1 THEN
      dbms_scheduler.drop_program('FETCH_SQS_METRIC_PROG',TRUE);
    end if;

    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_JOBS a
    WHERE JOB_NAME = 'FETCH_SQS_METRIC_JOB';

    IF exists_cnt  =1 THEN
        dbms_scheduler.drop_job('FETCH_SQS_METRIC_JOB',TRUE);
    END IF;

  END p_job_delete_fetch_sqs_metrics;
/

