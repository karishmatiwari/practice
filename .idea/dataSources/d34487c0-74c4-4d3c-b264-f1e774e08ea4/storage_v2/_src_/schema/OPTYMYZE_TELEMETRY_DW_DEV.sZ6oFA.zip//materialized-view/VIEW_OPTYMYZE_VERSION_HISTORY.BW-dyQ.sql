create materialized view VIEW_OPTYMYZE_VERSION_HISTORY
refresh force on demand
  as
    SELECT ENVIRONMENT_UUID, ENVIRONMENT_ID, ENVIRONMENT_NAME, DATA_CENTER_NAME, CLIENT_PROJECT_ID, CLIENT_ID, SUB_PROJECT_ID, CLIENT_NAME, ENVIRONMENT_TYPE, METRIC_DATE, METRIC_MONTH, VERSION, SERVICE_PACK,
  TO_NUMBER(SUBSTR(VERSION,1,INSTR(VERSION,'.',1,1)-1)) RELEASE_YEAR , 
  TO_NUMBER(SUBSTR(VERSION,INSTR(VERSION,'.',1,1)+1,INSTR(VERSION,'.',1,2)-1-(INSTR(VERSION,'.',1,1)-1)-1)) RELEASE_MONTH , 
	TO_NUMBER(SUBSTR(VERSION,INSTR(VERSION,'.',1,2)+1,INSTR(VERSION,'.',1,3)-1-(INSTR(VERSION,'.',1,2)-1)-1))  BRANCH_NUMBER, 
	TO_NUMBER(SUBSTR(VERSION,INSTR(VERSION,'.',1,3)-LENGTH(VERSION)))  BUILD_NUMBER FROM (

SELECT B.*,row_number()  OVER ( partition by
ENVIRONMENT_NAME, CLIENT_PROJECT_ID, CLIENT_ID, SUB_PROJECT_ID, CLIENT_NAME, ENVIRONMENT_TYPE,VERSION order by decode (DATA_CENTER_NAME,'TCS','1','AWS - Ireland','2'))ROWNUMBER_1 FROM (

SELECT a.*,row_number()  OVER ( partition by
ENVIRONMENT_NAME, CLIENT_PROJECT_ID, CLIENT_ID, SUB_PROJECT_ID, CLIENT_NAME, ENVIRONMENT_TYPE, EXTRACT(month FROM METRIC_DATE)
order by decode (DATA_CENTER_NAME,'TCS','1','AWS - Ireland','2') ) ROWNUMBER_2
FROM (
select
distinct First_Value(environment_uuid) OVER (PARTITION BY
DECODE(environment_name,'AlconProd_snd2','Alcon_snd2'
,'JJVisionCareProd','JJVisionCare'
,'JJVisionCareProd_snd','JJVisionCare_snd'
,'USCC','USCCO1'
,'USCC2','USCCO2'
,'USCC_snd','USCCO1_snd'
,'USCC2_snd','USCCO2_snd'
,'AdventSnd','Advent_snd'
,'AlconProd','Alcon'
,'AlconProd_snd','Alcon_snd'
,'BIVIPROD','BIVI'
,'BIVIPROD_snd','BIVI_snd',environment_name) ORDER BY METRIC_DATE_inner desc
    RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) environment_uuid,
          ENVIRONMENT_ID,
          DECODE(environment_name,'AlconProd_snd2','Alcon_snd2'
,'JJVisionCareProd','JJVisionCare'
,'JJVisionCareProd_snd','JJVisionCare_snd'
,'USCC','USCCO1'
,'USCC2','USCCO2'
,'USCC_snd','USCCO1_snd'
,'USCC2_snd','USCCO2_snd'
,'AdventSnd','Advent_snd'
,'AlconProd','Alcon'
,'AlconProd_snd','Alcon_snd'
,'BIVIPROD','BIVI'
,'BIVIPROD_snd','BIVI_snd',environment_name) environment_name,
          DATA_CENTER_NAME,
          CLIENT_PROJECT_ID,
          CLIENT_ID,
          SUB_PROJECT_ID,
          client_name,
          ENVIRONMENT_TYPE,
          to_date(to_char(METRIC_DATE_inner, 'DD-MM-YYYY'), 'DD-MM-YYYY') METRIC_DATE,
          METRIC_MONTH,
          version,
          SERVICE_PACK FROM
          (
SELECT CE.ENV_UUID                                     ENVIRONMENT_UUID,
       CE.ENV_ID                                       ENVIRONMENT_ID,
      /* CE.ENV_NAME*/ DECODE(CE.ENV_NAME,'AlconProd_snd2','Alcon_snd2'
,'JJVisionCareProd','JJVisionCare'
,'JJVisionCareProd_snd','JJVisionCare_snd'
,'USCC','USCCO1'
,'USCC2','USCCO2'
,'USCC_snd','USCCO1_snd'
,'USCC2_snd','USCCO2_snd'
,'AdventSnd','Advent_snd'
,'AlconProd','Alcon'
,'AlconProd_snd','Alcon_snd'
,'BIVIPROD','BIVI'
,'BIVIPROD_snd','BIVI_snd',CE.ENV_NAME)                                    ENVIRONMENT_NAME,
       CDC.DATA_CENTER_NAME                            DATA_CENTER_NAME,
       CCP.CP_ID                                       CLIENT_PROJECT_ID,
       to_char(CCP.CP_CLIENT_ID)                       CLIENT_ID,
       to_char(CCP.CP_SUB_PROJECT_ID)                  SUB_PROJECT_ID,
    /* ccp.cp_client_name*/  DECODE (ccp.cp_client_name,
    'Nestl¿¿ Nespresso SA','Nespresso',
'BCBSMA','BCBSMA'
,'Franklin Templeton Companies','Franklin_ProdEnv'
,'ONSemiconductor','ONSemiconductor'
,'GECVC','GECVC'
,'Alcon','Alcon'
,'Sunovion Pharmaceuticals, Inc.','Sunovion Pharmaceuticals, Inc.'
,'Advent Software, Inc.','Advent'
,'Desjardins','Desjardins'
,'United States Cellular Corp','USCC'
,'JJVisionCare','JohnsonAndJohnson'
,'Boehringer Ingelheim','BIVI',
'Dun & Bradstreet, Inc.','DnB',
'Lincoln Financial Group','LincolnFG',
'PC Connection, Inc.','Connection',
'Robert W. Baird & Co.','RWBaird'
,ccp.cp_client_name) client_name                          ,
       CET.ENV_TYPE_VALUE                              ENVIRONMENT_TYPE,
       METRIC_DATE METRIC_DATE_inner,
       TRIM(to_CHAR(METRIC_DATE, 'Month')) ||' '||to_CHAR(METRIC_DATE, 'YYYY') METRIC_MONTH,
       substr(tefs.APP_NAME,regexp_instr(tefs.APP_NAME,'[[:digit:]]')) version,
     decode(substr(substr(tefs.APP_NAME,regexp_instr(tefs.APP_NAME,'[[:digit:]]')),6,1),'0','No','Yes') SERVICE_PACK,
       coalesce(Max(substr(tefs.APP_NAME,regexp_instr(tefs.APP_NAME,'[[:digit:]]')))
       over (partition by /*CE.ENV_UUID,CE.ENV_ID,*/  DECODE(CE.ENV_NAME,'AlconProd_snd2','Alcon_snd2'
,'JJVisionCareProd','JJVisionCare'
,'JJVisionCareProd_snd','JJVisionCare_snd'
,'USCC','USCCO1'
,'USCC2','USCCO2'
,'USCC_snd','USCCO1_snd'
,'USCC2_snd','USCCO2_snd'
,'AdventSnd','Advent_snd'
,'AlconProd','Alcon'
,'AlconProd_snd','Alcon_snd'
,'BIVIPROD','BIVI'
,'BIVIPROD_snd','BIVI_snd',CE.ENV_NAME)/*,CDC.DATA_CENTER_NAME*/ ,CCP.CP_ID,  to_char(CCP.CP_CLIENT_ID),to_char(CCP.CP_SUB_PROJECT_ID),
DECODE (ccp.cp_client_name,
'Nestl¿¿ Nespresso SA','Nespresso'
,'BCBSMA','BCBSMA'
,'Franklin Templeton Companies','Franklin_ProdEnv'
,'ONSemiconductor','ONSemiconductor'
,'GECVC','GECVC'
,'Alcon','Alcon'
,'Sunovion Pharmaceuticals, Inc.','Sunovion Pharmaceuticals, Inc.'
,'Advent Software, Inc.','Advent'
,'Desjardins','Desjardins'
,'United States Cellular Corp','USCC'
,'JJVisionCare','JohnsonAndJohnson'
,'Boehringer Ingelheim','BIVI',
'Dun & Bradstreet, Inc.','DnB',
'Lincoln Financial Group','LincolnFG',
'PC Connection, Inc.','Connection',
'Robert W. Baird & Co.','RWBaird',ccp.cp_client_name) , CET.ENV_TYPE_VALUE, DATA_CENTER_NAME
       order by METRIC_DATE,/*substr(tefs.APP_NAME,regexp_instr(tefs.APP_NAME,'[[:digit:]]'))*/
to_number(replace(replace(substr(tefs.APP_NAME,regexp_instr(tefs.APP_NAME,'[[:digit:]]')),regexp_substr(substr(tefs.APP_NAME,regexp_instr(tefs.APP_NAME,'[[:digit:]]')),'[^.]+$'),''),'.',''))  rows between 1 PRECEDING and 1 preceding),'-99.9.9.999') rn
FROM
  (
  select  TRUNC(TPS.EVENT_TIME) METRIC_DATE,TPS.ENVIRONMENT_UUID,TPS.APP_NAME
  from table_http_sessions TPS
  where TRUNC(EVENT_TIME) is not null  --and ENVIRONMENT_UUID= '7a28ca4f-b27d-4347-bf09-d8907fa783ef'
  group by TRUNC(EVENT_TIME),ENVIRONMENT_UUID,APP_NAME
--  union all
--  select to_date('22-06-2017','dd-mm-yyyy') ,'7a28ca4f-b27d-4347-bf09-d8907fa783ef','optymyze-17.5.0.461'
--from dual
 ) TEFS
  JOIN CONFIG_ENVIRONMENTS CE
    ON TRIM(TEFS.ENVIRONMENT_UUID) = TRIM(CE.ENV_UUID)
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
  JOIN CONFIG_DATA_CENTERS CDC
    ON CDC.DATA_CENTER_ID = CE.ENV_DATA_CENTER_ID
    order by metric_date) where rn<> version
    )A )B) WHERE ROWNUMBER_1=1
/

