create materialized view VIEW_ROLES_AND_FEATURES_WS
refresh force on demand
  as
    SELECT CE.ENV_UUID ENVIRONMENT_UUID,
       CE.ENV_ID ENVIRONMENT_ID,
       CE.ENV_NAME ENVIRONMENT_NAME,
       cdc.data_center_name,
       CCP.CP_ID CLIENT_PROJECT_ID,
       CCP.CP_CLIENT_ID CLIENT_ID,
       TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
       ccp.cp_client_name client_name,
       CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
       trunc(sysdate - 1) METRIC_DATE,
       TRIM(TO_CHAR(trunc(sysdate - 1), 'Month')) || ' ' ||
       TO_CHAR(trunc(sysdate - 1), 'YYYY') metric_month,
       RF.ROLE_NAME,
       RF.ACCESS_CATEGORY,
       RF.APP_GROUP,
       RF.FEATURE_MODE,
       RF.FEATURE_NAME,
       RF.VISUALIZATION,
       RF.AGREEMENTS,
       RF.FOLDERS,
       trim(regexp_substr(RF.APP_MENU_ITEM_NAME,
                                  '[^,]+',
                                  1,
                                  levels.column_value)) APP_ITEM_NAME,
       -- RF.APP_MENU_ITEM_NAME APP_ITEM_NAME,
       RF.STUDIO_APP_NAME,
       RF.ROLE_STATUS
  FROM TABLE_ROLES_AND_FEATURES_WS RF
  join TABLE(CAST(multiset (SELECT level
                              FROM dual
                            CONNECT BY level <=
                                       LENGTH(regexp_replace(RF.APP_MENU_ITEM_NAME,
                                                             '[^,]+')) + 1) AS sys.OdciNumberList)) levels
    on 1 = 1
  JOIN CONFIG_ENVIRONMENTS CE
    ON TRIM(RF.ENV_UUID) = TRIM(CE.ENV_UUID)
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID and
       ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
  JOIN config_data_centers cdc
    ON ce.env_data_center_id = cdc.data_center_id
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
 WHERE TRUNC(RF.event_time) = trunc(sysdate - 1)
   AND CE.STATUS = 'Y'
   and CCP.CP_IS_DELETED = 0
   and RF.Supported = 0
/

