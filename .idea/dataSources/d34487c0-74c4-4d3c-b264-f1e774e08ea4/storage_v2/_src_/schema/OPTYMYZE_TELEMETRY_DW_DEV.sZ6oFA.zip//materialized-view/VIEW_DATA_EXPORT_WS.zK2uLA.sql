create materialized view VIEW_DATA_EXPORT_WS
refresh force on demand
  as
    SELECT DISTINCT CE.ENV_UUID ENVIRONMENT_UUID,
  CE.ENV_ID ENVIRONMENT_ID,
  CE.ENV_NAME ENVIRONMENT_NAME,
  cdc.data_center_name,
  CCP.CP_ID CLIENT_PROJECT_ID,
  CCP.CP_CLIENT_ID CLIENT_ID,
  TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
  ccp.cp_client_name client_name,
  CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
  trunc(sysdate-1) METRIC_DATE,
  TRIM(TO_CHAR(trunc(sysdate-1), 'Month'))
  ||' '
  ||TO_CHAR(trunc(sysdate-1), 'YYYY') metric_month,
  DE.DATA_EXPORT_NAME,
  DE.DATA_EXPORT_FOLDER_NAME,
  DE.DATA_EXPORT_PROCESSING_PERIOD,
  DE.DATA_EXPORT_PARENT_NAME DATA_EXPORT_TYPE_CATEGORY,
  DE.DATA_EXPORT_INPUT_TABLE_TYPE,
  DE.DATA_EXPORT_INPUT_TABLE,
  DE.DATA_EXPORT_OUTPUT_FILE,
  DE.DATA_EXPORT_OUTPUT_TYPE,
  DE.DATA_EXPORT_LAST_RUN_DATE,
  DE.DATA_EXPORT_CREATED_DATE,
  --DE.DATA_EXPORT_CREATED_BY,
  nvl(ro.login_id,DE.DATA_EXPORT_CREATED_BY) DATA_EXPORT_CREATED_BY,
  DE.DATA_EXPORT_PROCESS_ID,
  ce.ENV_VERSION,
       ce.release_year,
       ce.release_month,
       ce.branch_number,
       ce.build_number
FROM TABLE_DATA_EXPORT_WS DE
JOIN CONFIG_ENVIRONMENTS CE
ON TRIM(DE.ENV_UUID)    = TRIM(CE.ENV_UUID)
JOIN CONFIG_CLIENT_PROJECTS CCP
ON (CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
JOIN config_data_centers cdc
ON ce.env_data_center_id = cdc.data_center_id
JOIN CONFIG_ENVIRONMENT_TYPES CET
ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
left outer join table_role_wise_user_ws ro
on to_char(ro.user_id)=de.data_export_created_by
and trunc(ro.event_time)=TRUNC(de.event_time)
and ro.env_uuid=de.env_uuid
WHERE TRUNC(DE.event_time) = trunc(sysdate-1)
AND CE.STATUS='Y' and CCP.CP_IS_DELETED=0
and DE.Supported=0
/

