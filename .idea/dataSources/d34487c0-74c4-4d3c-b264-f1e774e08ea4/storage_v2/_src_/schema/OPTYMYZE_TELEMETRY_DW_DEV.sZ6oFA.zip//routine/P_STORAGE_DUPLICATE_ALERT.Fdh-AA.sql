create procedure p_storage_duplicate_alert as
SUBTYPE optimizedvarchar2 IS VARCHAR2(4001);
V_event_time DATE;
LV_ERROR_SHORT_NAME optimizedvarchar2;
    LV_MAIL_STARTS      optimizedvarchar2;
    Lv_Mail_Ends        optimizedvarchar2;
    LV_MAIL_DYNAMIC_TABLE     CLOB;
    lv_mail_data     clob;
    lv_mail_general_error_dyn clob;
    lv_mail_comb_body         clob;
    LV_MAIL_BODY        clob;
    LV_MAIL_SUBJECT     optimizedvarchar2;
    lv_mail_id          NUMBER;
    LV_SENDER_EMAIL_ID  optimizedvarchar2;
    lv_to_email_ids     optimizedvarchar2;
    LV_CC_EMAIL_IDS     optimizedvarchar2;
    LV_BCC_EMAIL_IDS    optimizedvarchar2;
    LV_METRIC_NAME      optimizedvarchar2;
    LV_ERROR_NAME      optimizedvarchar2;
    lv_cma_notify_iteration_number   pls_integer;
    LV_LOADED_FLAG      PLS_INTEGER;
    HEADER_LINE VARCHAR2(4000);
  LINE VARCHAR2(4000);
  FID UTL_FILE.FILE_TYPE ;
  ATTACH_CONTENT VARCHAR2(32767);
  v_att_filename VARCHAR2(4000);
BEGIN
EXECUTE IMMEDIATE 'alter session set nls_date_format = ''dd-Mon-yy''';
V_event_time := trunc(SYSDATE)-1;   

-----insert data into storage_duplicate_summary for CSV generation of duplicate records

FOR K IN (
   SELECT 'databaseSpaceTotalCombined' metric_name, '''''' device , 'DB_SPACE_TOTAL_COMB' size_value, v_event_time event_time , 0 status, 'TABLE_DB_SPACE_TOTAL_COMB_PR' table_name FROM dual
UNION ALL
SELECT 'databaseSpaceFreeCombined' metric_name, '''''' device , 'DB_SPACE_FREE_COMB' size_value, v_event_time event_time , 0 status, 'TABLE_DB_SPACE_FREE_COMB_PR' table_name FROM dual
UNION ALL
SELECT 'osSpaceTotal' metric_name, '''''' device , 'OS_SPACE_TOTAL' size_value, v_event_time event_time , 0 status, 'TABLE_OS_SPACE_TOTAL_PR' table_name FROM dual
UNION ALL
SELECT 'osSpaceFree' metric_name, '''''' device , 'OS_SPACE_FREE' size_value, v_event_time event_time , 0 status, 'TABLE_OS_SPACE_FREE_PR' table_name FROM dual
UNION ALL
SELECT 'environmentSpaceTotal' metric_name, 'O.DEVICE' device , 'ENV_SPACE_TOTAL' size_value, v_event_time event_time , 0 status, 'TABLE_ENV_SPACE_TOTAL_PR' table_name FROM dual
UNION ALL
SELECT 'environmentSpaceFree' METRIC_NAME, 'O.DEVICE' DEVICE , 'ENV_SPACE_FREE' SIZE_VALUE, v_event_time EVENT_TIME , 0 STATUS, 'TABLE_ENV_SPACE_FREE_PR' TABLE_NAME FROM DUAL
)
loop


execute immediate 'INSERT INTO storage_duplicate_summary (metric_name ,server , device , size_value , event_time ,status,
					env_uuid,ENVIRONMENT_ID,ENVIRONMENT_NAME,DATA_CENTER_NAME,CLIENT_PROJECT_ID,CLIENT_ID,SUB_PROJECT_ID,CLIENT_NAME,ENVIRONMENT_TYPE )
SELECT '''||k.metric_name||''' metric_name, i.server, '||k.device||' device,'||k.size_value||' size_value,'''||v_event_time||''' event_time,0 status,
	   CE.ENV_UUID ENVIRONMENT_UUID,
       CE.ENV_ID ENVIRONMENT_ID,
       CE.ENV_NAME ENVIRONMENT_NAME,
       cdc.data_center_name,
       CCP.CP_ID CLIENT_PROJECT_ID,
       CCP.CP_CLIENT_ID CLIENT_ID,
       TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
       ccp.cp_client_name client_name,
       CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE
FROM '||k.table_name||' o JOIN
(SELECT SERVER FROM '||k.table_name||' WHERE trunc(event_time) ='''||v_event_time||'''
GROUP BY SERVER
HAVING count(1)>1
) i
on i.server=o.server
JOIN CONFIG_ENVIRONMENTS CE
on i.server=ENV_SPM_SERVER_NAME
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID AND
       ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID) 
    JOIN config_data_centers cdc
    ON ce.env_data_center_id = cdc.data_center_id
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
    WHERE  trunc(event_time) ='''||v_event_time||'''
    AND status=''Y''
   AND CCP.CP_IS_DELETED = 0';
   
   

execute immediate 'INSERT INTO STORAGE_MISSING_ENV_SUMMARY(METRIC_NAME,ENV_UUID,SERVER,EVENT_TIME,STATUS,ENVIRONMENT_ID,ENVIRONMENT_NAME,DATA_CENTER_NAME,CLIENT_PROJECT_ID,CLIENT_ID,SUB_PROJECT_ID,CLIENT_NAME,ENVIRONMENT_TYPE)
SELECT  '''||k.metric_name||''' METRIC_NAME, CE.ENV_UUID ENVIRONMENT_UUID,
         CE.ENV_SPM_SERVER_NAME SERVER,
         '''||v_event_time||''' EVENT_TIME,
         0 status,
       CE.ENV_ID ENVIRONMENT_ID,
       CE.ENV_NAME ENVIRONMENT_NAME,
       cdc.data_center_name,
       CCP.CP_ID CLIENT_PROJECT_ID,
       CCP.CP_CLIENT_ID CLIENT_ID,
       TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
       ccp.cp_client_name client_name,
       CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE
       FROM CONFIG_ENVIRONMENTS CE    
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID AND
       ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
    JOIN config_data_centers cdc
    ON ce.env_data_center_id = cdc.data_center_id
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
   WHERE ce.STATUS=''Y''
   AND CCP.CP_IS_DELETED = 0
   AND NOT EXISTS (SELECT 1 FROM  '||k.table_name||' T
   where  T.SERVER= CE.ENV_SPM_SERVER_NAME
   AND TRUNC(T.EVENT_TIME) = '''||v_event_time||''')'; 
   dbms_output.put_line('INSERT INTO STORAGE_MISSING_ENV_SUMMARY(METRIC_NAME,ENV_UUID,SERVER,EVENT_TIME,STATUS,ENVIRONMENT_ID,ENVIRONMENT_NAME,DATA_CENTER_NAME,CLIENT_PROJECT_ID,CLIENT_ID,SUB_PROJECT_ID,CLIENT_NAME,ENVIRONMENT_TYPE)
SELECT  '''||k.metric_name||''' METRIC_NAME, CE.ENV_UUID ENVIRONMENT_UUID,
         CE.ENV_SPM_SERVER_NAME SERVER,
         '''||v_event_time||''' EVENT_TIME,
         0 status,
       CE.ENV_ID ENVIRONMENT_ID,
       CE.ENV_NAME ENVIRONMENT_NAME,
       cdc.data_center_name,
       CCP.CP_ID CLIENT_PROJECT_ID,
       CCP.CP_CLIENT_ID CLIENT_ID,
       TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
       ccp.cp_client_name client_name,
       CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE
       FROM CONFIG_ENVIRONMENTS CE    
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID AND
       ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
    JOIN config_data_centers cdc
    ON ce.env_data_center_id = cdc.data_center_id
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
   WHERE ce.STATUS=''Y''
   AND CCP.CP_IS_DELETED = 0
   AND NOT EXISTS (SELECT 1 FROM  TABLE_ENV_SPACE_FREE_PR T
   where  T.SERVER= CE.ENV_SPM_SERVER_NAME
   AND TRUNC(T.EVENT_TIME) = '''||v_event_time||''')');

END loop;

INSERT INTO STORAGE_DUPLICATE_SUMMARY (METRIC_NAME ,server , DEVICE , SIZE_VALUE , EVENT_TIME ,STATUS,
			env_uuid,ENVIRONMENT_ID,ENVIRONMENT_NAME,DATA_CENTER_NAME,CLIENT_PROJECT_ID,CLIENT_ID,SUB_PROJECT_ID,CLIENT_NAME,ENVIRONMENT_TYPE )
SELECT 'backupStorageSize' metric_name, ce.ENV_SPM_SERVER_NAME server, '' device,backup_storage_size size_value,v_event_time event_time,0 status,
			i.env_uuid,
       CE.ENV_ID ENVIRONMENT_ID,
       CE.ENV_NAME ENVIRONMENT_NAME,
       cdc.data_center_name,
       CCP.CP_ID CLIENT_PROJECT_ID,
       CCP.CP_CLIENT_ID CLIENT_ID,
       TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
       ccp.cp_client_name client_name,
       CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE
FROM TABLE_BACKUP_STORAGE_SIZE_WS O JOIN
(SELECT env_uuid FROM TABLE_BACKUP_STORAGE_SIZE_WS WHERE trunc(event_time) =v_event_time
GROUP BY ENV_UUID
HAVING count(1)>1
) i
on i.env_uuid=o.env_uuid
JOIN CONFIG_ENVIRONMENTS CE
on i.env_uuid=ce.env_uuid
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID AND
       ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID) 
    JOIN config_data_centers cdc
    ON ce.env_data_center_id = cdc.data_center_id
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
    WHERE  trunc(event_time) =v_event_time
    AND CE.STATUS='Y'
   AND CCP.CP_IS_DELETED = 0;
   
   
INSERT INTO STORAGE_MISSING_ENV_SUMMARY(METRIC_NAME,ENV_UUID,SERVER,EVENT_TIME,STATUS,ENVIRONMENT_ID,ENVIRONMENT_NAME,DATA_CENTER_NAME,CLIENT_PROJECT_ID,CLIENT_ID,SUB_PROJECT_ID,CLIENT_NAME,ENVIRONMENT_TYPE)
SELECT  'backupStorageSize' METRIC_NAME, CE.ENV_UUID ENVIRONMENT_UUID,
         CE.ENV_SPM_SERVER_NAME SERVER,
         TRUNC(SYSDATE - 1) EVENT_TIME,
         0 status,
       CE.ENV_ID ENVIRONMENT_ID,
       CE.ENV_NAME ENVIRONMENT_NAME,
       cdc.data_center_name,
       CCP.CP_ID CLIENT_PROJECT_ID,
       CCP.CP_CLIENT_ID CLIENT_ID,
       TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
       ccp.cp_client_name client_name,
       CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE
       FROM CONFIG_ENVIRONMENTS CE    
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID AND
       ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
    JOIN config_data_centers cdc
    ON ce.env_data_center_id = cdc.data_center_id
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
   WHERE ce.STATUS='Y'
   AND CCP.CP_IS_DELETED = 0
   AND NOT EXISTS (SELECT 1 FROM  TABLE_BACKUP_STORAGE_SIZE_WS T
   WHERE  T.ENV_UUID= CE.ENV_UUID
   and TRUNC(t.EVENT_TIME) = v_event_time);
   
   

----mail creation part
BEGIN 
EXECUTE IMMEDIATE 'alter session set nls_date_format = ''dd-Mon-yy''';
  LV_MAIL_STARTS     :='<!doctype html> <html> <head> <style type="text/css"> .error { border-collapse: collapse;width: 90%;border:1px solid #00bfff;}    .error td {border:1px solid #00bfff;border-right:1px solid #00bfff;}    .table {border-collapse: collapse;border:1px solid #00bfff;width: 90%;}th, td {border:0px;text-align: left;padding: 5px;}   th {border:1px solid #00bfff;background-color: #bbe9f9;}.thsub {background-color: #d8f5ff;border-collapse: collapse;} .thsub2 {background-color: #f7fcff;}body{font-family:cambria ;font-size:14px;} </style> </head> <body> <table align="center" class="table"> <tr> <td> Hello, <br><br>Please find below metric summary for which we are getting multiple entries. <br><br>';
  LV_MAIL_ENDS       :='</td> </tr> <tr > <td style="background-color: white">The query details used for the above metrics are available on: https://confluence.optymyze.net/display/CSA/Prometheus+queries+used+for+Storage+metrics <br><br><br> Regards, <br> Client Analytics Alerts</td> </table> </body> </html> ';
  lv_mail_subject    :='Client Analytics Alerts: Duplicate records in Storage metrics(Prometheus) on ' || TO_CHAR(v_event_time,'DD-Mon-YYYY');
  LV_SENDER_EMAIL_ID :='telemetry_alert@optymyze.com';
  LV_MAIL_DYNAMIC_TABLE:=LV_MAIL_DYNAMIC_TABLE||'<br><table align="center" class="error"><tr class="thsub"><td nowrap><b>Metric Name</b></td><td nowrap><b>Number Of Environments With Duplicates</b></td></tr>';
   FOR I IN (SELECT * FROM (
SELECT METRIC_NAME, EVENT_TIME,COUNT(DISTINCT ENV_UUID)ENV_COUNT_WITH_DUPLICATE_VALUE FROM STORAGE_DUPLICATE_SUMMARY WHERE EVENT_TIME= V_EVENT_TIME
GROUP BY METRIC_NAME,EVENT_TIME)
   )
   LOOP
   lv_mail_data:=lv_mail_data||'<TR  class="thsub2"  ><TD nowrap>'||i.METRIC_NAME||'</TD> <TD nowrap>'||i.ENV_COUNT_WITH_DUPLICATE_VALUE||'</TD> </TR>';
   END LOOP;
   if lv_mail_data is not null then
   LV_MAIL_DYNAMIC_TABLE:=LV_MAIL_DYNAMIC_TABLE|| lv_mail_data ||'</table>';
  LV_MAIL_BODY :=LV_MAIL_STARTS || LV_MAIL_DYNAMIC_TABLE || LV_MAIL_ENDS ;
  
  
-----------ATTACHMENT CREATION START
BEGIN

  --FID := UTL_FILE.FOPEN ('STORAGEMETRIC', 'STORAGE_METRICS_'||TO_CHAR(V_EVENT_TIME,'DD-MM-YYYY')||'.csv', 'W');
  HEADER_LINE:= 'METRIC_NAME'||','||'ENV_UUID'||','||'SERVER' || ',' || 'SIZE' ;
  UTL_FILE.PUT_LINE (FID, HEADER_LINE);
   FOR  OL IN (SELECT * FROM STORAGE_DUPLICATE_SUMMARY WHERE TRUNC(EVENT_TIME)=V_EVENT_TIME ORDER BY METRIC_NAME)
  LOOP

  LINE:= OL.METRIC_NAME||','||OL.ENV_UUID||','||OL.SERVER || ',' || OL.SIZE_VALUE ;
  attach_content:=attach_content|| line||chr(10);
  --UTL_FILE.PUT_LINE (FID, LINE);
        END LOOP;
ATTACH_CONTENT:= HEADER_LINE||CHR(10)||ATTACH_CONTENT;
v_att_filename := 'STORAGE_METRICS_'||TO_CHAR(V_EVENT_TIME,'DD-MM-YYYY')||'.csv' ;
    --UTL_FILE.FCLOSE (FID);
  END;

-----------ATTACHMENT CREATION END
    ELSE 
    LV_MAIL_BODY :='<!doctype html> <html> <head> <style type="text/css"> .error { border-collapse: collapse;width: 90%;border:1px solid #00bfff;}    .error td {border:1px solid #00bfff;border-right:1px solid #00bfff;}    .table {border-collapse: collapse;border:1px solid #00bfff;width: 90%;}th, td {border:0px;text-align: left;padding: 5px;}   th {border:1px solid #00bfff;background-color: #bbe9f9;}.thsub {background-color: #d8f5ff;border-collapse: collapse;} .thsub2 {background-color: #f7fcff;}body{font-family:cambria ;font-size:14px;} </style> </head> <body> <table align="center" class="table"> <tr> <td> Hello! <br><br>There is no duplicate for storage metrics.<br><br></td> </tr> <tr > <td style="background-color: white">Regards, <br> Client Analytics Alerts</td> </table> </body> </html> ';
    ATTACH_CONTENT:='';
    V_ATT_FILENAME:='';
       END IF;

	 --UTL_MAIL.SEND( SENDER=>LV_SENDER_EMAIL_ID, RECIPIENTS=>'ahmed@optymyze.com', CC=>'', BCC=>'', SUBJECT=> LV_MAIL_SUBJECT, MESSAGE=> LV_MAIL_BODY, MIME_TYPE =>'text/html', PRIORITY =>3, REPLYTO =>NULL );
   
BEGIN
  UTL_MAIL.send_attach_varchar2 (
    SENDER       => LV_SENDER_EMAIL_ID,
    RECIPIENTS   => 'ahmed@optymyze.com',
    cc           => '',
    BCC          => '',
    subject      => LV_MAIL_SUBJECT,
    MESSAGE      => LV_MAIL_BODY,
    MIME_TYPE =>'text/html',
    ATTACHMENT   => ATTACH_CONTENT,
    att_filename =>  v_att_filename 
  );
END;
   END;    
     
END;
/

