create materialized view VIEW_TERRITORY_METADATA_WS
refresh force on demand
  as
    SELECT CE.ENV_UUID ENVIRONMENT_UUID,
       CE.ENV_ID ENVIRONMENT_ID,
       CE.ENV_NAME ENVIRONMENT_NAME,
       cdc.data_center_name,
       CCP.CP_ID CLIENT_PROJECT_ID,
       CCP.CP_CLIENT_ID CLIENT_ID,
       TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
       ccp.cp_client_name client_name,
       CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
       trunc(TM.event_time) METRIC_DATE,
       TRIM(TO_CHAR(trunc(TM.event_time), 'Month')) || ' ' ||
       TO_CHAR(trunc(TM.event_time), 'YYYY') metric_month,
       TM.TERRITORY_DEFINITION_ID,
       TM.TERRITORY_DEFINITION_NAME,
       TM.TERRITORY_FREQUENCY,
       TM.TERRITORY_HIERARCHY,
       TM.TERRITORY_ENTITY,
       TM.SALES_ENTITY,
       TM.TERRITORY_SALES_ASSIGNMENT,
       TM.ADDITIONAL_ENTITIES,
       TM.TERRITORY_USERS_ASSIGNMENTS,
       --TM.PERFORMANCE_DATA_TABLES,
       case
         when length(TM.PERFORMANCE_DATA_TABLES) > 1300 then
          substr(TM.PERFORMANCE_DATA_TABLES,
                 1,
                 instr(substr(TM.PERFORMANCE_DATA_TABLES, 1, 1300), ',', -1) - 1)
         else
          TM.PERFORMANCE_DATA_TABLES
       end PERFORMANCE_DATA_TABLES1,
       case
         when length(TM.PERFORMANCE_DATA_TABLES) > 1300 then
          substr(TM.PERFORMANCE_DATA_TABLES,
                 instr(substr(TM.PERFORMANCE_DATA_TABLES, 1, 1300), ',', -1) + 1,
                 1300)
         else
          null
       end PERFORMANCE_DATA_TABLES2,
       TM.TERRITORY_BOUNDARIES,
       ce.ENV_VERSION,
       ce.release_year,
       ce.release_month,
       ce.branch_number,
       ce.build_number
  FROM TABLE_TERRITORY_METADATA_WS TM
  JOIN CONFIG_ENVIRONMENTS CE
    ON TRIM(TM.ENV_UUID) = TRIM(CE.ENV_UUID)
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID and
       ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
  JOIN config_data_centers cdc
    ON ce.env_data_center_id = cdc.data_center_id
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
 WHERE TRUNC(TM.event_time) = trunc(sysdate - 1)
   AND CE.STATUS = 'Y'
   and CCP.CP_IS_DELETED = 0
   and TM.supported = 0
/

