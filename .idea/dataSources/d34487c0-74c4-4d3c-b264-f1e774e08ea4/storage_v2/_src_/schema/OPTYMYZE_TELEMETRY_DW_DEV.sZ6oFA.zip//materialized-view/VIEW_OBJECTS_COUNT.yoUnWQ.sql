create materialized view VIEW_OBJECTS_COUNT
refresh complete on demand
  as
    with dates_between as (select last_day(add_months(trunc(sysdate), -2)) + 1 first_date,
                                      last_day(add_months(trunc(sysdate), -1)) last_date
                                 from dual),

max_date as
(select max(event_date) max_date from table_OBJECTS_COUNT cross join dates_between where   event_date between  trunc(dates_between.first_date) and  trunc(dates_between.last_date) )
SELECT distinct ce.env_uuid ENVIRONMENT_UUID,
       ce.env_id ENVIRONMENT_ID,
       TOC.ENVIRONMENT_NAME ENVIRONMENT_NAME,
       CDC.DATA_CENTER_NAME DATA_CENTER_NAME,
       ccp.cp_id CLIENT_PROJECT_ID,
      to_char( CCP.CP_CLIENT_ID)  CLIENT_ID,
       to_char(CCP.CP_SUB_PROJECT_ID)  SUB_PROJECT_ID,
       ccp.cp_client_name CLIENT_Name,
       CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
       to_char(dates_between.last_date, 'DD-MM-YYYY') METRIC_DATE,
     TRIM(to_CHAR(dates_between.last_date, 'Month')) ||' '||to_CHAR(dates_between.last_date, 'YYYY') METRIC_MONTH,
      TOC.DEFINITION_TYPE  ,
      TOC.OBJECT_COUNT
           from TABLE_OBJECTS_COUNT TOC
           join config_environments ce
             on (TOC.environment_name = ce.env_name and toc.ENV_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
           join config_client_projects ccp
             on (ce.env_cp_id = ccp.cp_id and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
           join config_environment_types cet
             on cet.env_type_id = ce.env_env_type_id
        JOIN CONFIG_DATA_CENTERS CDC
    ON CDC.DATA_CENTER_ID = CE.ENV_DATA_CENTER_ID
    cross join dates_between
cross join max_date
where trunc(event_date) = trunc(max_date.max_date)
and   CE.STATUS='Y' and CCP.CP_IS_DELETED=0
/

