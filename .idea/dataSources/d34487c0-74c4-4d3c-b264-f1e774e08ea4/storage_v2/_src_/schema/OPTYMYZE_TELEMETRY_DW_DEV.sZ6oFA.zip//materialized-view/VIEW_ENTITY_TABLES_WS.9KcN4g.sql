create materialized view VIEW_ENTITY_TABLES_WS
refresh force on demand
  as
    SELECT CE.ENV_UUID ENVIRONMENT_UUID,
  CE.ENV_ID ENVIRONMENT_ID,
  CE.ENV_NAME ENVIRONMENT_NAME,
  cdc.data_center_name,
  CCP.CP_ID CLIENT_PROJECT_ID,
  CCP.CP_CLIENT_ID CLIENT_ID,
  TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
  ccp.cp_client_name client_name,
  CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
  trunc(sysdate-1) METRIC_DATE,
  TRIM(TO_CHAR(trunc(sysdate-1), 'Month'))
  ||' '
  ||TO_CHAR(trunc(sysdate-1), 'YYYY') metric_month,
  ENT.ENTITY_TABLE_NAME,
  ENT.ENTITY_TABLE_FOLDER_NAME,
  ENT.ENTITY_TABLE_KEY_FIELDS,
  ENT.NUMBER_OF_FIELDS,
  ENT.ENTITY_TABLE_IS_CORE,
  ENT.ENTITY_TABLE_CREATED_DATE,
  nvl(ro.login_id,ENT.ENTITY_TABLE_CREATED_BY) ENTITY_TABLE_CREATED_BY,
  --ENT.ENTITY_TABLE_CREATED_BY,
  ENT.NUMBER_OF_RECORDS,
  round((decode(ent.Table_Size,'-99999999999999999999',NULL,ent.Table_Size)/1024/1024),3) Table_Size ,
  round((decode(ent.index_size,'-99999999999999999999',NULL,ent.index_size)/1024/1024),3) Index_size,   --- in MB
  ce.ENV_VERSION,
  ce.release_year,
  ce.release_month,
  ce.branch_number,
  ce.build_number
  FROM TABLE_ENTITY_TABLES_WS ENT
JOIN CONFIG_ENVIRONMENTS CE
ON TRIM(ENT.ENV_UUID)    = TRIM(CE.ENV_UUID)
JOIN CONFIG_CLIENT_PROJECTS CCP
ON (CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
JOIN config_data_centers cdc
ON ce.env_data_center_id = cdc.data_center_id
JOIN CONFIG_ENVIRONMENT_TYPES CET
ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
left outer join table_role_wise_user_ws ro
on to_char(ro.user_id)=ent.entity_table_created_by
and trunc(ro.event_time)=TRUNC(ENT.event_time)
and ro.env_uuid=ent.env_uuid
WHERE TRUNC(ENT.event_time) = trunc(sysdate-1)
AND CE.STATUS='Y' and CCP.CP_IS_DELETED=0
AND ent.supported=0
/

