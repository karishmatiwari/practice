create TYPE                             "MY_OBJ" is object ( a number , b varchar2(1000));
/

