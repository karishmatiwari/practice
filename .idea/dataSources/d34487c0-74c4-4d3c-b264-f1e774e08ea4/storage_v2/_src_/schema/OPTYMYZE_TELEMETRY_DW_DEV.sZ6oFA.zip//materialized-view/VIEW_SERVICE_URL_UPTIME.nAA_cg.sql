create materialized view VIEW_SERVICE_URL_UPTIME
refresh complete on demand
  as
    with dates_between as
(select last_day(add_months(trunc(sysdate), -2)) + 1 first_date,
         last_day(add_months(trunc(sysdate), -1)) last_date
    from dual)
select
   ce.env_name ENVIRONMENT_NAME,
   ce.env_uuid ENVIRONMENT_UUID,
   ce.env_id ENVIRONMENT_ID,
   CDC.DATA_CENTER_NAME DATA_CENTER_NAME,
   ccp.cp_id CLIENT_PROJECT_ID,
   CCP.CP_CLIENT_ID CLIENT_ID,
   ccp.cp_sub_project_id SUB_PROJECT_ID,
   ccp.cp_client_name CLIENT_Name,
   CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
   to_char(dates_between.last_date, 'DD-MM-YYYY') METRIC_DATE,
   TRIM(to_CHAR(dates_between.last_date, 'Month')) || ' ' ||
   to_CHAR(dates_between.last_date, 'YYYY') METRIC_MONTH,
   TSUU.EVENT_DATE EVENT_DATE,
   TSUU.UPTIME_PERCENT UPTIME_PERCENT,
   TSUU.DOWNTIME_PERCENT DOWNTIME_PERCENT,
   TSUU.STATUS STATUS
  from TABLE_SERVICE_URL_UPTIME TSUU
inner join config_environments CE
on ce.env_name = TSUU.PROJECT_NAME
inner join config_data_centers cdc
    on ce.env_data_center_id = cdc.data_center_id
inner join config_client_projects CCP
    on (ce.env_cp_id = ccp.cp_id and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
inner join config_environment_types cet
    on ce.env_env_type_id = cet.env_type_id
inner join config_farms cf
    on ce.env_farm_id = cf.farm_id
cross join dates_between
where TRUNC(TSUU.EVENT_DATE) BETWEEN TRUNC(dates_between.first_date) and TRUNC(dates_between.last_date)
and ce.status = 'Y' and CCP.CP_IS_DELETED=0 AND CF.STATUS='Y'
/

