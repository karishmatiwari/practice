create PROCEDURE p_job_create_load_mv_Sqs
    IS
      exists_cnt pls_integer;
    BEGIN

        SELECT COUNT(1)
        INTO exists_cnt
        FROM USER_SCHEDULER_SCHEDULES
        WHERE schedule_name = 'TWO_AM_SCHEDULE';
        --------------create schedule-----------------
        IF exists_cnt =0 
        THEN
        DBMS_SCHEDULER.CREATE_SCHEDULE (SCHEDULE_NAME   => 'TWO_AM_SCHEDULE',
                                        REPEAT_INTERVAL => 'FREQ=DAILY; BYHOUR=2,3; BYMINUTE=0,30',
                                        START_DATE      => TRUNC(sysdate),
                                        COMMENTS        => '4 half-hourly schedules for 2AM,2:30AM,3AM,3:30AM');
        END IF;

        SELECT COUNT(1)
        INTO exists_cnt
        FROM USER_SCHEDULER_programs
        WHERE PROGRAM_NAME = 'SQS_METRIC_LOAD_MV_SQS_PROG';
        --------------create program----------------- 
        IF exists_cnt=0 
        THEN
        DBMS_SCHEDULER.CREATE_PROGRAM ( PROGRAM_NAME        => 'SQS_METRIC_LOAD_MV_SQS_PROG',
                                        PROGRAM_TYPE        =>'STORED_PROCEDURE',
                                        PROGRAM_ACTION      => 'LOAD_TEST',---WRAPPER need to be changed *************
                                        ENABLED             => FALSE,
                                        NUMBER_OF_ARGUMENTS => 1,
                                        COMMENTS            => 'This would load all the sqs metrics to the database and refresh mv'
                                       );
        DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT(PROGRAM_NAME      => 'SQS_METRIC_LOAD_MV_SQS_PROG',
                                               ARGUMENT_POSITION => 1,
                                               ARGUMENT_NAME     => 'P_check_flag',
                                               ARGUMENT_TYPE     => 'VARCHAR2',
                                               DEFAULT_VALUE     => 'Y');
                                               
        DBMS_SCHEDULER.ENABLE(NAME =>'SQS_METRIC_LOAD_MV_SQS_PROG' );

        END IF;

        SELECT COUNT(1)
        INTO exists_cnt
        FROM USER_SCHEDULER_jobs a
        WHERE JOB_NAME = 'SQS_METRIC_LOAD_MV_SQS_JOB';
        --------------create job----------------- 
        IF exists_cnt  =0 
        THEN
        DBMS_SCHEDULER.CREATE_JOB(JOB_NAME      => 'SQS_METRIC_LOAD_MV_SQS_JOB',
                                  PROGRAM_NAME  => 'SQS_METRIC_LOAD_MV_SQS_PROG',
                                  SCHEDULE_NAME => 'TWO_AM_SCHEDULE',
                                  ENABLED       => true,
                                  AUTO_DROP     => false,
                                  COMMENTS      => 'This job will run the SQS_METRIC_LOAD_MV_SQS_PROG program according to the 3am_SCHEDULE schedule.');

        END IF;
        
    END p_job_create_load_mv_Sqs;
/

