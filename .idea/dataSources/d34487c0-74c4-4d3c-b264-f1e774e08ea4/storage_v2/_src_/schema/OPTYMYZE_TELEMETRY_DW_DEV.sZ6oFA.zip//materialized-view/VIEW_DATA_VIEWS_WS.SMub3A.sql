create materialized view VIEW_DATA_VIEWS_WS
refresh force on demand
  as
    SELECT CE.ENV_UUID ENVIRONMENT_UUID,
  CE.ENV_ID ENVIRONMENT_ID,
  CE.ENV_NAME ENVIRONMENT_NAME,
  cdc.data_center_name,
  CCP.CP_ID CLIENT_PROJECT_ID,
  CCP.CP_CLIENT_ID CLIENT_ID,
  TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
  ccp.cp_client_name client_name,
  CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
  trunc(ST.EVENT_TIME) METRIC_DATE,
  TRIM(TO_CHAR(trunc(ST.EVENT_TIME), 'Month'))
  ||' '
  ||TO_CHAR(trunc(ST.EVENT_TIME), 'YYYY') metric_month,
ST.DATA_VIEW_NAME,
ST.APP_MENU_ITEM,
ST.FIELDS_COUNT,
ST.FILTER_SORT_COUNT,
ST.TABLE_TYPE,
ST.TABLE_NAME,
DECODE (ST.TABLE_TYPE_FLAG,1,'TABLE',2,'VIEW',3,'SYNONYM') TABLE_TYPE_FLAG,
ST.TABLE_ROWS,
    to_char(trim(regexp_substr(ST.ROLES_WITH_ACCESS,
                                  '[^,]+',
                                  1,
                                  levels.column_value))) ROLES_WITH_ACCESS,
ST.DATA_VIEW_CREATED_DATE,
ST.DATA_VIEW_FIELD_COUNT,
ST.TABLE_ENTITY_COUNT,
ST.DATA_VIEW_ENTITY_COUNT DATA_VIEW_ENTITY_COLUMN_COUNT,
round(((decode(ST.TABLE_TYPE_FLAG, 2 , (DECODE(ST.TABLE_ROWS,0,131072,
              (ST.TABLE_ROWS*CE.A_ROW_BYTE_VAL)))  , ST.BYTES_READ))/1024/1024),3) BYTES_READ,
ST.DATA_VIEW_PARENT_NAME DATA_VIEW_TYPE_CATEGORY,
ST.DATA_VIEW_TOTAL_FIELD_COUNT,
ST.DATA_VIEW_UNIQUE_ENTITY_COUNT,
ST.DATA_VIEW_UNIQUE_ENTITY_NAME,
ST.DATA_VIEW_ID,
ce.ENV_VERSION,
  ce.release_year,
  ce.release_month,
  ce.branch_number,
  ce.build_number
  FROM TABLE_DATA_VIEWS_WS ST
  join TABLE(CAST(multiset (SELECT level
                              FROM dual
                            CONNECT BY level <=
                                       LENGTH(regexp_replace(ST.ROLES_WITH_ACCESS,
                                                             '[^,]+')) + 1) AS sys.OdciNumberList)) levels
                                                            on 1=1
JOIN CONFIG_ENVIRONMENTS CE
ON TRIM(ST.ENV_UUID)    = TRIM(CE.ENV_UUID)
JOIN CONFIG_CLIENT_PROJECTS CCP
ON (CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
JOIN config_data_centers cdc
ON ce.env_data_center_id = cdc.data_center_id
JOIN CONFIG_ENVIRONMENT_TYPES CET
ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
WHERE TRUNC(ST.EVENT_TIME) = TRUNC(SYSDATE-1)
AND CE.STATUS='Y' AND CCP.CP_IS_DELETED=0
/

