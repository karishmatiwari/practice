create materialized view VIEW_STUDIO_ITEM_PAGES_WS
refresh force on demand
  as
    SELECT CE.ENV_UUID ENVIRONMENT_UUID,
       CE.ENV_ID ENVIRONMENT_ID,
       CE.ENV_NAME ENVIRONMENT_NAME,
       cdc.data_center_name,
       CCP.CP_ID CLIENT_PROJECT_ID,
       CCP.CP_CLIENT_ID CLIENT_ID,
       TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
       ccp.cp_client_name client_name,
       CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
       trunc(sysdate - 1) METRIC_DATE,
       TRIM(TO_CHAR(trunc(sysdate - 1), 'Month')) || ' ' ||
       TO_CHAR(trunc(sysdate - 1), 'YYYY') metric_month,
       SAI.app_name,
       SAI.app_label,
       SAI.app_item_name,
       SAI.app_item_label,
       to_char(trim(regexp_substr(SAI.app_item_roles,
                                  '[^,]+',
                                  1,
                                  levels.column_value))) app_item_roles,
       --SAI.app_item_roles,
       SAI.app_item_creation_date,
       SAI.app_creation_date,
       SAI.app_item_id,
       SAI.app_id,
       SAP.page_id,
       SAP.page_name,
       SAP.page_label,
       SAP.page_type,
       DECODE(SAI.APP_GROUP,'~~~~~~^^^^^ERROR_VALUE',NULL,SAI.APP_GROUP)  APP_GROUP,
       ce.ENV_VERSION,
       ce.release_year,
       ce.release_month,
       ce.branch_number,
       ce.build_number
  FROM TABLE_STUDIO_APP_ITEMS_WS SAI join TABLE(CAST(multiset (SELECT level
                              FROM dual
                            CONNECT BY level <=
                                       LENGTH(regexp_replace(SAI.app_item_roles,
                                                             '[^,]+')) + 1) AS sys.OdciNumberList)) levels
                                                            on 1=1
  JOIN CONFIG_ENVIRONMENTS CE
    ON TRIM(SAI.ENV_UUID) = TRIM(CE.ENV_UUID)
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID and
       ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
  JOIN config_data_centers cdc
    ON ce.env_data_center_id = cdc.data_center_id
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
  /*left outer*/ inner join TABLE_STUDIO_APP_PAGES_WS SAP
    on SAP.APP_ITEM_ID = SAI.App_Item_Id
    and sap.env_uuid=sai.env_uuid
    and trunc(sap.event_time)=TRUNC(SAI.event_time)
 WHERE TRUNC(SAI.event_time) = trunc(sysdate - 1)
   AND CE.STATUS = 'Y'
   and CCP.CP_IS_DELETED = 0
   and SAI.supported = 0
   and APP_ITEM_LABEL is not null
/

