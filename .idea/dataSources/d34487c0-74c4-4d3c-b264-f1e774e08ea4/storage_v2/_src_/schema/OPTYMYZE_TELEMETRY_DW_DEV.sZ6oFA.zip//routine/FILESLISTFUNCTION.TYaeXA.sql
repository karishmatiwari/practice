create FUNCTION FilesListFunction(directoryName varchar2) RETURN VARCHAR2 AS
LANGUAGE JAVA NAME 'FilesListFunction.getCSVFiles(java.lang.String) return java.lang.String';
/

