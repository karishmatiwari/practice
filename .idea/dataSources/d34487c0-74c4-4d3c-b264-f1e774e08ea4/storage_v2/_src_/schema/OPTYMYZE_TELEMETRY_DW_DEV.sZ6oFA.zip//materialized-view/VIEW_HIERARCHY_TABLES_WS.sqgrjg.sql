create materialized view VIEW_HIERARCHY_TABLES_WS
refresh force on demand
  as
    SELECT CE.ENV_UUID ENVIRONMENT_UUID,
  CE.ENV_ID ENVIRONMENT_ID,
  CE.ENV_NAME ENVIRONMENT_NAME,
  cdc.data_center_name,
  CCP.CP_ID CLIENT_PROJECT_ID,
  CCP.CP_CLIENT_ID CLIENT_ID,
  TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
  ccp.cp_client_name client_name,
  CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
  trunc(sysdate-1) METRIC_DATE,
  TRIM(TO_CHAR(trunc(sysdate-1), 'Month'))
  ||' '
  ||TO_CHAR(trunc(sysdate-1), 'YYYY') metric_month,
 HIER.HIERARCHY_TABLE_NAME,
 HIER.HIERARCHY_TABLE_FOLDER_NAME,
 HIER.HIERARCHY_TABLE_ENTITIES,
 regexp_count(HIER.HIERARCHY_TABLE_ENTITIES, ',') + 1 ENTITY_COUNT,
 HIER.HIERARCHY_TABLE_IS_CORE,
 HIER.HIERARCHY_TABLE_CREATED_DATE,
 nvl(ro.login_id,HIER.HIERARCHY_TABLE_CREATED_BY) HIERARCHY_TABLE_CREATED_BY,
 --HIER.HIERARCHY_TABLE_CREATED_BY,
 HIER.HR_DISPLAY_ORDER,
 HIER.NUMBER_OF_RECORDS,
 round((decode(hier.Table_Size,-99999999999999999999,NULL,hier.Table_Size)/1024/1024),3) table_size ,
 round((decode(hier.index_size,-99999999999999999999,null,hier.index_size)/1024/1024),3) index_size,       -- in MB
 ce.ENV_VERSION,
 ce.release_year,
  ce.release_month,
  ce.branch_number,
  ce.build_number
  FROM TABLE_HIERARCHY_TABLES_WS HIER
JOIN CONFIG_ENVIRONMENTS CE
ON TRIM(HIER.ENV_UUID)    = TRIM(CE.ENV_UUID)
JOIN CONFIG_CLIENT_PROJECTS CCP
ON (CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
JOIN config_data_centers cdc
ON ce.env_data_center_id = cdc.data_center_id
JOIN CONFIG_ENVIRONMENT_TYPES CET
ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
left outer join table_role_wise_user_ws ro
on to_char(ro.user_id)=HIER.HIERARCHY_TABLE_CREATED_BY
and trunc(ro.event_time)=TRUNC(HIER.event_time)
and ro.env_uuid=hier.env_uuid
WHERE TRUNC(HIER.event_time) = trunc(sysdate-1)
AND CE.STATUS='Y' and CCP.CP_IS_DELETED=0
AND HIER.Supported=0
/

