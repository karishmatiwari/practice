create PROCEDURE  p_job_deletion_load_mv_sqs
    IS
      exists_cnt pls_integer;
    BEGIN
        SELECT COUNT(1)
        INTO exists_cnt
        FROM USER_SCHEDULER_SCHEDULES
        WHERE SCHEDULE_NAME = 'TWO_AM_SCHEDULE';
        --------------delete schedule-----------------
        IF exists_cnt       =1 
        THEN
          DBMS_SCHEDULER.DROP_SCHEDULE('TWO_AM_SCHEDULE',TRUE);
        END IF;
        
        SELECT COUNT(1)
        INTO exists_cnt
        FROM USER_SCHEDULER_PROGRAMS
        WHERE PROGRAM_NAME = 'SQS_METRIC_LOAD_MV_SQS_PROG';
        --------------delete program-----------------
        IF exists_cnt      =1 
        THEN
          DBMS_SCHEDULER.DROP_PROGRAM ('SQS_METRIC_LOAD_MV_SQS_PROG', TRUE);
        END IF;

        SELECT COUNT(1)
        INTO exists_cnt
        FROM USER_SCHEDULER_JOBS A
        WHERE JOB_NAME = 'SQS_METRIC_LOAD_MV_SQS_JOB';
          --------------delete job-----------------
        IF exists_cnt  =1 
        THEN
          DBMS_SCHEDULER.DROP_JOB ( 'SQS_METRIC_LOAD_MV_SQS_JOB',TRUE);
        END IF;    
    END p_job_deletion_load_mv_sqs;
/

