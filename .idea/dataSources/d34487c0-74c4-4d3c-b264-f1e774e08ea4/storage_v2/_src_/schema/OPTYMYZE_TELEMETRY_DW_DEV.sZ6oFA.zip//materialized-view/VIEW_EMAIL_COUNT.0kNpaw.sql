create materialized view VIEW_EMAIL_COUNT
refresh complete on demand
  as
    with dates_between as (select last_day(add_months(trunc(sysdate), -2)) + 1 first_date,
                                      last_day(add_months(trunc(sysdate), -1)) last_date
                                 from dual)
SELECT ce.env_uuid ENVIRONMENT_UUID,
       ce.env_id ENVIRONMENT_ID,
       ce.env_name ENVIRONMENT_NAME,
     CDC.DATA_CENTER_NAME DATA_CENTER_NAME,
       ccp.cp_id CLIENT_PROJECT_ID,
     TO_CHAR(CCP.CP_CLIENT_ID) CLIENT_ID,
     CCP.CP_SUB_PROJECT_ID  SUB_PROJECT_ID,
       ccp.cp_client_name CLIENT_Name,
       CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
     to_char(dates_between.last_date, 'DD-MM-YYYY') METRIC_DATE,
     TRIM(to_CHAR(dates_between.last_date, 'Month')) ||' '||to_CHAR(dates_between.last_date, 'YYYY') METRIC_MONTH,
       res.EMAIL_COUNT EMAIL_COUNT
  FROM (
         select tec.environment_uuid,
                COUNT(TEC.EMAIL_SENDER_ADDRESS) EMAIL_COUNT
           from table_email_count tec
          CROSS JOIN dates_between
          WHERE TEC.EVENT_TIME >= first_date
            AND TEC.EVENT_TIME <= last_date
          GROUP BY tec.environment_uuid
          ) res
           join config_environments ce
             on res.environment_uuid = ce.env_uuid
           join config_client_projects ccp
             on (ce.env_cp_id = ccp.cp_id and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
           join config_environment_types cet
             on cet.env_type_id = ce.env_env_type_id
        JOIN CONFIG_DATA_CENTERS CDC
    ON CDC.DATA_CENTER_ID = CE.ENV_DATA_CENTER_ID
             CROSS JOIN dates_between
       where CE.STATUS='Y'
         and CCP.CP_IS_DELETED=0
/

