create materialized view VIEW_WIDGET_COUNT
refresh complete on demand
  as
    WITH dates_between AS
  (SELECT last_day(add_months(TRUNC(sysdate), -2)) + 1 first_date,
    last_day(add_months(TRUNC(sysdate),       -1)) last_date
  FROM dual
  ),
  max_date AS
  (SELECT MAX(event_date) max_date
  FROM TABLE_WIDGET_COUNT
  CROSS JOIN dates_between
  WHERE event_date BETWEEN TRUNC(dates_between.first_date) AND TRUNC(dates_between.last_date)
  )
SELECT CE.ENV_UUID ENVIRONMENT_UUID,
  CE.ENV_ID ENVIRONMENT_ID,
  CE.ENV_NAME ENVIRONMENT_NAME,
  cdc.data_center_name,
  CCP.CP_ID CLIENT_PROJECT_ID,
  TO_CHAR(CCP.CP_CLIENT_ID) CLIENT_ID,
  TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
  ccp.cp_client_name client_name,
  CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
  TO_CHAR(max_date.max_date, 'DD-MM-YYYY') METRIC_DATE,
  TRIM(TO_CHAR(max_date.max_date, 'Month'))
  ||' '
  ||TO_CHAR(max_date.max_date, 'YYYY') METRIC_MONTH,
  TEFS.widget_name,
  NVL(TEFS.widget_count,0) WIDGET_count
FROM table_widget_count TEFS
JOIN CONFIG_ENVIRONMENTS CE
ON ( TRIM(TEFS.environment_name) = TRIM(CE.env_name)
AND tefs.ENV_DATA_CENTER_ID      = ce.ENV_DATA_CENTER_ID)
JOIN CONFIG_CLIENT_PROJECTS CCP
ON ( CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
JOIN config_data_centers cdc
ON ce.env_data_center_id = cdc.data_center_id
JOIN CONFIG_ENVIRONMENT_TYPES CET
ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
CROSS JOIN dates_between
CROSS JOIN max_date
WHERE widget_name    IN('ALERTS','TWITTER','CHART','MAP','YAMMER','YOUTUBE','VISUAL RECORDS','PIE CHART','COMPENSATION SUMMARY','ANGULAR GAUGE','FEEDBACK')
AND TRUNC(event_date) = TRUNC(max_date.max_date)
and CCP.CP_IS_DELETED=0 AND CE.STATUS ='Y'
/

