create materialized view VIEW_WEBSERVICE_ERRORS
refresh complete on demand
  as
    WITH DATES_BETWEEN AS
(SELECT LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE), -2)) + 1 FIRST_DATE,
         LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE), -1)) LAST_DATE
    FROM DUAL)
SELECT CE.ENV_UUID                                                                                     ENVIRONMENT_UUID,
       CE.ENV_ID                                                                                       ENVIRONMENT_ID,
       CE.ENV_NAME                                                                                     ENVIRONMENT_NAME,
       CDC.DATA_CENTER_NAME                                                                            DATA_CENTER_NAME,
       CCP.CP_ID                                                                                       CLIENT_PROJECT_ID,
       CCP.CP_CLIENT_ID                                                                                CLIENT_ID,
       TO_CHAR(CCP.CP_SUB_PROJECT_ID)                                                                  SUB_PROJECT_ID,
       CCP.CP_CLIENT_NAME                                                                              CLIENT_NAME,
       CET.ENV_TYPE_VALUE                                                                              ENVIRONMENT_TYPE,
       TO_CHAR(DATES_BETWEEN.LAST_DATE, 'DD-MM-YYYY')                                                  METRIC_DATE,
       TRIM(TO_CHAR(DATES_BETWEEN.LAST_DATE, 'MONTH')) ||' '||TO_CHAR(DATES_BETWEEN.LAST_DATE, 'YYYY') METRIC_MONTH,
       TWSC.SERVICE_TYPE                                                                               Webservice_Name,
       TWSC.service_subtype                                                                            Webservice_Subtype,
       COUNT(TWSC.WEBSERVICE_STATUS)                                                                   error_count
FROM TABLE_WEB_SERVICE_CALL TWSC
  JOIN CONFIG_ENVIRONMENTS CE
    ON ( TRIM(TWSC.ENVIRONMENT_UUID) = TRIM(CE.ENV_UUID) )
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON ( CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID) 
    JOIN CONFIG_DATA_CENTERS CDC
    ON CE.ENV_DATA_CENTER_ID = CDC.DATA_CENTER_ID
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
	and CCP.CP_IS_DELETED=0 AND CE.STATUS ='Y'
CROSS JOIN DATES_BETWEEN 
where TWSC.WEBSERVICE_STATUS <> 0
AND TRUNC(TWSC.EVENT_TIME) BETWEEN   DATES_BETWEEN.FIRST_DATE AND DATES_BETWEEN.LAST_DATE
GROUP BY ENV_UUID,
         ENV_ID,
         CE.ENV_NAME,
         DATA_CENTER_NAME,
         CCP.CP_ID ,
         CCP.CP_CLIENT_ID ,
         TO_CHAR(CCP.CP_SUB_PROJECT_ID),
         CCP.CP_CLIENT_NAME ,
         CET.ENV_TYPE_VALUE,
          TO_CHAR(DATES_BETWEEN.LAST_DATE, 'DD-MM-YYYY') ,
         TRIM(TO_CHAR(DATES_BETWEEN.LAST_DATE, 'MONTH')) ||' '||TO_CHAR(DATES_BETWEEN.LAST_DATE, 'YYYY'),
         TWSC.SERVICE_TYPE,
         TWSC.service_subtype
/

