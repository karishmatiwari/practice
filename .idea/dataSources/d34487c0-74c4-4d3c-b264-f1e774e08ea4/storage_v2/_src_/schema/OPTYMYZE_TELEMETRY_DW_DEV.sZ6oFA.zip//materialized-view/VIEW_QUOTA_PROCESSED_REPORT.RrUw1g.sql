create materialized view VIEW_QUOTA_PROCESSED_REPORT
refresh force on demand
  as
    SELECT CE.ENV_UUID ENVIRONMENT_UUID,
       CE.ENV_ID ENVIRONMENT_ID,
       CE.ENV_NAME ENVIRONMENT_NAME,
       cdc.data_center_name,
       CCP.CP_ID CLIENT_PROJECT_ID,
       CCP.CP_CLIENT_ID CLIENT_ID,
       TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
       ccp.cp_client_name client_name,
       CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
       TRUNC(QPR.event_time) METRIC_DATE,
       TRIM(TO_CHAR(TRUNC(QPR.event_time), 'Month')) || ' ' ||
       TO_CHAR(TRUNC(QPR.event_time), 'YYYY') metric_month,
       QPR.ENVIRONMENT_NAME ENVIRONMENT_NAME_QUOTA,
       QPR.QUOTA_DEFINITION_ID,
       QPR.QUOTA_DEFINITION_NAME,
       QPR.QUOTA_HIERARCHY,
       QPR.QUOTA_ASSIGNMENTS,
       QPR.QUOTA_RUN_PERIOD,
       QPR.INITIAL_QUOTA,
       QPR.NUMBER_OF_RECORDS_PROCESSED,
       round((QPR.Input_Tables_Size/1024/1024),3) INPUT_TABLES_SIZE,
       QPR.RUN_DATE_TIME,
       QPR.JOB_NAME,
       QPR.PROCESS_NAME,
       ce.ENV_VERSION,
       ce.release_year,
       ce.release_month,
       ce.branch_number,
       ce.build_number
      
  FROM TABLE_QUOTA_PROCESSED_REPORT QPR
  JOIN CONFIG_ENVIRONMENTS CE
    ON TRIM(QPR.ENVIRONMENT_UUID) = TRIM(CE.ENV_UUID)
  JOIN CONFIG_CLIENT_PROJECTS CCP
    ON (CCP.CP_ID = CE.ENV_CP_ID and
       ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID)
  JOIN config_data_centers cdc
    ON ce.env_data_center_id = cdc.data_center_id
  JOIN CONFIG_ENVIRONMENT_TYPES CET
    ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
 WHERE TRUNC(QPR.event_time) = TRUNC(SYSDATE - 1)
   AND CE.STATUS = 'Y'
   AND CCP.CP_IS_DELETED = 0
/

