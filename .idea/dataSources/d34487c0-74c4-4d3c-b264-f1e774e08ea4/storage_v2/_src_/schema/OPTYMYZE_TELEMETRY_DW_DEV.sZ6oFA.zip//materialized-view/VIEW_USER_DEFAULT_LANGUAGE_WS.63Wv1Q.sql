create materialized view VIEW_USER_DEFAULT_LANGUAGE_WS
refresh force on demand
  as
    WITH dates_between AS
  (SELECT last_day(add_months(TRUNC(sysdate), -2)) + 1 first_date,
    last_day(add_months(TRUNC(sysdate),       -1)) last_date
  FROM dual
  ),
max_date AS
(select max(event_time) max_date
from TABLE_USER_DEFAULT_LANGUAGE_WS
cross join dates_between
where   event_time between  trunc(dates_between.first_date) and  trunc(dates_between.last_date) )
SELECT CE.ENV_UUID ENVIRONMENT_UUID,
  CE.ENV_ID ENVIRONMENT_ID,
  CE.ENV_NAME ENVIRONMENT_NAME,
  cdc.data_center_name,
  CCP.CP_ID CLIENT_PROJECT_ID,
  CCP.CP_CLIENT_ID CLIENT_ID,
  TO_CHAR(CCP.CP_SUB_PROJECT_ID) SUB_PROJECT_ID,
  ccp.cp_client_name client_name,
  CET.ENV_TYPE_VALUE ENVIRONMENT_TYPE,
  dates_between.last_date METRIC_DATE,
  TRIM(TO_CHAR(dates_between.last_date, 'Month'))
  ||' '
  ||TO_CHAR(dates_between.last_date, 'YYYY') metric_month,
  TUDLW.SUPPORTED SUPPORTED,
  TUDLW.LANGUAGE_NAME LANGUAGE_NAME,
  NVL(TUDLW.USER_COUNT,0) USER_COUNT
FROM TABLE_USER_DEFAULT_LANGUAGE_WS TUDLW
JOIN CONFIG_ENVIRONMENTS CE
ON  TRIM(TUDLW.ENV_UUID) = TRIM(CE.ENV_UUID)
JOIN CONFIG_CLIENT_PROJECTS CCP
ON ( CCP.CP_ID = CE.ENV_CP_ID and ccp.CP_DATA_CENTER_ID = ce.ENV_DATA_CENTER_ID) 
JOIN config_data_centers cdc
ON ce.env_data_center_id = cdc.data_center_id
JOIN CONFIG_ENVIRONMENT_TYPES CET
ON CET.ENV_TYPE_ID = CE.ENV_ENV_TYPE_ID
CROSS JOIN dates_between
cross join max_date
WHERE TRUNC(TUDLW.EVENT_TIME) = TRUNC(max_date.max_date)
and CCP.CP_IS_DELETED=0 AND CE.STATUS ='Y'
/

