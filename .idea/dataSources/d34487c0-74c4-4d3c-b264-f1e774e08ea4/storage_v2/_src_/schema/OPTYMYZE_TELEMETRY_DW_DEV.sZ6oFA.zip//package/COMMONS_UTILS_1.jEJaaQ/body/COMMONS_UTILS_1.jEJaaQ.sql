create PACKAGE BODY commons_utils_1 AS
-- -----------------------------------------------------------------------------
  -- Copyright (c) 2016 - 2017 Optymyze Pte. Ltd. All Rights Reserved.
  -- This program belongs to Optymyze Pte. Ltd. It is considered a TRADE SECRET and
  -- is not to be divulged or used by parties who have not received written
  -- authorization from Optymyze Pte. Ltd.
  -- ---------------------------------------------------------------------------
  -- Database Type  : SPM
  -- Product        : Client Analytics Portal
  -- Module         : Client Analytics Portal
  -- First version Requester/s  : Pimparkar Shriniket,Gaurav Rajput
  -- First version author/s : Gaurav Rajput 
  -- First Create date    : 20160915
  -- First version Reviewer       : -- 
  -- First version Review date    : --
  -- Description    : Package used to handle all operations for Client Analytics Portal

  -- Change author      :
  -- Change date        :
  -- Change reviewer    :
  -- Change review date :
  -- Change description :
  -- ---------------------------------------------------------------------------
   
     PROCEDURE p_load_metric(pi_file_date IN DATE , pi_metric_id IN varchar2,pi_extra_derived_cols_val varchar2,pi_attach_string_to_filenam varchar2 default 'TESTING',
     Pi_Merge_insert_flag IN VARCHAR2 DEFAULT 'N') IS
  -- ------------------------------------------------------------------------------------
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Description    : Generic procedure that performs loading of the provided metric into its respective base table.
  
  -- Change description :
  -- ------------------------------------------------------------------------------------
    
    lv_insert_into_central_table commons_utils_1.maxvarchar2;
    lv_external_tab_column_list  commons_utils_1.optimizedvarchar2;
    lv_staging_tab_column_list   commons_utils_1.optimizedvarchar2;
    lv_ext_tab_col_nam_datatype  commons_utils_1.optimizedvarchar2;
    lv_access_parameter_col_list commons_utils_1.optimizedvarchar2;
    lv_directory_name            commons_utils_1.optimizedvarchar2;
    lv_file_name                 commons_utils_1.optimizedvarchar2;
    lv_metric_table_name         commons_utils_1.optimizedvarchar2;
    lv_view_name                 commons_utils_1.optimizedvarchar2;
    lv_metric_name               commons_utils_1.optimizedvarchar2;
    lv_metric_input_file_path    commons_utils_1.optimizedvarchar2;
    lv_file_length               PLS_INTEGER;
    lv_block_size                PLS_INTEGER;
    lv_num_processed             PLS_INTEGER;
    lv_proc_name                 commons_utils_1.optimizedvarchar2;
    lv_metric_source_id          PLS_INTEGER;
    lv_badfile_cnt               PLS_INTEGER;
    lv_loader_seq_currval        PLS_INTEGER;
    lv_csv_file_name             commons_utils_1.optimizedvarchar2;
    lv_bad_file_name             commons_utils_1.optimizedvarchar2; 
    lv_external_tab_name         commons_utils_1.optimizedvarchar2; 
    lv_field_delimiter           commons_utils_1.optimizedvarchar2; 
    lv_data_centre_id            commons_utils_1.optimizedvarchar2;  
    lv_staging_tab_col_nam_datatyp commons_utils_1.optimizedvarchar2;
    lv_Merge_on_clause commons_utils_1.maxvarchar2;
    lv_merge_values_clause commons_utils_1.maxvarchar2;
    lv_date_column_name commons_utils_1.optimizedvarchar2;
    lv_date_column_value commons_utils_1.optimizedvarchar2;
    lv_root commons_utils_1.optimizedvarchar2;
    
  BEGIN

    lv_proc_name   := Upper('p_load_metric') || ' for Metric id ' || pi_metric_id;
    lv_data_centre_id :='Datacentre_All';
    
    -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
    commons_utils_1.p_fetch_metric_details(pi_file_date                  => pi_file_date,
                                         pi_metric_id                  => pi_metric_id,
                                         pi_data_center_id             => lower(lv_data_centre_id),
                                         pi_attach_string_to_filenam   => pi_attach_string_to_filenam,
                                         po_metric_table_name        => lv_metric_table_name,
                                         po_view_name                => lv_view_name,
                                         po_metric_input_file_path   => lv_metric_input_file_path,
                                         po_external_tab_column_list => lv_external_tab_column_list,
                                         po_staging_tab_column_list  => lv_staging_tab_column_list,
                                         po_access_parameter_col_list=> lv_access_parameter_col_list,
                                         po_ext_tab_col_nam_datatype => lv_ext_tab_col_nam_datatype,
                                         po_staging_tab_col_nam_datatyp=>lv_staging_tab_col_nam_datatyp ,
                                         po_metric_source_id         => lv_metric_source_id,
                                         po_csv_file_name            => lv_csv_file_name,
                                         po_bad_file_name            => lv_bad_file_name,
                                         po_metric_external_table_nam => lv_external_tab_name,
                                         po_metric_name               => lv_metric_name,
                                         po_metric_default_dir_name =>lv_directory_name,
                                         po_field_delimiter =>lv_field_delimiter );
    
    -- get the csv filename that are present at the path 
    BEGIN
      commons_utils_1.p_get_filename(pi_directory => lv_metric_input_file_path,pi_filename => lv_csv_file_name);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE commons_utils_1.ex_directory_missing;
    END;

    BEGIN
      SELECT filename
        INTO lv_file_name
        FROM dir_list
       WHERE  upper(filename) = upper(lv_csv_file_name);

    EXCEPTION
      WHEN no_data_found THEN
        RAISE commons_utils_1.ex_file_missing;
      WHEN OTHERS THEN
        RAISE;
    END; 

    -- Replace the directory to point to the specified path
    commons_utils_1.p_replace_directory(pi_path=> lv_metric_input_file_path,pi_directory_name=>lv_directory_name);
 
    -- alter the external table with the location file and the log file 
    commons_utils_1.p_alter_external_table(pi_ext_table_name => lv_external_tab_name,
                                          pi_csv_file_name => lv_csv_file_name,
                                          pi_bad_file_name => lv_bad_file_name,
                                          pi_access_parameter_col_list => lv_access_parameter_col_list,
                                          pi_field_delimiter => lv_field_delimiter,
                                          pi_logging_dir => 'new_logging_dir'
                                        );

IF pi_extra_derived_cols_val is not null then 
      -- insertion in the specified metric table
      
IF Pi_Merge_insert_flag = 'N' THEN  
      
      lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' ||lv_staging_tab_column_list||')
                                       select ' || lv_external_tab_column_list || ',' ||pi_extra_derived_cols_val||'
                                       from ' || lv_external_tab_name  ;
ELSE  
      SELECT pr.pr_name, pr.pr_value into lv_date_column_name,lv_date_column_value FROM PROPERTIES pr where pr.pr_id= pi_metric_id;
        
      lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' ||lv_staging_tab_column_list||')
                                       select ' || lv_external_tab_column_list || ',' ||pi_extra_derived_cols_val||'
                                       from ' || lv_external_tab_name ||' WHERE trunc('||lv_date_column_name|| ')>to_date('''
                                       ||lv_date_column_value||''',''DD.MM.YYYY'')';


                                                                   
END IF;                                    
                                       
    ELSE
      -- insertion in the specified metric table
      lv_insert_into_central_table := 'insert into ' || lv_metric_table_name || '(' ||lv_staging_tab_column_list||')
                                       select ' || lv_external_tab_column_list ||'
                                       from ' || lv_external_tab_name  ;      
END IF;    
    
    EXECUTE IMMEDIATE lv_insert_into_central_table;
    
    lv_num_processed := SQL%ROWCOUNT;

    -- retrieve the list of .bad  present at the path 
    commons_utils_1.p_get_filename(pi_directory => commons_utils_1.gv_loggingroot,pi_filename => lv_bad_file_name);
    BEGIN
      SELECT count(*)
        INTO lv_badfile_cnt
        from dir_list
       where lower(filename) = lower(lv_bad_file_name);

    EXCEPTION
      WHEN OTHERS THEN
        RAISE;
    END;

    if lv_badfile_cnt > 0 then
      raise commons_utils_1.ex_bad_file_exists;
    end if;

    -- exception to check if the file being loaded is empty ?
    if lv_num_processed = 0 then
     raise commons_utils_1.ex_file_empty;
    end if;

    -- clean the GTT
    DELETE FROM dir_list
    WHERE  upper(filename) = upper(lv_csv_file_name);
     
    DELETE FROM dir_list
     where lower(filename) = lower(lv_bad_file_name);
     
    UPDATE table_load_metrics
    SET loaded_flag = 'Y'
    WHERE metric_id = pi_metric_id
    AND loaded_date = pi_file_date; 

    UPDATE PROPERTIES P
    SET P.PR_VALUE = TO_CHAR(trunc(sysdate-1), 'DD.MM.YYYY')
    WHERE P.PR_ID = pi_metric_id; 

  EXCEPTION
    WHEN OTHERS THEN
      execute immediate 'ROLLBACK TO S_'||pi_metric_id;

    -- clean the GTT
    DELETE FROM dir_list
     WHERE  upper(filename) = lv_csv_file_name;
     
    DELETE FROM dir_list
     where lower(filename) = lower(lv_bad_file_name);
     
      IF SQLCODE = commons_utils_1.c_ex_directory_missing THEN
        commons_utils_1.p_error_logging(pi_metric_id            => pi_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Directory does not exist OR read rights not provided for ' || lv_metric_input_file_path || ' : ' || SQLERRM,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = commons_utils_1.c_ex_file_missing THEN
        commons_utils_1.p_error_logging(pi_metric_id            => pi_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'File does not exist at the following path ' || lv_metric_input_file_path,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSIF SQLCODE = commons_utils_1.c_ex_bad_file_exists THEN
        commons_utils_1.p_error_logging(pi_metric_id            => pi_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Bad file '||lv_bad_file_name ||' was generated for '||lv_data_centre_id||' on at the following path ' || commons_utils_1.gv_loggingroot,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
     ELSIF SQLCODE = commons_utils_1.c_ex_file_empty THEN
        commons_utils_1.p_error_logging(pi_metric_id            => pi_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'File '||lv_csv_file_name ||' does not have any records for '||lv_data_centre_id||' on at the following path ' || lv_metric_input_file_path,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      ELSE
        commons_utils_1.p_error_logging(pi_metric_id            => pi_metric_id,
                                      pi_procedure_name       => lv_proc_name,
                                      pi_error_message        => 'Failed at p_load_metric for metric '||lv_metric_name|| ' with error :- ' || SQLERRM || 'Backtraced: ' || commons_utils_1.f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => pi_file_date);
      END IF;
  END p_load_metric;
  
  PROCEDURE p_send_alert_email(pin_processing_date IN date,pin_load_current_iteration pls_integer)
  AS
  -- ---------------------------------------------------------------------------
  -- Author         : Joseph Sanumon
  -- Reviewer       : Rajput Gaurav
  -- Description    : Sends out Email alerts to a configured set of users in the metadata
  
  -- Change description :
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Date : 20171011
  -- Description    : Addition of CONFIG_GENERAL_ERRORS so that alerts other than metric alerts can be sent
  -- ---------------------------------------------------------------------------
    LV_ERROR_SHORT_NAME optimizedvarchar2;
    LV_MAIL_STARTS      optimizedvarchar2;
    Lv_Mail_Ends        optimizedvarchar2;
    lv_mail_dynamic_table     clob;
    lv_mail_general_error_dyn clob;
    lv_mail_comb_body         clob;
    LV_MAIL_BODY        clob;
    LV_MAIL_SUBJECT     optimizedvarchar2;
    lv_mail_id          NUMBER;
    LV_SENDER_EMAIL_ID  optimizedvarchar2;
    lv_to_email_ids     optimizedvarchar2;
    LV_CC_EMAIL_IDS     optimizedvarchar2;
    LV_BCC_EMAIL_IDS    optimizedvarchar2;
    LV_METRIC_NAME      optimizedvarchar2;
    LV_ERROR_NAME      optimizedvarchar2;
    lv_cma_notify_iteration_number   pls_integer;
    lv_loaded_flag      PLS_INTEGER;
  BEGIN
    
    LV_MAIL_STARTS     :='<!doctype html> <html> <head> <style type="text/css"> .error { border-collapse: collapse;width: 90%;border:1px solid #00bfff;}    .error td {border:1px solid #00bfff;border-right:1px solid #00bfff;}    .table {border-collapse: collapse;border:1px solid #00bfff;width: 90%;}th, td {border:0px;text-align: left;padding: 5px;}   th {border:1px solid #00bfff;background-color: #bbe9f9;}.thsub {background-color: #d8f5ff;border-collapse: collapse;} .thsub2 {background-color: #f7fcff;}body{font-family:cambria ;font-size:14px;} </style> </head> <body> <table align="center" class="table"> <tr> <td> Hello! <br><br>Please find below the summary Alerts for ''Telemetry''. Kindly have a look and resolve these issues. <br><br>';
    LV_MAIL_ENDS       :='</td> </tr> <tr > <td style="background-color: white">Regards, <br> Telemetry Alerts</td> </table> </body> </html> ';
    lv_mail_subject    :='Telemetry Alerts as on ' || TO_CHAR(sysdate,'DD-Mon-YYYY') || ' from production server '  || SYS_CONTEXT ('USERENV', 'SERVER_HOST');
    LV_SENDER_EMAIL_ID :='telemetry_alert@optymyze.com';
  
    <<CMA_ID_LOOP>>
    FOR c_processing_metric_ids IN
        (select METRIC_CMA_ID , LISTAGG(METRIC_ID , ',') within GROUP (  ORDER BY Metric_Id) METRIC_ID 
                     from (   
         SELECT METRIC_CMA_ID,to_char(Cm.Metric_Id) Metric_Id
    FROM Config_Metrics Cm
    WHERE EXISTS
      (SELECT 1
      FROM Telemetry_Error_Logs
                        WHERE TRUNC(Tel_Error_Event_Date) =trunc(pin_processing_date)
                        AND to_char(cm.metric_id)                  = tel_metric_id)
         union all     
         select CGE_CMA_ID, CGE_MAPPING_NAME Metric_Id
                      from CONFIG_GENERAL_ERRORS CGE
                      WHERE EXISTS 
                      (SELECT 1
                        FROM Telemetry_Error_Logs
                        WHERE TRUNC(Tel_Error_Event_Date) =trunc(pin_processing_date)
                        AND to_char(CGE.CGE_MAPPING_NAME)= tel_metric_id)
      )
    GROUP BY METRIC_CMA_ID
    )
    LOOP
      <<METRIC_IDS_LOOP>>
      FOR c_processing_metric_id IN
      ( WITH DATA AS( SELECT DISTINCT c_processing_metric_ids.METRIC_ID rcv_metric_id FROM dual )
        SELECT trim(regexp_substr(rcv_metric_id, '[^,]+', 1, LEVEL)) rcv_metric_id
        FROM DATA
          CONNECT BY regexp_substr(rcv_metric_id , '[^,]+', 1, LEVEL) IS NOT NULL
      )
      LOOP
        if trim(TRANSLATE(c_processing_metric_id.rcv_metric_id,'0123456789-+.', ' ')) is null
              then 
          SELECT cma_notify_iteration_number
          INTO lv_cma_notify_iteration_number
          FROM CONFIG_MAIL_ALERT
          WHERE CMA_ID = c_processing_metric_ids.METRIC_CMA_ID;
  
          SELECT COUNT(1)
          INTO lv_loaded_flag
          FROM TABLE_LOAD_METRICS
          WHERE METRIC_ID        =C_PROCESSING_METRIC_ID.RCV_METRIC_ID
          AND TRUNC(LOADED_DATE) = PIN_PROCESSING_DATE AND LOADED_FLAG='N';
  
  
         <<Frequency_check>>
         if lv_loaded_flag != 0 AND lv_cma_notify_iteration_number <= pin_load_current_iteration then
              SELECT METRIC_NAME
              INTO LV_METRIC_NAME
              FROM config_metrics
              WHERE METRIC_ID=c_processing_metric_id.rcv_metric_id;
              -- error message fetch into a  variable
              lv_mail_dynamic_table:=lv_mail_dynamic_table||'<br><table align="center" class="error"><tr><th colspan="4">'||initcap(LV_METRIC_NAME)||'</th> </tr><tr class="thsub"><td><b>Error</b></td><td><b>Description</b></td><td><b>Iteration</b></td><td><b> Error Log Date</b></td><td><b>Event Date</b></td></tr>';
  
              <<EXCEPTION_ID_LOOP>>
              FOR C_Process_Errors IN
              (SELECT TEL_ERROR_CODE,
                tel_error_message,
                TO_CHAR(TEL_ERROR_EVENT_DATE,'dd-Mon-yyyy') error_event_date,
                TO_CHAR(TEL_ERROR_log_DATE,'dd-Mon-yyyy hh24:mi:ss') error_log_date,
				TEL_ITERATION_NUMBER--OF-103077
              FROM Telemetry_Error_Logs
              WHERE TRUNC(TEL_ERROR_EVENT_DATE) =pin_processing_date
              AND TEL_METRIC_ID               =to_char(c_processing_metric_id.rcv_metric_id)
              ORDER BY error_log_date
              )
              LOOP
                SELECT DECODE(
                  c_process_errors.TEL_ERROR_CODE,
                    c_ex_directory_missing,   c_str_directory_missing,
                    c_ex_file_missing,        c_str_file_missing,
                    c_ex_bad_file_exists,     c_str_bad_file,
                    c_ex_file_empty,          c_str_file_empty,
                    c_ex_mv_refresh_alert,    c_str_mv_refresh_alert,'Internal Error ')
                INTO LV_ERROR_SHORT_NAME
                FROM dual;
                lv_mail_dynamic_table:=lv_mail_dynamic_table||'<TR  class="thsub2" ><TD>'||LV_ERROR_SHORT_NAME||'</TD> <TD>'||c_process_errors.TEL_ERROR_MESSAGE||'</TD> <TD nowrap>'||c_process_errors.TEL_ITERATION_NUMBER||'</TD> <TD nowrap>'||c_process_errors.error_log_date||'</TD><TD nowrap>'||c_process_errors.error_event_date||'</TD> </TR>';
              END LOOP Exception_Id_Loop;
              lv_mail_dynamic_table:=lv_mail_dynamic_table||'</table>';
            end if ;  --Frequency_check
         else 
           SELECT cma_notify_iteration_number INTO lv_cma_notify_iteration_number
           FROM CONFIG_MAIL_ALERT WHERE CMA_ID IN ( SELECT CGE_CMA_ID FROM CONFIG_GENERAL_ERRORS WHERE UPPER(CGE_MAPPING_NAME)=UPPER(C_PROCESSING_METRIC_ID.RCV_METRIC_ID));
          if lv_cma_notify_iteration_number <= pin_load_current_iteration
            then
            SELECT CGE_ERROR_NAME
              INTO LV_ERROR_NAME
              FROM CONFIG_GENERAL_ERRORS
              WHERE CGE_MAPPING_NAME=c_processing_metric_id.rcv_metric_id;
              -- error message fetch into a  variable
              lv_mail_general_error_dyn:=lv_mail_general_error_dyn||'<br><table align="center" class="error"><tr><th colspan="4">'||initcap(LV_ERROR_NAME)||'</th> </tr><tr class="thsub"><td><b>Error</b></td><td><b>Description</b></td><td><b>Iteration</b></td><td><b> Error Log Date</b></td><td><b>Event Date</b></td></tr>';
               <<EXCEPTION_ID_LOOP>>
              FOR C_Process_Errors IN
              (SELECT TEL_ERROR_CODE,
                tel_error_message,
                TO_CHAR(TEL_ERROR_EVENT_DATE,'dd-Mon-yyyy') error_event_date,
                TO_CHAR(TEL_ERROR_log_DATE,'dd-Mon-yyyy hh24:mi:ss') error_log_date,
				TEL_ITERATION_NUMBER--OF-103077
              FROM Telemetry_Error_Logs
              WHERE TRUNC(TEL_ERROR_EVENT_DATE) =pin_processing_date
              AND TEL_METRIC_ID               =to_char(c_processing_metric_id.rcv_metric_id)
              ORDER BY error_log_date
              )
              LOOP
                SELECT DECODE(
                  c_process_errors.TEL_ERROR_CODE,
                    c_ex_directory_missing,   c_str_directory_missing,
                    c_ex_file_missing,        c_str_file_missing,
                    c_ex_bad_file_exists,     c_str_bad_file,
                    c_ex_file_empty,          c_str_file_empty,
                    c_ex_mv_refresh_alert,    c_str_mv_refresh_alert , 'Internal Error ')
                INTO LV_ERROR_SHORT_NAME
                FROM dual;
                lv_mail_general_error_dyn:=lv_mail_general_error_dyn||'<TR  class="thsub2" ><TD>'||LV_ERROR_SHORT_NAME||'</TD> <TD>'||c_process_errors.TEL_ERROR_MESSAGE||'</TD> <TD nowrap>'||c_process_errors.TEL_ITERATION_NUMBER||'</TD> <TD nowrap>'||c_process_errors.error_log_date||'</TD><TD nowrap>'||c_process_errors.error_event_date||'</TD> </TR>';
              END LOOP Exception_Id_Loop;
              lv_mail_general_error_dyn:=lv_mail_general_error_dyn||'</table>';
           end if;
                end if;
      END LOOP METRIC_IDS_LOOP;
  
      --<<Content_check>>
      lv_mail_comb_body:=lv_mail_general_error_dyn||lv_mail_dynamic_table;
      --if lv_mail_comb_body is not null then ---OF-103077
                  -- send call
                  BEGIN
                    /*SELECT CMA_TO_RECIPIENTS_LIST
                    INTO LV_DIST_RECEPIENTS
                    FROM config_mail_alert
                    WHERE Cma_Id=c_processing_metric_ids. METRIC_CMA_ID;*/
                    SELECT CMA_FROM_EMAIL_ID,
                      CASE CMA_TO_FLAG
                        WHEN c_distribution_list
                        THEN CMA_TO_DISTRIBUTION_LIST
                        WHEN c_receipient_list
                        THEN CMA_TO_RECIPIENTS_LIST
                        ELSE rtrim(CMA_TO_RECIPIENTS_LIST||','||CMA_TO_DISTRIBUTION_LIST,',') /* c_both_list */
                      END to_list,
                      CASE CMA_CC_FLAG
                        WHEN c_distribution_list
                        THEN CMA_CC_DISTRIBUTION_LIST
                        WHEN c_receipient_list
                        THEN cma_cc_recipients_list
                        ELSE rtrim(CMA_CC_RECIPIENTS_LIST||','||CMA_CC_DISTRIBUTION_LIST,',') /* c_both_list */
                      END cc_list,
                      CASE CMA_BCC_FLAG
                        WHEN c_distribution_list
                        THEN CMA_BCC_DISTRIBUTION_LIST
                        WHEN c_receipient_list
                        THEN cma_BCC_recipients_list
                        ELSE rtrim(cma_BCC_recipients_list||','||CMA_BCC_DISTRIBUTION_LIST,',') /* c_both_list */
                      END bcc_list
                    INTO LV_SENDER_EMAIL_ID,
                      LV_TO_EMAIL_IDS,
                      LV_CC_EMAIL_IDS,
                      LV_BCC_EMAIL_IDS
                    FROM config_mail_alert
                    WHERE cma_id=c_processing_metric_ids.METRIC_CMA_ID;
                  EXCEPTION
                  WHEN OTHERS THEN
                    raise_application_error(-20006,'Error while selecting from config_mail_alert');
                  END;
  
				  <<Content_check>>--OF-103077
				if lv_mail_comb_body is not null then
                  lv_mail_body :=lv_mail_starts || lv_mail_comb_body || lv_mail_ends ;
				  ELSE
				  lv_mail_body :='<!doctype html> <html> <head> <style type="text/css"> .error { border-collapse: collapse;width: 90%;border:1px solid #00bfff;}    .error td {border:1px solid #00bfff;border-right:1px solid #00bfff;}    .table {border-collapse: collapse;border:1px solid #00bfff;width: 90%;}th, td {border:0px;text-align: left;padding: 5px;}   th {border:1px solid #00bfff;background-color: #bbe9f9;}.thsub {background-color: #d8f5ff;border-collapse: collapse;} .thsub2 {background-color: #f7fcff;}body{font-family:cambria ;font-size:14px;} </style> </head> <body> <table align="center" class="table"> <tr> <td> Hello! <br><br>There is no Alert for ''Telemetry''.<br><br></td> </tr> <tr > <td style="background-color: white">Regards, <br> Telemetry Alerts</td> </table> </body> </html> ';
				end if ; --Content_check
  
                  BEGIN
                    SELECT NVL(MAX(TMAL_MAIL_ID),0)+1 INTO LV_MAIL_ID FROM TEL_MAIL_ALERT_LOGS;
                    INSERT
                    INTO TEL_MAIL_ALERT_LOGS
                      (
                        TMAL_MAIL_ID ,
                        TMAL_FROM_EMAIL_ID ,
                        TMAL_TO_EMAIL_ID,
                        TMAL_MAIL_SUBJECT ,
                        TMAL_MAIL_CC ,
                        TMAL_MAIL_BCC ,
                        TMAL_MAIL_SENT ,
                        TMAL_MAIL_ERROR,
                        TMAIL_ERROR_EVENT_DATE,
                        TMAIL_MAIL_CONTENT,
                        tmail_notify_iteration_number,
						TMAIL_ITERATION_NUMBER--OF-103077
                      )
                      VALUES
                      (
                        LV_MAIL_ID,
                        LV_SENDER_EMAIL_ID,
                        LV_TO_EMAIL_IDS,
                        LV_MAIL_SUBJECT,
                        lv_cc_email_ids,
                        LV_BCC_EMAIL_IDS,
                        'N',
                        NULL,
                        pin_processing_date,
                        lv_mail_body,
                        lv_cma_notify_iteration_number,
						pin_load_current_iteration--OF-103077
                      );
                    COMMIT;
                  EXCEPTION
                  WHEN OTHERS THEN
                    raise_application_error(-20006,'Error while inserting into TEL_MAIL_ALERT_LOGS.');
                  END;
  
                    begin
                        commons_utils_1.p_error_logging(pi_metric_id    => 'p_send_alert_email',
                                    pi_procedure_name => 'p_send_alert_email',
                                    pi_error_message  => 'before p_send_alert_email-->
                                    utl_mail.send( sender=>'''||LV_SENDER_EMAIL_ID||''', recipients=>'''||LV_TO_EMAIL_IDS||''', cc=>'''||lv_cc_email_ids||''', bcc=>'''||LV_BCC_EMAIL_IDS||''', subject=> '''||LV_MAIL_SUBJECT||''', MESSAGE=> ''null'', mime_type =>''text/html'', priority =>3, replyto =>NULL )',
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => sysdate);

--                                    pi_tel_error_event_date => sysdate);
                     utl_mail.send( sender=>LV_SENDER_EMAIL_ID, recipients=>LV_TO_EMAIL_IDS, cc=>lv_cc_email_ids, bcc=>LV_BCC_EMAIL_IDS, subject=> LV_MAIL_SUBJECT, MESSAGE=> LV_MAIL_BODY, mime_type =>'text/html', priority =>3, replyto =>NULL );
                      UPDATE TEL_MAIL_ALERT_LOGS
                      SET TMAL_MAIL_SENT ='Y' ,
                        TMAL_MAIL_SENT_ON=sysdate
                      where tmal_mail_id =lv_mail_id;
                       commit;
                    EXCEPTION
                    WHEN OTHERS THEN
                      UPDATE TEL_MAIL_ALERT_LOGS
                      SET TMAL_MAIL_ERROR =DBMS_UTILITY.FORMAT_ERROR_STACK
                      WHERE TMAL_MAIL_ID  =lV_MAIL_ID;
                      commit;

                    END;
      --end if ; --Content_check
  
      lv_to_email_ids:='';
      lv_cc_email_ids:='';
      lv_bcc_email_ids:='';
      lv_mail_body      :='';
      lv_mail_comb_body :='';
      lv_mail_general_error_dyn := ''; 
      lv_mail_dynamic_table :='';
    END LOOP cma_id_loop;
  exception
  when others then
  raise;
  END p_send_alert_email;


  PROCEDURE p_get_filename(
      pi_directory IN VARCHAR2,
      pi_filename VARCHAR2)
  AS
  -- ------------------------------------------------------------------------------------
  -- Author         : Joseph Sanumon
  -- Reviewer       : Rajput Gaurav
  -- Description    : Gets all the file names by taking Input a particular directory path
  
  -- Change description :
  -- ------------------------------------------------------------------------------------
    LANGUAGE JAVA NAME 'List_Files.getList( java.lang.String , java.lang.String )';

  PROCEDURE p_replace_directory(pi_path        IN VARCHAR2,
                              pi_directory_name IN VARCHAR2)  IS
  -- ------------------------------------------------------------------------------------
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Description    : Creates or replace a directory object 
  
  -- Change description :
  -- ------------------------------------------------------------------------------------
   PRAGMA AUTONOMOUS_TRANSACTION;
    lv_ddl            optimizedvarchar2;
  BEGIN
    lv_ddl := 'CREATE OR REPLACE DIRECTORY ' || pi_directory_name ||' AS ''' || pi_path || '''';
    EXECUTE IMMEDIATE lv_ddl;

   exception
  when others then
        raise_application_error(-20006,'Error in p_replace_directory with error code '|| sqlcode || sqlerrm);
  END p_replace_directory;


 /* procedure p_table_ocm_sync_insert (pi_processing_date in date,
    PI_ITERATION_NUMBER IN NUMBER) -- 4 TIMES OCM SYNC
  as
  -- ------------------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Pragma Automonous transaction that inserts into table_com_sync
  
  -- Change description :
  -- ------------------------------------------------------------------------------------  
  pragma autonomous_transaction;
  lv_table_name varchar2(100);
  begin
    lv_table_name:='table_ocm_sync';
    insert into table_ocm_sync (toc_id,
                                toc_event_date,
                                toc_flag,
                                description,
                                TOC_ITERATION_NUMBER) values (TOC_SEQ.Nextval,pi_processing_date,'N','OCM_SYNC',PI_ITERATION_NUMBER); -- 4 TIMES OCM SYNC
                                commit;
  exception 
    WHEN DUP_VAL_ON_INDEX        THEN  
    rollback;   
    when others then
    rollback; 
    commons_utils_1.p_error_logging(pi_metric_id    => 'p_table_ocm_sync_insert',
                                    pi_procedure_name => 'p_table_ocm_sync_insert',
                                    pi_error_message  => 'Failed while inserting in '||lv_table_name||' error message '||sqlerrm,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => pi_processing_date);
  end p_table_ocm_sync_insert;*/

  

  PROCEDURE p_fetch_metric_details(pi_file_date                  IN DATE,
                                 pi_metric_id                  IN CONFIG_METRICS.metric_id%TYPE,
                                 pi_data_center_id             IN VARCHAR2,
                                 pi_attach_string_to_filenam   IN VARCHAR2,
                                 po_metric_table_name          OUT CONFIG_METRICS.metric_table_name%TYPE,
                                 po_view_name                  OUT CONFIG_METRICS.metric_view_name%TYPE,
                                 po_metric_input_file_path     OUT VARCHAR2,
                                 po_external_tab_column_list   OUT VARCHAR2,
                                 po_staging_tab_column_list    OUT VARCHAR2,
                                 po_access_parameter_col_list  OUT varchar2,
                                 po_ext_tab_col_nam_datatype   OUT VARCHAR2,
                                 po_staging_tab_col_nam_datatyp   OUT VARCHAR2,
                                 po_metric_source_id           OUT CONFIG_METRICS.metric_source_id%TYPE,
                                 po_csv_file_name              OUT varchar2 ,
                                 po_bad_file_name              OUT varchar2,
                                 po_metric_external_table_nam  OUT varchar2,
                                 po_metric_name                OUT CONFIG_METRICS.metric_name%TYPE,
                                 po_metric_default_dir_name OUT config_metrics.metric_default_directory_name%type,
                                 po_field_delimiter           OUT varchar2
                               ) IS
  -- ------------------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Gets all the metric details that are required from metadata tables 
  
  -- Change description :
  -- ------------------------------------------------------------------------------------
    lv_date_char optimizedvarchar2;
    lv_metric_a_date_format optimizedvarchar2;
  BEGIN
  lv_date_char := to_char(pi_file_date, 'DDMMYYYY');

  BEGIN
  select METRIC_A_DATE_FORMAT into lv_metric_a_date_format from config_metric_attributes cma where cma.metric_a_metric_id=pi_metric_id  and UPPER(cma.METRIC_A_COLUMN_NAME)='EVENT_TIME';
  exception when no_data_found
    then
      lv_metric_a_date_format:=NULL;
  END;

    SELECT upper(metric_name),
           metric_table_name,
           metric_view_name,
           TRIM(REPLACE(REPLACE(REPLACE(metric_input_file_path,'Root_path', decode(metric_source_id,10,commons_utils_1.gv_new_root,commons_utils_1.gv_root)), 'Datacentre_check', 'Datacentre_' || pi_data_center_id),'DDMMYYYY', lv_date_char)) metric_input_file_path,
           listagg(decode(metric_a_is_rcvd_from_csv,1,metric_a_column_name,2,metric_a_column_name,null), ',') within GROUP(ORDER BY metric_a_order) external_tab_column_names,
           listagg(metric_a_column_name, ',') within GROUP(ORDER BY decode(metric_a_is_rcvd_from_csv,1,1,2,1,2),metric_a_order) staging_tab_column_names,
--           REPLACE(replace(replace(listagg(lower(metric_a_column_name) || chr(32) || metric_a_column_datatype,',') within GROUP(ORDER BY metric_a_order),chr(32)||'DATE',chr(32)||'CHAR(50) date_format DATE mask "dd.mm.yyyy hh24:mi:ss"'),chr(32)||'VARCHAR2(',chr(32)||'CHAR('),chr(32)||'NUMBER',chr(32)||'INTEGER EXTERNAL') access_parameter_col_list,
                      REPLACE (REPLACE(replace(replace(replace(listagg(decode(metric_a_is_rcvd_from_csv,1,metric_a_column_name || chr(32) || upper(metric_a_column_datatype),2,metric_a_column_name || chr(32) || upper(metric_a_column_datatype),null),',') within GROUP(ORDER BY metric_a_order),chr(32)||'DATE',chr(32)||lv_metric_a_date_format),chr(32)||'VARCHAR2(',chr(32)||'CHAR('),chr(32) || 'CLOB',chr(32) || 'CHAR(100000)'),chr(32)||'NUMBER',chr(32)|| null ),CHR(32)||'CHAR)',')') access_parameter_col_list,
           listagg(decode(metric_a_is_rcvd_from_csv,1,metric_a_column_name || chr(32) || upper(metric_a_column_datatype),2,metric_a_column_name || chr(32) || upper(metric_a_column_datatype),null),',') within GROUP(ORDER BY metric_a_order)  ext_tab_column_names_datatype,
           listagg(metric_a_column_name || chr(32) || upper(metric_a_column_datatype),',') within GROUP(ORDER BY metric_a_order)  po_staging_tab_col_nam_datatyp,
           metric_source_id,
           decode(metric_source_id,10,(replace(metric_input_file_format,'<Metricname>',Metric_mapped_name)),(replace(REPLACE(metric_input_file_format,'<Metricname>',Metric_name||'_'||pi_attach_string_to_filenam),'DDMMYYYY',lv_date_char))) csv_file_name, --Metricname_ddmmyyyy.csv
           decode(metric_source_id,10,(lower(cm.metric_name)||'_'|| sys_context('gc_new_loader_seq_cur_val', 'global_attribute')  || '.bad' ),(lower(cm.metric_name)||'_'||pi_attach_string_to_filenam||'_'||  lv_date_char || '_datacentre_'||pi_data_center_id||'_'|| sys_context('gc_loader_seq_cur_val', 'global_attribute')  || '.bad' )) bad_file_name,
           lower(metric_external_table_name) metric_external_table_name,
           metric_default_directory_name,
           decode(metric_source_id,2,',',5,',',6,',','\t') field_delimiter
      INTO po_metric_name,
           po_metric_table_name,
           po_view_name,
           po_metric_input_file_path,
           po_external_tab_column_list,
           po_staging_tab_column_list,
           po_access_parameter_col_list,
           po_ext_tab_col_nam_datatype,
           po_staging_tab_col_nam_datatyp,
           po_metric_source_id,
           po_csv_file_name,
           po_bad_file_name,
           po_metric_external_table_nam,
           po_metric_default_dir_name,
           po_field_delimiter
      FROM config_metrics cm
      LEFT OUTER JOIN config_metric_attributes cma
        ON cm.metric_id = cma.metric_a_metric_id
     WHERE cm.metric_id = pi_metric_id
     GROUP BY metric_name,
              metric_table_name,
              metric_view_name,
              metric_input_file_path,
              metric_source_id,
              metric_input_file_format,
              metric_external_table_name,
              metric_default_directory_name,
              Metric_mapped_name;

  EXCEPTION
    WHEN OTHERS THEN
      raise_application_error(-20006,'Error in p_fetch_metric_details with error code ' || sqlcode || sqlerrm);
  END p_fetch_metric_details;


  procedure get_access_parameter_string (
  pi_bad_file_name  IN varchar2,
  pi_access_parameter_col_list  IN VARCHAR2,
  pi_field_delimiter            IN VARCHAR2,
  pi_logging_dir                IN VARCHAR2 ,
  po_access_param_string out varchar2
  ) is
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Prepares the access paramater string required for the alteration of the external table 
  
  -- Change description :
  -- -----------------------------------------------------------------------------
  begin
  po_access_param_string:=' ACCESS PARAMETERS ( RECORDS DELIMITED BY NEWLINE skip 1
                           CHARACTERSET AL32UTF8
                           BADFILE '||pi_logging_dir||' : '''||pi_bad_file_name||'''
                           LOGFILE '||pi_logging_dir||' :  '''||replace(pi_bad_file_name,'.bad','.log')||'''
                           discardfile '||pi_logging_dir||' : '''||replace(pi_bad_file_name,'.bad','.dsc')||'''
                           FIELDS TERMINATED BY '''||pi_field_delimiter||'''
                           missing field values are null ('||pi_access_parameter_col_list||')) ' ;


  exception
  when others then
    raise_application_error(-20006,'Error in get_access_parameter_string with error code ' || SQLCODE || sqlerrm);
  end get_access_parameter_string;

  procedure get_location_string (pi_csv_file_name  IN varchar2, po_location_string OUT varchar2) as
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Prepares the location paramater string required for the alteration of the external table 
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
  begin
    po_location_string:= ' LOCATION ('''||pi_csv_file_name ||''')';
  exception
  when others then
    raise_application_error(-20006,'Error in get_location_string with error code ' || SQLCODE || sqlerrm);
  end get_location_string;


  PROCEDURE p_alter_external_table( pi_ext_table_name IN varchar2,
                                  pi_csv_file_name  IN varchar2,
                                  pi_bad_file_name  IN varchar2,
                                  pi_access_parameter_col_list  IN VARCHAR2,
                                  pi_field_delimiter            IN VARCHAR2,
                                  pi_logging_dir                IN VARCHAR2  default 'bad_dir'
   )
  IS
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Alters the external table with the location and access parameter string
  
  -- Change description :
  -- -----------------------------------------------------------------------------
    PRAGMA AUTONOMOUS_TRANSACTION;

  lv_access_param_string optimizedvarchar2;
  lv_location_string optimizedvarchar2;
  BEGIN

  get_access_parameter_string (  pi_bad_file_name  =>pi_bad_file_name,  pi_access_parameter_col_list  =>pi_access_parameter_col_list,  pi_field_delimiter            =>pi_field_delimiter,  po_access_param_string =>lv_access_param_string , pi_logging_dir => pi_logging_dir);
  get_location_string (pi_csv_file_name =>pi_csv_file_name, po_location_string =>lv_location_string);
  execute immediate 'ALTER TABLE' || chr(32) ||pi_ext_table_name ||chr(32) || lv_access_param_string ;
  execute immediate 'ALTER TABLE' ||  chr(32) ||pi_ext_table_name ||chr(32) ||lv_location_string;

  EXCEPTION
  WHEN OTHERS THEN
    raise_application_error(-20006,'Error in p_alter_external_table with error code ' || SQLCODE || sqlerrm);
  END p_alter_external_table;
  

  PROCEDURE p_read_write_config(
      pi_read_write_action IN NUMBER,
      pi_config_table      IN VARCHAR2,
      pi_exe_proc_name     IN VARCHAR2)
  IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Alters the Physical table with the read write property
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    PRAGMA AUTONOMOUS_TRANSACTION;
    LV_SQL_TABLE VARCHAR2(4001 CHAR);
  BEGIN
    IF pi_read_write_action =1 THEN
      LV_SQL_TABLE         :='ALTER TABLE ' ||UPPER(pi_config_table)|| ' READ WRITE ';
    ELSIF pi_read_write_action =0 THEN
      LV_SQL_TABLE         :='ALTER TABLE ' ||UPPER(pi_config_table)|| ' READ ONLY ';
    END IF;
    EXECUTE IMMEDIATE LV_SQL_TABLE;

  EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE in (-14139,-14140) THEN
      NULL;
    ELSE
      commons_utils_1.p_error_logging(pi_metric_id    => '',
                                  pi_procedure_name => 'P_READ_WRITE_CONFIG',
                                  pi_error_message  => 'Failed in '||pi_exe_proc_name||' during applying '|| CASE pi_read_write_action WHEN 1 THEN 'READ WRITE mode  '  WHEN  0 THEN 'READ ONLY mode ' END || ' on table ' ||UPPER(pi_config_table)||' due to : '|| f_get_exception_backtrace,
                                  pi_error_in_code  => SQLCODE,
                                  pi_tel_error_event_date => null);
      raise;
    END IF;
  END p_read_write_config;
  

  procedure p_create_external_table( pi_metric_id IN config_metrics.metric_id%type ,pi_file_date    IN DATE,pi_attach_string_to_filenam varchar default 'TESTING',pi_is_create_required IN pls_integer default 1)
  is
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Creates the External table 
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
      lv_execute_ddl commons_utils_1.maxvarchar2;
      lv_external_tab_column_list  commons_utils_1.optimizedvarchar2;
      lv_staging_tab_column_list   commons_utils_1.optimizedvarchar2;
      lv_ext_tab_col_nam_datatype  commons_utils_1.optimizedvarchar2;
      lv_access_parameter_col_list commons_utils_1.optimizedvarchar2;
      lv_directory_name            commons_utils_1.optimizedvarchar2;
      lv_file_name                 commons_utils_1.optimizedvarchar2;
      lv_metric_table_name         commons_utils_1.optimizedvarchar2;
      lv_view_name                 commons_utils_1.optimizedvarchar2;
      lv_metric_name               commons_utils_1.optimizedvarchar2;
      lv_metric_input_file_path    commons_utils_1.optimizedvarchar2;
      lv_file_length               PLS_INTEGER;
      lv_block_size                PLS_INTEGER;
      lv_num_processed             PLS_INTEGER;
      lv_proc_name                 commons_utils_1.optimizedvarchar2;
      lv_metric_source_id          PLS_INTEGER;
      lv_badfile_cnt               PLS_INTEGER;
      lv_loader_seq_currval        PLS_INTEGER;
      lv_csv_file_name             commons_utils_1.optimizedvarchar2;
      lv_bad_file_name             commons_utils_1.optimizedvarchar2;
      lv_external_tab_name         commons_utils_1.optimizedvarchar2;
      lv_field_delimiter           commons_utils_1.optimizedvarchar2;
      lv_data_centre_id            commons_utils_1.optimizedvarchar2;
  
      lv_metric_external_table_nam optimizedvarchar2;
      lv_access_param_string optimizedvarchar2;
      lv_location_string  optimizedvarchar2;
      lv_staging_tab_col_nam_datatyp commons_utils_1.optimizedvarchar2;
      lv_logging_dir commons_utils_1.optimizedvarchar2;
  
      ex_invalid_metric_name exception;
      pragma exception_init(ex_invalid_metric_name,-20011);
  begin
  lv_proc_name := 'p_create_external_table';
  lv_loader_seq_currval := 1;
  lv_data_centre_id :='Datacentre_All';

   begin
    select metric_external_table_name into lv_metric_external_table_nam from config_metrics where metric_id=pi_metric_id ;
  
    begin
      execute immediate ' drop table '|| lv_metric_external_table_nam ;
    exception
    when others then
      if sqlcode = -00942 then --ORA-00942: table or view does not exists
        null;
      else
        raise;
      end if;
    end;
  
   exception
   when no_data_found then
     raise ex_invalid_metric_name;
   when others then
    raise_application_error(-20006,'Error in p_create_external_table with error code ' || SQLCODE || sqlerrm);
   end;

  if pi_is_create_required = 1 then
          -- calling the procedure retrieving the parameters from config_metrics AND config_metric_attributes
          commons_utils_1.p_fetch_metric_details(pi_file_date                  => pi_file_date,
                                               pi_metric_id                  => pi_metric_id,
                                               pi_data_center_id             => lower(lv_data_centre_id),
                                               pi_attach_string_to_filenam   => pi_attach_string_to_filenam,
                                               po_metric_table_name        => lv_metric_table_name,
                                               po_view_name                => lv_view_name,
                                               po_metric_input_file_path   => lv_metric_input_file_path,
                                               po_external_tab_column_list => lv_external_tab_column_list,
                                               po_staging_tab_column_list  => lv_staging_tab_column_list,
                                               po_access_parameter_col_list=> lv_access_parameter_col_list,
                                               po_ext_tab_col_nam_datatype => lv_ext_tab_col_nam_datatype,
                                               po_staging_tab_col_nam_datatyp=>lv_staging_tab_col_nam_datatyp ,
                                               po_metric_source_id         => lv_metric_source_id,
                                               po_csv_file_name            => lv_csv_file_name,
                                               po_bad_file_name            => lv_bad_file_name,
                                               po_metric_external_table_nam => lv_external_tab_name,
                                               po_metric_name               => lv_metric_name,
                                               po_metric_default_dir_name =>lv_directory_name,
                                               po_field_delimiter           => lv_field_delimiter);

        if lv_metric_source_id = 10 then
          lv_logging_dir := 'new_logging_dir';
        else
          lv_logging_dir := 'bad_dir';
        end if;
        get_access_parameter_string (
        pi_bad_file_name  =>lv_bad_file_name,
        pi_access_parameter_col_list  =>lv_access_parameter_col_list,
        pi_field_delimiter            =>lv_field_delimiter,
        pi_logging_dir => lv_logging_dir,
        po_access_param_string =>lv_access_param_string);
  
      get_location_string (pi_csv_file_name =>lv_csv_file_name, po_location_string =>lv_location_string);
      
      lv_execute_ddl:= q'$ CREATE TABLE $'||lv_external_tab_name||q'$ ( $'||lv_ext_tab_col_nam_datatype||q'$ ) ORGANIZATION EXTERNAL
                                        (
                                          TYPE ORACLE_LOADER
                                          DEFAULT DIRECTORY $'||lv_directory_name||lv_access_param_string
                                          || lv_location_string|| q'$ )reject limit unlimited $';

       execute immediate lv_execute_ddl;
  
  end if;
  
  exception
  when others then
  IF SQLCODE = -20011 THEN
          commons_utils_1.p_error_logging(pi_metric_id            => pi_metric_id,
                                        pi_procedure_name       => lv_proc_name,
                                        pi_error_message        => 'Passed Metric_id ' || pi_metric_id || 'to '||lv_proc_name||' does not exists in the config_metrics table ',
                                        pi_error_in_code        => SQLCODE,
                                        pi_tel_error_event_date => pi_file_date);
                                        raise;
        ELSE
          commons_utils_1.p_error_logging(pi_metric_id            => pi_metric_id,
                                        pi_procedure_name       => lv_proc_name,
                                        pi_error_message        => 'Failed at '||lv_proc_name||' for metric '||lv_metric_name|| ' with error :- ' || SQLERRM || 'Backtraced: ' || f_get_exception_backtrace,
                                        pi_error_in_code        => SQLCODE,
                                        pi_tel_error_event_date => pi_file_date);
                                        raise;
        END IF;
  
  end p_create_external_table;


  PROCEDURE p_validate_insert_inputs(pi_farm_id                    IN config_farms.farm_id%TYPE,
                                     pi_farm_name                  IN config_farms.farm_name%TYPE DEFAULT NULL,
                                     pi_farm_application_url       IN config_farms.farm_application_url%TYPE,
                                     pi_data_center_id             IN config_data_centers.data_center_id%TYPE,
                                     pi_data_center_name           IN config_data_centers.data_center_name%TYPE,
                                     pi_data_center_ocm_url        IN config_data_centers.data_center_ocm_url%TYPE DEFAULT NULL,
                                     pi_data_center_flag           IN config_data_centers.data_center_flag%TYPE,
                                     pi_data_centre_graphite_cnnct IN config_data_centers.data_centre_graphite_connect%TYPE DEFAULT NULL,
                                     pi_cp_id                      IN config_client_projects.cp_id%TYPE,
                                     pi_cp_client_nm               IN config_client_projects.cp_client_name%TYPE DEFAULT NULL,
                                     pi_cp_client_id               IN config_client_projects.cp_client_id%TYPE,
                                     pi_envi_uuid                  IN config_environments.env_uuid%TYPE,
                                     pi_envi_id                    IN config_environments.env_id%TYPE,
                                       pi_env_env_type_id            IN config_environments.env_env_type_id%TYPE,
                                     pi_envi_name                  IN config_environments.env_name%TYPE,
                                     pi_status                     IN config_environments.status%TYPE,
                                     pi_config_table               IN VARCHAR2,
                                     po_string                     OUT VARCHAR2) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Validates the received inputs 
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
  BEGIN

    CASE upper(pi_config_table)
      WHEN 'CONFIG_ENVIRONMENTS' THEN
        IF pi_envi_uuid IS NULL THEN
          po_string := 'ENV_UUID is null';
        END IF;
        IF pi_envi_id IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and ENV_ID is null';
          ELSE
            po_string := ' ENV_ID is null';
          END IF;
        END IF;
        IF pi_envi_name IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and ENV_NAME is null';
          ELSE
            po_string := ' ENV_NAME is null';
          END IF;
        END IF;
          IF pi_env_env_type_id IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and ENV_ENV_TYPE_ID is null';
          ELSE
            po_string := ' ENV_ENV_TYPE_ID is null';
          END IF;
        END IF;
         /* IF pi_envi_strt IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and ENV_START_DATE is null';
          ELSE
            po_string := ' ENV_START_DATE is null';
          END IF;
        END IF;
        IF pi_envi_end IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and ENV_END_DATE is null';
          ELSE
            po_string := ' ENV_END_DATE is null';
          END IF;
        END IF;
        IF pi_envi_cmnt IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and ENV_COMMENTS is null';
          ELSE
            po_string := ' ENV_COMMENTS is null';
          END IF;
        END IF;*/
        IF pi_status IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and STATUS is null';
          ELSE
            po_string := ' STATUS is null';
          END IF;
        END IF;
        IF pi_cp_id IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and ENV_CP_ID is null';
          ELSE
            po_string := ' ENV_CP_ID is null';
          END IF;
        END IF;
        IF pi_farm_id IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and ENV_FARM_ID is null';
          ELSE
            po_string := ' ENV_FARM_ID is null';
          END IF;
        END IF;
        IF pi_data_center_id IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and ENV_DATA_CENTER_ID is null';
          ELSE
            po_string := ' ENV_DATA_CENTER_ID is null';
          END IF;
        END IF;

      WHEN 'CONFIG_CLIENT_PROJECTS' THEN
        IF pi_cp_id IS NULL THEN
          po_string := ' CP_ID is null';
        END IF;
        IF pi_cp_client_id IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and CP_CLIENT_ID is null';
          ELSE
            po_string := ' CP_CLIENT_ID is null';
          END IF;
        END IF;

        IF pi_cp_client_nm IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and CP_CLIENT_NAME is null';
          ELSE
            po_string := ' CP_CLIENT_NAME is null';
          END IF;
        END IF;

        /*IF pi_cp_sb_pr_id IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and CP_SUB_PROJECT_ID is null';
          ELSE
            po_string := ' CP_SUB_PROJECT_ID is null';
          END IF;
        END IF;

        IF pi_cp_client_cmpl_nm IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and CP_CLIENT_COMPLETE_NAME is null';
          ELSE
            po_string := ' CP_CLIENT_COMPLETE_NAME is null';
          END IF;
        END IF;*/

        IF pi_data_center_id IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and CP_DATA_CENTER_ID is null';
          ELSE
            po_string := ' CP_DATA_CENTER_ID is null';
          END IF;
        END IF;

      WHEN 'CONFIG_FARMS' THEN
        IF pi_farm_id IS NULL THEN
          po_string := ' FARM_ID is null';
        END IF;
        IF pi_data_center_id IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and FARM_DATA_CENTER_ID is null';
          ELSE
            po_string := ' FARM_DATA_CENTER_ID is null';
          END IF;
        END IF;
         IF pi_farm_application_url IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and PI_FARM_APPLICATION_URL is null';
          ELSE
            po_string := ' PI_FARM_APPLICATION_URL is null';
          END IF;
        END IF;
        IF pi_farm_name IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and FARM_NAME is null';
          ELSE
            po_string := ' FARM_NAME is null';
          END IF;
        END IF;

        /*IF pi_farm_comments IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and FARM_COMMENTS is null';
          ELSE
            po_string := ' FARM_COMMENTS is null';
          END IF;
        END IF;*/

      WHEN 'CONFIG_DATA_CENTERS' THEN
        IF pi_data_center_id IS NULL THEN
          po_string := ' DATA_CENTER_ID is null';
        END IF;
        IF pi_data_center_name IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and DATA_CENTER_NAME is null';
          ELSE
            po_string := ' DATA_CENTER_NAME is null';
          END IF;
        END IF;

        IF pi_data_center_ocm_url IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and DATA_CENTER_OCM_URL is null';
          ELSE
            po_string := ' DATA_CENTER_OCM_URL is null';
          END IF;
        END IF;

        /*IF pi_data_center_comments IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and DATA_CENTER_COMMENTS is null';
          ELSE
            po_string := ' DATA_CENTER_COMMENTS is null';
          END IF;
        END IF;*/

        IF pi_data_center_flag IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string || ' and DATA_CENTER_FLAG is null';
          ELSE
            po_string := ' DATA_CENTER_FLAG is null';
          END IF;
        END IF;

        IF pi_data_centre_graphite_cnnct IS NULL THEN
          IF length(po_string) > 0 THEN
            po_string := po_string ||
                         ' and DATA_CENTRE_GRAPHITE_CONNECT is null';
          ELSE
            po_string := ' DATA_CENTRE_GRAPHITE_CONNECT is null';
          END IF;
        END IF;
    END CASE;
  EXCEPTION
     WHEN CASE_NOT_FOUND  then
     ROLLBACK;
     commons_utils_1.p_error_logging(pi_metric_id    => '',
                                    pi_procedure_name => 'p_validate_insert_inputs',
                                    pi_error_message  => 'Passed table '||pi_config_table||' is not supported Backtraced : ' || f_get_exception_backtrace,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => null);
      RAISE;
    WHEN OTHERS THEN
      ROLLBACK;
      commons_utils_1.p_error_logging(pi_metric_id    => '',
                                  pi_procedure_name => 'p_validate_insert_inputs',
                                  pi_error_message  => 'Error in p_validate_insert_inputs Backtraced : ' || f_get_exception_backtrace,
                                  pi_error_in_code  => SQLCODE,
                                  pi_tel_error_event_date => null);
      RAISE;
  END p_validate_insert_inputs;


  PROCEDURE p_validate_delete_inputs(pi_envi_uuid      IN config_environments.env_uuid%TYPE,
                                     pi_cp_id          IN config_client_projects.cp_id%TYPE,
                                     pi_data_center_id IN config_data_centers.data_center_id%TYPE,
                                     pi_farm_id        IN config_farms.farm_id%TYPE,
                                     pi_config_table   IN VARCHAR2,
                                     po_string         OUT VARCHAR2) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Validates the received inputs 
  
  -- Change description :
  -- -----------------------------------------------------------------------------                                     
  BEGIN
    CASE upper(pi_config_table)

      WHEN 'CONFIG_ENVIRONMENTS' THEN
        IF pi_envi_uuid IS NULL THEN
          po_string := 'ENV_UUID is null';
        END IF;

      WHEN 'CONFIG_CLIENT_PROJECTS' THEN
        IF pi_cp_id IS NULL THEN
          po_string := 'CP_ID is null';
        END IF;

      WHEN 'CONFIG_FARMS' THEN
        IF pi_farm_id IS NULL THEN
          po_string := 'FARM_ID is null';
        END IF;

      WHEN 'CONFIG_DATA_CENTERS' THEN
        IF pi_data_center_id IS NULL THEN
          po_string := 'DATA_CENTER_ID is null';
        END IF;

    END CASE;

  EXCEPTION
    WHEN CASE_NOT_FOUND  then
     ROLLBACK;
     commons_utils_1.p_error_logging(pi_metric_id    => '',
                                    pi_procedure_name => 'p_validate_delete_inputs',
                                    pi_error_message  => 'Passed table '||pi_config_table||' is not supported Backtraced : ' || f_get_exception_backtrace,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => null);
      RAISE;
    WHEN OTHERS THEN
      ROLLBACK;
      commons_utils_1.p_error_logging(pi_metric_id    => '',
                                  pi_procedure_name => 'p_validate_delete_inputs',
                                  pi_error_message  => 'Error in p_validate_delete_inputs Backtraced : ' || f_get_exception_backtrace,
                                  pi_error_in_code  => SQLCODE,
                                  pi_tel_error_event_date => null);

      RAISE;
  END p_validate_delete_inputs;


  PROCEDURE p_load_phs_metrics_for_dates(pin_from_date date,pin_to_date date) is
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that does the loading of PHS metrics used for manual backdated loading 
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
      lv_processing_date date;
      lv_to_indx pls_integer;
      lv_from_date date ;
      lv_to_date date ;
      lv_bad_file_seq pls_integer;
      le_state_of_job EXCEPTION;
      lv_badroot varchar2(4001);
      lv_state varchar2(4001);
      invalid_dates EXCEPTION;

    begin
        INSERT INTO TELEMETRY_MANUAL_RUN_INFO
                                              select  error_logs_seq.nextval,
                                                pin_from_date,
                                                pin_to_date,
                                                CURRENT_DATE,
                                                SYS_CONTEXT ('USERENV', 'OS_USER') ,
                                                SYS_CONTEXT ('USERENV', 'HOST') ,
                                                SYS_CONTEXT ('USERENV', 'IP_ADDRESS')  ,
                                                SYS_CONTEXT ('USERENV', 'MODULE'),
                                                SYS_CONTEXT ('USERENV', 'ISDBA'),
                                                SYS_CONTEXT ('USERENV', 'SERVER_HOST'),
                                                SYS_CONTEXT ('USERENV', 'SID')
                                                FROM DUAL ;
        -- create the job for one time use
        BEGIN
          p_job_del_Logging_bad_file_del;
          p_job_cr_Logging_bad_file_del;
        EXCEPTION
        WHEN OTHERS THEN
          raise;
        END;

        --execute immediate 'alter session set nls_date_format =''dd-mm-yyyy hh24:mi:ss''';
        lv_from_date := trunc(pin_from_date);
        lv_to_date := trunc(pin_to_date);

        begin
          SELECT pr_value
          INTO lv_badroot
          FROM properties
          WHERE pr_name = 'Logging_path';
        exception
        when others then
          commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_load_phs_metrics_for_dates',pi_description =>'Error in properties select : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace );
         raise;
        end ;

        select (lv_to_date - lv_from_date) into lv_to_indx from dual;
         if lv_to_indx < 0 then
            raise invalid_dates ;
         end if;

       -- lv_bad_file_seq := loader_seq.nextval ;          ---- enhancement for timely mail alert
        for i in 0..lv_to_indx loop
                SELECT lv_from_date + i INTO lv_processing_date FROM dual;

                -- delete the specific date folder of application metrics
                for indx in(select lv_badroot val1,lower(metric_name)||'_'||to_char(lv_processing_date,'ddmmyyyy') val2  from config_metrics where metric_id in ('15','3','2','5','11'/*,'27'*/,'28','29'/*,'32'*/)) loop
                      dbms_scheduler.set_job_argument_value(job_name       => 'DEL_PHS_METRIC_LOGFILE_JOB',argument_name  => 'path_logging_folder',argument_value => indx.val1);
                      dbms_scheduler.set_job_argument_value(job_name       => 'DEL_PHS_METRIC_LOGFILE_JOB',argument_name  => 'metric_name_date',argument_value => indx.val2);
                      dbms_scheduler.enable(NAME => 'DEL_PHS_METRIC_LOGFILE_JOB'); -- this is required since job is created in disabled mode and running it does not enable it
                      dbms_scheduler.run_job(job_name => 'DEL_PHS_METRIC_LOGFILE_JOB');
                end loop;

                LOOP
                      dbms_lock.sleep(10);
                    
                    -- using this instead of user_scheduler_jobs because of oracle's bug where status is not updated at times
                    SELECT STATUS
                    INTO lv_state
                    FROM
                      (SELECT u.STATUS,
                      row_number() over ( partition BY JOB_NAME order by ACTUAL_START_DATE DESC) rn
                      FROM user_SCHEDULER_JOB_RUN_DETAILS u
                      WHERE job_name= 'DEL_PHS_METRIC_LOGFILE_JOB'
                      )
                    WHERE rn =1 ;


                      IF lv_state   IN( 'SUCCEEDED','COMPLETED') THEN
                        EXIT;
                      ELSIF   lv_state = 'RUNNING' THEN
                        CONTINUE;
                      ELSE
                        RAISE le_state_of_job;
                      END IF;

                END LOOP;

                -- delete master table load for load
                delete from table_load_metrics WHERE trunc(LOADED_DATE) = lv_processing_date and metric_id in ('15','3','2','5','11'/*,'27'*/,'28','29'/*,'32'*/);

                -- delete the base tables of PHS metrics in DW /*('Objects_count','Optymyze_Version','Studio_App_Allowed','Studio_App_Count','Widget_Count','Used_Space')*/
                for indx in (select  METRIC_TABLE_NAME from config_metrics where metric_id in ('15','3','2','5','11'/*,'27'*/,'28','29'/*,'32'*/)) loop
                          --execute IMMEDIATE 'delete from '||indx.METRIC_TABLE_NAME ||' WHERE trunc(event_date) = trunc(to_date('''|| to_char(lv_processing_date,'dd-mm-yyyy hh24:mi:ss') ||''',''dd-mm-yyyy hh24:mi:ss''))';
                            execute IMMEDIATE 'delete from '||indx.METRIC_TABLE_NAME ||' WHERE trunc(event_date) = trunc(:lv_processing_date)' using lv_processing_date;
                end loop;

                -- delete miscellaneous tables
                delete from telemetry_error_logs WHERE trunc(TEL_ERROR_EVENT_DATE) = lv_processing_date AND tel_metric_id in ('15','3','2','5','11'/*,'27'*/,'28','29'/*,'32'*/,'PHS Metrics');-- AND UPPER(TEL_METRIC_NAME) in ('STUDIO_APP_TIME','WIDGET_LOAD_COUNT','LOGIN_SESSIONS','EMAIL_COUNT','HTTP_SESSIONS');
                commit; -- this is required since shell script opens up new session and wait for exactly same tables
        end loop;
        for i in 0..lv_to_indx loop
                SELECT lv_from_date + i INTO lv_processing_date FROM dual;

--                p_grant_read_permission(lv_processing_date);
                commons_utils_1.p_load_phs_reports_wrapper(lv_processing_date);
                commit;
        end loop ;

        -- drop the job
        BEGIN
          p_job_del_Logging_bad_file_del;
        EXCEPTION
        WHEN OTHERS THEN
          commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_load_phs_metrics_for_dates',pi_description =>'Error in p_job_del_Logging_bad_file_del : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace );
          raise;
        END;
      EXCEPTION
        WHEN le_state_of_job THEN
        commons_utils_1.p_error_logging(pi_metric_id    => 'PHS Metrics',
                                      pi_procedure_name => 'p_load_phs_metrics_for_dates',
                                      pi_error_message  => 'The state of the job  DEL_PHS_METRIC_LOGFILE_JOB at  ' || sysdate || 'was '|| lv_state || 'hence deleting of Log files for PHS metrics did not take place ',
                                      pi_error_in_code  => SQLCODE,
                                      pi_tel_error_event_date => lv_processing_date);
               -- drop the job
        BEGIN
          p_job_del_Logging_bad_file_del;
        EXCEPTION
        WHEN OTHERS THEN
          commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_load_phs_metrics_for_dates',pi_description =>'Error in p_job_del_Logging_bad_file_del 2nd one : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace );
          raise;
        END;
       raise_application_error(-20006,'The state of the job  DEL_PHS_METRIC_LOGFILE_JOB at  ' || sysdate || 'was '|| lv_state || 'hence deleting of Log files for PHS metrics did not take place ' );

        WHEN invalid_dates THEN
        commons_utils_1.p_error_logging(pi_metric_id    => 'PHS Metrics',
                                      pi_procedure_name => 'p_load_phs_metrics_for_dates',
                                      pi_error_message  => ' To_date Input '||pin_to_date|| ' must be Greater than or equal to from_date Input'||pin_from_date||'. Please check the dates provided to the API',
                                      pi_error_in_code  => SQLCODE,
                                      pi_tel_error_event_date => lv_processing_date);
        -- drop the job
        BEGIN
          p_job_del_Logging_bad_file_del;
        EXCEPTION
        WHEN OTHERS THEN
          commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_load_phs_metrics_for_dates',pi_description =>'Error in p_job_del_Logging_bad_file_del invalid_dates exception: '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace );
        raise;
        END;
        raise_application_error(-20006,' To_date Input '||pin_to_date|| ' must be Greater than or equal to from_date Input'||pin_from_date||'. Please check the dates provided to the API' );

        WHEN OTHERS THEN
        commons_utils_1.p_error_logging(pi_metric_id            =>  'PHS Metrics',
                                      pi_procedure_name       => 'p_load_phs_metrics_for_dates',
                                      pi_error_message        => 'Error in p_load_phs_metrics_for_dates : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => lv_processing_date);
        -- drop the job
        BEGIN
          p_job_del_Logging_bad_file_del;
        EXCEPTION
        WHEN OTHERS THEN
          commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_load_phs_metrics_for_dates',pi_description =>'Error in p_job_del_Logging_bad_file_del OTHERS EXCEPTION : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace );
          raise;
        END;
        RAISE;
    END p_load_phs_metrics_for_dates;


  PROCEDURE p_load_app_metrics_for_dates(pin_from_date date,pin_to_date date,pin_root varchar2) is
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that does the loading of Application metrics used for manual backdated loading 
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    lv_processing_date date;
    lv_to_indx pls_integer;
    lv_from_date date ;
    lv_to_date date ;
    lv_root varchar2(4001);
    lv_state varchar2(4001);
    lv_badroot varchar2(4001);
    lv_bad_file_seq pls_integer;
  
    le_state_of_job EXCEPTION;
    invalid_dates EXCEPTION;

    begin
  
    INSERT INTO TELEMETRY_MANUAL_RUN_INFO
                                                select  error_logs_seq.nextval,
                                                  pin_from_date,
                                                  pin_to_date,
                                                  CURRENT_DATE,
                                                  SYS_CONTEXT ('USERENV', 'OS_USER') ,
                                                  SYS_CONTEXT ('USERENV', 'HOST') ,
                                                  SYS_CONTEXT ('USERENV', 'IP_ADDRESS')  ,
                                                  SYS_CONTEXT ('USERENV', 'MODULE'),
                                                  SYS_CONTEXT ('USERENV', 'ISDBA'),
                                                  SYS_CONTEXT ('USERENV', 'SERVER_HOST'),
                                                  SYS_CONTEXT ('USERENV', 'SID')
                                                  FROM DUAL ;
  
    -- create the job for one time use
    BEGIN
      p_job_delete_app_met_fol_del;
      p_job_create_app_met_fol_del;
    EXCEPTION
    WHEN OTHERS THEN
      raise;
    END;
  
    lv_root := pin_root;
    lv_from_date := trunc(pin_from_date);
    lv_to_date := trunc(pin_to_date);
  
    begin
      SELECT pr_value
      INTO lv_badroot
      FROM properties
      WHERE pr_name = 'Logging_path';
    exception
    when others then
     raise;
    end ;
  
    select (lv_to_date - lv_from_date) into lv_to_indx from dual;
    if lv_to_indx < 0 then
      raise invalid_dates ;
    end if;
  
      for i in 0..lv_to_indx loop
              SELECT lv_from_date + i INTO lv_processing_date FROM dual;
              delete from table_fetch_metrics WHERE trunc(fetched_DATE) = lv_processing_date and METRIC_OR_GROUP_NAME = 'APPLICATION_METRICS';
  
              -- delete the specific date folder of application metrics
              for indx in(select lv_root||'/Metric_' || metric_name ||'/'  ||to_char(lv_processing_date,'ddmmyyyy') val1,lv_badroot val2,lower(metric_name)||'_'||to_char(lv_processing_date,'ddmmyyyy') val3  from config_metrics where metric_id in (21,1,4,30,31,37,38,39,40,44,45,52,53,56,58,61,112)) loop
                    dbms_scheduler.set_job_argument_value(job_name       => 'DEL_APP_METRIC_FOLDER_JOB',argument_name  => 'path_csv_folder',argument_value => indx.val1);
                    dbms_scheduler.set_job_argument_value(job_name       => 'DEL_APP_METRIC_FOLDER_JOB',argument_name  => 'path_logging_folder',argument_value => indx.val2);
                    dbms_scheduler.set_job_argument_value(job_name       => 'DEL_APP_METRIC_FOLDER_JOB',argument_name  => 'metric_name_date',argument_value => indx.val3);
                    dbms_scheduler.enable(NAME => 'DEL_APP_METRIC_FOLDER_JOB');-- this is required since job is created in disabled mode and running it does not enable it
                    dbms_scheduler.run_job(job_name => 'DEL_APP_METRIC_FOLDER_JOB');
              end loop;
  
              LOOP
                    dbms_lock.sleep(10);
  
                  -- using this instead of user_scheduler_jobs because of oracle's bug where status is not updated at times
                  SELECT STATUS
                  into lv_state
                  FROM
                    (SELECT u.STATUS,
                      row_number() over ( partition BY JOB_NAME order by ACTUAL_START_DATE DESC) rn
                    FROM user_SCHEDULER_JOB_RUN_DETAILS u
                    WHERE job_name= 'DEL_APP_METRIC_FOLDER_JOB'
                    )
                  WHERE rn =1 ;
  
                    IF lv_state   IN( 'SUCCEEDED','COMPLETED') THEN
                      EXIT;
                    ELSIF   lv_state = 'RUNNING' THEN
                      CONTINUE;
                    ELSE
                      RAISE le_state_of_job;
                    END IF;
  
              END LOOP;
  
              -- delete master table load for load /*Email_Count,Http_Sessions,Login_sessions,Studio_App_Time,Widget_Load_Count  */
              delete from table_load_metrics WHERE trunc(LOADED_DATE) = lv_processing_date and metric_id in ('21','1','4','30','31','37','38','39','40','44','45','52','53','56','58','61','112');
  
              -- delete the base tables of application metrics in DW /*Email_Count,Http_Sessions,Login_sessions,Studio_App_Time,Widget_Load_Count  */
              for indx in (select  METRIC_TABLE_NAME from config_metrics where metric_id in ('21','1','4','30','31','37','38','39','40','44','45','52','53','56','58','61','112')) loop
                            execute IMMEDIATE 'delete from '||indx.METRIC_TABLE_NAME ||' WHERE trunc(event_time) = trunc(:lv_processing_date)' using lv_processing_date;
                          --execute IMMEDIATE 'delete from '||indx.METRIC_TABLE_NAME ||' WHERE trunc(event_time) = trunc(to_date('''|| lv_processing_date ||''',''dd-mm-yyyy hh24:mi:ss''))';
              end loop;
  
              -- delete miscellaneous tables
              delete from telemetry_error_logs WHERE trunc(TEL_ERROR_EVENT_DATE) = lv_processing_date AND tel_metric_id in ('21','1','4','30','31','37','38','39','40','44','45','52','53','56','58','61','112','APPLICATION_METRICS');-- AND UPPER(TEL_METRIC_NAME) in ('STUDIO_APP_TIME','WIDGET_LOAD_COUNT','LOGIN_SESSIONS','EMAIL_COUNT','HTTP_SESSIONS');
              commit; -- this is required since shell script opens up new session and wait for exactly same tables
      end loop;
      for i in 0..lv_to_indx loop
              SELECT lv_from_date + i INTO lv_processing_date FROM dual;
  
                commons_utils_1.p_fetch_app_metrics_wrapper(lv_processing_date,pi_attach_string_to_filenam => 'DW_INPUT');
                commons_utils_1.p_load_app_metrics_wrapper(lv_processing_date);
                commit;
   end loop ;
--      IF TRUNC(lv_processing_date)=TRUNC(SYSDATE-1) THEN                 ---- OF-88012
        --merge to update config_environment with latest Optymye_version
--          p_merge_config_environmnt_http(pi_processing_date=>lv_processing_date );
--      END IF;
  
         -- drop the job
      BEGIN
        p_job_delete_app_met_fol_del;
        null;
      EXCEPTION
      WHEN OTHERS THEN
        raise;
      END;
  
    EXCEPTION
      WHEN le_state_of_job THEN
          commons_utils_1.p_error_logging(pi_metric_id    => 'APPLICATION_METRICS',
                                        pi_procedure_name => 'p_load_app_metrics_for_dates',
                                        pi_error_message  => 'The state of the job  FETCH_APP_METRIC_JOB at --> ' || sysdate || 'was '|| lv_state || 'hence fetching of application metrics did not take place ',
                                        pi_error_in_code  => SQLCODE,
                                        pi_tel_error_event_date => lv_processing_date);
        -- drop the job
        BEGIN
          p_job_delete_app_met_fol_del;
        EXCEPTION
        WHEN OTHERS THEN
          raise;
        END;
        raise_application_error(-20006,'The state of the job  FETCH_APP_METRIC_JOB at  ' || sysdate || 'was '|| lv_state || 'hence fetching of application metrics did not take place ' );
     WHEN invalid_dates THEN
          commons_utils_1.p_error_logging(pi_metric_id    => 'APPLICATION_METRICS',
                                        pi_procedure_name => 'p_load_app_metrics_for_dates',
                                        pi_error_message  => ' To_date Input '||pin_to_date|| ' must be Greater than or equal to from_date Input'||pin_from_date||'. Please check the dates provided to the API',
                                        pi_error_in_code  => SQLCODE,
                                        pi_tel_error_event_date => lv_processing_date);
        -- drop the job
        BEGIN
          p_job_delete_app_met_fol_del;
        EXCEPTION
        WHEN OTHERS THEN
          raise;
        END;
        raise_application_error(-20006,' To_date Input '||pin_to_date|| ' must be Greater than or equal to from_date Input'||pin_from_date||'. Please check the dates provided to the API' );
      WHEN OTHERS THEN
        commons_utils_1.p_error_logging(pi_metric_id    => 'APPLICATION_METRICS',
                                      pi_procedure_name => 'p_load_app_metrics_for_dates',
                                      pi_error_message  => 'Error in p_load_app_metrics_for_dates : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace,
                                      pi_error_in_code  => SQLCODE,
                                      pi_tel_error_event_date => lv_processing_date);
  
        -- drop the job
        BEGIN
          p_job_delete_app_met_fol_del;
        EXCEPTION
        WHEN OTHERS THEN
          raise;
        END;
       RAISE;
  END p_load_app_metrics_for_dates;
  

  PROCEDURE p_load_os_metrics_for_dates(pin_from_date date,pin_to_date date) is
  -- -----------------------------------------------------------------------------
  -- Author         : Paanshul Chowdhary
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that does the loading of OS metrics used for manual backdated loading 
  
  -- Change description :
  -- -----------------------------------------------------------------------------   
      lv_processing_date date;
      lv_to_indx pls_integer;
      lv_from_date date ;
      lv_to_date date ;
      lv_bad_file_seq pls_integer;
      le_state_of_job EXCEPTION;
      lv_badroot varchar2(4001);
      lv_state varchar2(4001);
      invalid_dates EXCEPTION;
     
    begin
        INSERT INTO TELEMETRY_MANUAL_RUN_INFO
                                              select  error_logs_seq.nextval,
                                                pin_from_date,
                                                pin_to_date,
                                                CURRENT_DATE,
                                                SYS_CONTEXT ('USERENV', 'OS_USER') ,
                                                SYS_CONTEXT ('USERENV', 'HOST') ,
                                                SYS_CONTEXT ('USERENV', 'IP_ADDRESS')  ,
                                                SYS_CONTEXT ('USERENV', 'MODULE'),
                                                SYS_CONTEXT ('USERENV', 'ISDBA'),
                                                SYS_CONTEXT ('USERENV', 'SERVER_HOST'),
                                                SYS_CONTEXT ('USERENV', 'SID')
                                                FROM DUAL ;
        -- create the job for one time use
        BEGIN
          p_job_OS_Log_bad_file_del;
          p_job_OS_Log_bad_file_cr;
        EXCEPTION
        WHEN OTHERS THEN
          raise;
        END;
        --execute immediate 'alter session set nls_date_format =''dd-mm-yyyy hh24:mi:ss''';
        lv_from_date := trunc(pin_from_date);
        lv_to_date := trunc(pin_to_date);
        begin
          SELECT pr_value
          INTO lv_badroot
          FROM properties
          WHERE pr_name = 'Logging_path';
        exception
        when others then
         raise;
        end ;
        select (lv_to_date - lv_from_date) into lv_to_indx from dual;
         if lv_to_indx < 0 then
            raise invalid_dates ;
         end if;
       
        for i in 0..lv_to_indx loop
                SELECT lv_from_date + i INTO lv_processing_date FROM dual;
                -- delete the specific date folder of application metrics
                for indx in(select lv_badroot val1,lower(metric_name)||'_'||to_char(lv_processing_date,'ddmmyyyy') val2  from config_metrics where metric_id in ('25')) loop
                      dbms_scheduler.set_job_argument_value(job_name       => 'DEL_OS_METRIC_LOGFILE_JOB',argument_name  => 'path_logging_folder',argument_value => indx.val1);
                      dbms_scheduler.set_job_argument_value(job_name       => 'DEL_OS_METRIC_LOGFILE_JOB',argument_name  => 'metric_name_date',argument_value => indx.val2);
                      dbms_scheduler.enable(NAME => 'DEL_OS_METRIC_LOGFILE_JOB'); -- this is required since job is created in disabled mode and running it does not enable it
                      dbms_scheduler.run_job(job_name => 'DEL_OS_METRIC_LOGFILE_JOB');
                end loop;
                LOOP
                      dbms_lock.sleep(10);
                      
                    -- using this instead of user_scheduler_jobs because of oracle's bug where status is not updated at times
                    SELECT STATUS
                    INTO lv_state
                    FROM
                      (SELECT u.STATUS,
                      row_number() over ( partition BY JOB_NAME order by ACTUAL_START_DATE DESC) rn
                      FROM user_SCHEDULER_JOB_RUN_DETAILS u
                      WHERE job_name= 'DEL_OS_METRIC_LOGFILE_JOB'
                      )
                    WHERE rn =1 ;

                      IF lv_state   IN( 'SUCCEEDED','COMPLETED') THEN
                        EXIT;
                      ELSIF   lv_state = 'RUNNING' THEN
                        CONTINUE;
                      ELSE
                        RAISE le_state_of_job;
                      END IF;
                END LOOP;
                -- delete master table load for load
                delete from table_load_metrics WHERE trunc(LOADED_DATE) = lv_processing_date and metric_id in ('25');
                -- delete the base tables of OS metrics in DW /*('Used_Space')*/
                for indx in (select  METRIC_TABLE_NAME from config_metrics where metric_id in ('25')) loop
                          --execute IMMEDIATE 'delete from '||indx.METRIC_TABLE_NAME ||' WHERE trunc(event_date) = trunc(to_date('''|| to_char(lv_processing_date,'dd-mm-yyyy hh24:mi:ss') ||''',''dd-mm-yyyy hh24:mi:ss''))';
                            execute IMMEDIATE 'delete from '||indx.METRIC_TABLE_NAME ||' WHERE trunc(event_date) = trunc(:lv_processing_date)' using lv_processing_date;
                end loop;
                -- delete miscellaneous tables
                delete from telemetry_error_logs WHERE trunc(TEL_ERROR_EVENT_DATE) = lv_processing_date AND tel_metric_id in ('25');-- AND UPPER(TEL_METRIC_NAME) in ('Used_Space');
                commit; -- this is required since shell script opens up new session and wait for exactly same tables
        end loop;
        for i in 0..lv_to_indx loop
                SELECT lv_from_date + i INTO lv_processing_date FROM dual;
--                p_grant_read_permission(lv_processing_date);
                commons_utils_1.p_load_OS_reports_wrapper(lv_processing_date);
                commit;
        end loop ;
        -- drop the job
        BEGIN
          p_job_OS_Log_bad_file_del;
        EXCEPTION
        WHEN OTHERS THEN
          raise;
        END;
      EXCEPTION
        WHEN le_state_of_job THEN
        commons_utils_1.p_error_logging(pi_metric_id    => 'OS Metrics',
                                      pi_procedure_name => 'p_load_os_metrics_for_dates',
                                      pi_error_message  => 'The state of the job  DEL_OS_METRIC_LOGFILE_JOB at  ' || sysdate || 'was '|| lv_state || 'hence deleting of Log files for OS metrics did not take place ',
                                      pi_error_in_code  => SQLCODE,
                                      pi_tel_error_event_date => lv_processing_date);
               -- drop the job
        BEGIN
          p_job_OS_Log_bad_file_del;
        EXCEPTION
        WHEN OTHERS THEN
          raise;
        END;
       raise_application_error(-20006,'The state of the job  DEL_OS_METRIC_LOGFILE_JOB at  ' || sysdate || 'was '|| lv_state || 'hence deleting of Log files for OS metrics did not take place ' );
        WHEN invalid_dates THEN
        commons_utils_1.p_error_logging(pi_metric_id    => 'OS Metrics',
                                      pi_procedure_name => 'p_load_os_metrics_for_dates',
                                      pi_error_message  => ' To_date Input '||pin_to_date|| ' must be Greater than or equal to from_date Input'||pin_from_date||'. Please check the dates provided to the API',
                                      pi_error_in_code  => SQLCODE,
                                      pi_tel_error_event_date => lv_processing_date);
        -- drop the job
        BEGIN
          p_job_OS_Log_bad_file_del;
        EXCEPTION
        WHEN OTHERS THEN
          raise;
        END;
        raise_application_error(-20006,' To_date Input '||pin_to_date|| ' must be Greater than or equal to from_date Input'||pin_from_date||'. Please check the dates provided to the API' );
        WHEN OTHERS THEN
        commons_utils_1.p_error_logging(pi_metric_id            =>  'OS Metrics',
                                      pi_procedure_name       => 'p_load_os_metrics_for_dates',
                                      pi_error_message        => 'Error in p_load_os_metrics_for_dates : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => lv_processing_date);
        -- drop the job
        BEGIN
          p_job_OS_Log_bad_file_del;
        EXCEPTION
        WHEN OTHERS THEN
          raise;
        END;
        RAISE;
    END p_load_os_metrics_for_dates;


  PROCEDURE p_load_ws_metrics_for_dates(pin_from_date date,pin_to_date date) is
  -- -----------------------------------------------------------------------------
  -- Author         : Paanshul Chowdhary
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that does the loading of WS metrics used for manual backdated loading 
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    lv_processing_date date;
    lv_to_indx pls_integer;
    lv_state varchar2(4001);
    lv_badroot varchar2(4001);
    lv_bad_file_seq pls_integer;
    lv_from_date date ;
    lv_to_date date ;
  
    invalid_dates EXCEPTION;
    le_state_of_job EXCEPTION;
  
    begin
  
    INSERT INTO TELEMETRY_MANUAL_RUN_INFO
                                                select  error_logs_seq.nextval,
                                                  pin_from_date,
                                                  pin_to_date,
                                                  CURRENT_DATE,
                                                  SYS_CONTEXT ('USERENV', 'OS_USER') ,
                                                  SYS_CONTEXT ('USERENV', 'HOST') ,
                                                  SYS_CONTEXT ('USERENV', 'IP_ADDRESS')  ,
                                                  SYS_CONTEXT ('USERENV', 'MODULE'),
                                                  SYS_CONTEXT ('USERENV', 'ISDBA'),
                                                  SYS_CONTEXT ('USERENV', 'SERVER_HOST'),
                                                  SYS_CONTEXT ('USERENV', 'SID')
                                                  FROM DUAL ;
  
  
  
    --execute immediate 'alter session set nls_date_format =''dd-mm-yyyy hh24:mi:ss''';
  
    lv_from_date := trunc(pin_from_date);
    lv_to_date := trunc(pin_to_date);
  
    begin
      SELECT pr_value
      INTO lv_badroot
      FROM properties
      WHERE pr_name = 'Logging_path';
    exception
    when others then
     raise;
    end ;
  
    select (lv_to_date - lv_from_date) into lv_to_indx from dual;
    if lv_to_indx < 0 then
      raise invalid_dates ;
    end if;
  
   -- lv_bad_file_seq := loader_seq.nextval ;        ----- enhancement for timely mail alert
  
      for i in 0..lv_to_indx loop
              SELECT lv_from_date + i INTO lv_processing_date FROM dual;
     -- delete master table load for load \*Email_Count,Http_Sessions,Login_sessions,Studio_App_Time,Widget_Load_Count  *\
              delete from table_load_metrics WHERE trunc(LOADED_DATE) = lv_processing_date and metric_id in ('32','33','34','35','36','41','42','43','48','49','50','51','54','55','57','59','60','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','79','80','81','82','83','84','85','86','87','88','89','90','107','113'); ----OF-86041
  
              -- delete the base tables of webservice metrics in DW \*Email_Count,Http_Sessions,Login_sessions,Studio_App_Time,Widget_Load_Count  *\
              for indx in (select  METRIC_TABLE_NAME from config_metrics where metric_id in ('32','33','34','35','36','41','42','43','48','49','50','51','54','55','57','59','60','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','79','80','81','82','83','84','85','86','87','88','89','90','107','113')) loop            -----OF-86041
                            execute IMMEDIATE 'delete from '||indx.METRIC_TABLE_NAME ||' WHERE trunc(event_time) = trunc(:lv_processing_date)' using lv_processing_date;
                          --execute IMMEDIATE 'delete from '||indx.METRIC_TABLE_NAME ||' WHERE trunc(event_time) = trunc(to_date('''|| lv_processing_date ||''',''dd-mm-yyyy hh24:mi:ss''))';
              end loop;
  
              -- delete miscellaneous tables
              delete from telemetry_error_logs WHERE trunc(TEL_ERROR_EVENT_DATE) = lv_processing_date AND tel_metric_id in ('32','33','34','35','36','41','42','43','48','49','50','51','54','55','57','59','60','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','79','80','81','82','83','84','85','86','87','88','89','90','107','113');               ----OF-86041
              commit; -- this is required since shell script opens up new session and wait for exactly same tables
              end loop;
  
              for i in 0..lv_to_indx loop
              SELECT lv_from_date + i INTO lv_processing_date FROM dual;
        -- p_grant_read_permission(lv_processing_date);
                commons_utils_1.p_load_ws_wrapper(lv_processing_date);
                commit;
      end loop ;
  
     EXCEPTION
  
     WHEN invalid_dates THEN
          commons_utils_1.p_error_logging(pi_metric_id    => 'WEBSERVICE_METRICS',
                                        pi_procedure_name => 'p_load_ws_metrics_for_dates',
                                        pi_error_message  => ' To_date Input '||pin_to_date|| ' must be Greater than or equal to from_date Input'||pin_from_date||'. Please check the dates provided to the API',
                                        pi_error_in_code  => SQLCODE,
                                        pi_tel_error_event_date => lv_processing_date);
  
        raise_application_error(-20006,' To_date Input '||pin_to_date|| ' must be Greater than or equal to from_date Input'||pin_from_date||'. Please check the dates provided to the API' );
      WHEN OTHERS THEN
        commons_utils_1.p_error_logging(pi_metric_id    => 'WEBSERVICE_METRICS',
                                      pi_procedure_name => 'p_load_ws_metrics_for_dates',
                                      pi_error_message  => 'Error in p_load_ws_metrics_for_dates : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace,
                                      pi_error_in_code  => SQLCODE,
                                      pi_tel_error_event_date => lv_processing_date);
  
  END p_load_ws_metrics_for_dates;


  PROCEDURE p_error_logging(pi_metric_id    IN VARCHAR2,
                          pi_procedure_name IN VARCHAR2,
                          pi_error_message  IN VARCHAR2,
                          pi_error_in_code  IN VARCHAR2,
                          pi_tel_error_event_date IN DATE,
                          pi_env_id IN VARCHAR2 default null) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Paanshul Chowdhary
  -- Reviewer       : Rajput Gaurav
  -- Description    : Pragma Autonomous Transaction that helps in error logging 
  
  -- Change description :
  -- -----------------------------------------------------------------------------                          
  PRAGMA AUTONOMOUS_TRANSACTION;
  lv_metric_name varchar2(4001);

  BEGIN
     begin
         select upper(metric_name) into lv_metric_name from config_metrics where metric_id = to_number(pi_metric_id);
     exception
     when others then
          lv_metric_name := pi_metric_id;
     end ;
    
    INSERT INTO telemetry_error_logs
      (tel_error_id,
       tel_metric_id,
       tel_metric_name,
       tel_procedure_name,
       tel_error_message,
       tel_error_code,
       tel_error_log_date,
       tel_error_event_date,
       os_user      ,
       host         ,
       ip_address   ,
       module       ,
       is_dba       ,
       server_host  ,
       session_id   ,
	   TEL_ITERATION_NUMBER,
     tel_env_id)  --OF-103077
    select
       error_logs_seq.nextval,
       pi_metric_id,
       lv_metric_name,
       pi_procedure_name,
       pi_error_message,
       pi_error_in_code,
       CURRENT_DATE,
       pi_tel_error_event_date,
       SYS_CONTEXT ('USERENV', 'OS_USER') ,
       SYS_CONTEXT ('USERENV', 'HOST') ,
       SYS_CONTEXT ('USERENV', 'IP_ADDRESS')  ,
       SYS_CONTEXT ('USERENV', 'MODULE'),
       SYS_CONTEXT ('USERENV', 'ISDBA'),
       SYS_CONTEXT ('USERENV', 'SERVER_HOST'),
       SYS_CONTEXT ('USERENV', 'SID'),
	   SYS_CONTEXT('GC_LOADER_SEQ_CUR_VAL', 'GLOBAL_ATTRIBUTE'),
     pi_env_id--OF-103077
       FROM DUAL
       ;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      Rollback;
  END p_error_logging;


  PROCEDURE p_drop_external_table(pi_table_name IN VARCHAR2) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Paanshul Chowdhary
  -- Reviewer       : Rajput Gaurav
  -- Description    : Drops the external table 
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
  PRAGMA AUTONOMOUS_TRANSACTION;
    lv_sql_drop_external_table VARCHAR2(4001 CHAR);
  BEGIN
    FOR c IN (SELECT table_name
                FROM user_tables
               WHERE table_name IN (pi_table_name)) LOOP

      lv_sql_drop_external_table := 'DROP TABLE ' || c.table_name;
      EXECUTE IMMEDIATE lv_sql_drop_external_table;

    END LOOP;
  exception
  when others then
          raise_application_error(-20006,'Error in p_drop_external_table with error ' || sqlcode || sqlerrm );
  END p_drop_external_table;


  FUNCTION f_create_directory(fi_path        IN VARCHAR2,
                              fi_metric_name IN VARCHAR2) RETURN VARCHAR2 IS
  -- -----------------------------------------------------------------------------
  -- Author         : Paanshul Chowdhary
  -- Reviewer       : Rajput Gaurav
  -- Description    : Creates a Directory
  
  -- Change description :
  -- -----------------------------------------------------------------------------                            
   PRAGMA AUTONOMOUS_TRANSACTION;
    fo_directory_name VARCHAR2(4001 CHAR);
    lv_ddl             CLOB;
  BEGIN
    fo_directory_name := substr(upper('DIR_' || fi_metric_name || '_' ||telemetry_directory_name_seq.nextval),1,30);

    lv_ddl := 'CREATE OR REPLACE DIRECTORY ' || fo_directory_name ||' AS ''' || fi_path || '''';

    EXECUTE IMMEDIATE lv_ddl;
    RETURN fo_directory_name;
   exception
  when others then
        raise_application_error(-20006,'Error in f_create_directory with error code '|| sqlcode || sqlerrm);
  END f_create_directory;


  PROCEDURE p_create_external_table(pi_column_datatype_list IN VARCHAR2,
                                    pi_directory_name         IN VARCHAR2,
                                    pi_file_name              IN VARCHAR2,
                                    pi_ext_tab_source_flag    IN NUMBER,
                                    pi_fields_list            IN VARCHAR2,
                                    pi_metric_name            IN VARCHAR2,
                                    pi_file_date              IN DATE,
                                    pi_data_center            IN VARCHAR2,
                                    po_external_table_name    OUT VARCHAR2
                                    ) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Paanshul Chowdhary
  -- Reviewer       : Rajput Gaurav
  -- Description    : Creates a External table 
  
  -- Change description :
  -- -----------------------------------------------------------------------------                                    
    PRAGMA AUTONOMOUS_TRANSACTION;
    lv_table_name            VARCHAR2(4001 CHAR) ;
    lv_create_external_table CLOB;
    lv_load_seq     number ;
    lv_date     VARCHAR2(4001 CHAR) ;
  BEGIN
    lv_table_name  := 'EXTERNAL_' ||table_name_seq.nextval;
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_load_seq from dual;
    BEGIN
    p_drop_external_table(pi_table_name => lv_table_name);

   lv_date:= to_char(pi_file_date,'ddmmyyyy');


    EXCEPTION
    WHEN OTHERS THEN
      IF SQLCODE = -00942 THEN --ORA-00942: table or view does not exist
        NULL;
      ELSE
        RAISE;
      END IF;
    END;

    --Application,OS scripts,DW config tables,Database Sources
    IF (pi_ext_tab_source_flag NOT IN (2,5,6)) THEN
      lv_create_external_table := 'CREATE TABLE ' || lv_table_name || '
                                  ( ' ||
                                 pi_column_datatype_list || ' )
                                  ORGANIZATION EXTERNAL
                                  (
                                    TYPE ORACLE_LOADER
                                    DEFAULT DIRECTORY ' ||
                                 pi_directory_name || '
                                    ACCESS PARAMETERS ( RECORDS DELIMITED BY NEWLINE skip 1
                                     BADFILE bad_dir : '''||lower(pi_metric_name)||'_'||lv_date||'_'||'datacentre_'||lower(pi_data_center)||'_'||lv_load_seq||'.bad''
                                     LOGFILE bad_dir : '''||lower(pi_metric_name)||'_'||lv_date||'_'||'datacentre_'||lower(pi_data_center)||'_'||lv_load_seq||'.log''
                                                        FIELDS TERMINATED BY ''\t''
                                                        missing field values are null
                                                       (
                                                       ' ||
                                 pi_fields_list || '

                                                       )

                                                       )
                                    LOCATION (''' ||
                                 pi_file_name || ''')
                                  )
                                  reject limit unlimited';


    ELSE
    --SPM Schema,OCM (2,5)
              lv_create_external_table := 'CREATE TABLE ' || lv_table_name || '
                                  ( ' ||
                                 pi_column_datatype_list || '  )
                                  ORGANIZATION EXTERNAL
                                  (
                                    TYPE ORACLE_LOADER
                                    DEFAULT DIRECTORY  ' ||
                                 pi_directory_name || '
                                    ACCESS PARAMETERS ( RECORDS DELIMITED BY NEWLINE skip 1
                                      BADFILE bad_dir : '''||lower(pi_metric_name)||'_'||lv_date||'_'||'datacentre_'||lower(pi_data_center)||'_'||lv_load_seq||'.bad''
                                      LOGFILE bad_dir : '''||lower(pi_metric_name)||'_'||lv_date||'_'||'datacentre_'||lower(pi_data_center)||'_'||lv_load_seq||'.log''
                                                        FIELDS TERMINATED BY '',''
                                                        OPTIONALLY ENCLOSED BY ''"''
                                                      )
                                    LOCATION ( ''' ||
                                 pi_file_name || ''')
                                  )
                                  reject limit unlimited';
    END IF;
    EXECUTE IMMEDIATE lv_create_external_table;
    po_external_table_name := lv_table_name;
    commit;
    --SELECT MAX(TIMESTAMP) INTO max_timestamp FROM server_up_time;
    exception
    when others then
      raise_application_error(-20006,'Error in p_create_external_table with error code ' || sqlcode || sqlerrm);
  END p_create_external_table;

  PROCEDURE p_telemetry_info_logging(  pi_procedure_name        IN VARCHAR2,
                                     pi_description CLOB ) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Description    : Information Logging 
  
  -- Change description :
  -- -----------------------------------------------------------------------------                                     
  PRAGMA AUTONOMOUS_TRANSACTION;
    lv_is_logging_enable pls_integer ;
  BEGIN
  
      SELECT sys_context('gc_logging', 'global_attribute')
      INTO lv_is_logging_enable
      FROM dual; 
  
       if lv_is_logging_enable = commons_utils_1.c_logging_enable then
          INSERT INTO telemetry_info_logs
                (til_procedure_name,
                til_description,
                til_log_date,
                os_user,
                host,
                ip_address,
                module,
                is_dba,
                server_host,
                session_id
                 )
                select 
                pi_procedure_name,
                pi_description,
                CURRENT_DATE,
                SYS_CONTEXT ('USERENV', 'OS_USER') ,
                SYS_CONTEXT ('USERENV', 'HOST') ,
                SYS_CONTEXT ('USERENV', 'IP_ADDRESS')  ,
                SYS_CONTEXT ('USERENV', 'MODULE'),
                SYS_CONTEXT ('USERENV', 'ISDBA'),
                SYS_CONTEXT ('USERENV', 'SERVER_HOST'),
                SYS_CONTEXT ('USERENV', 'SID')
                FROM DUAL ;
                COMMIT;
      end if;          
  EXCEPTION
  WHEN OTHERS THEN
    NULL;
  END p_telemetry_info_logging;

  PROCEDURE p_drop_directory(pi_directory_name IN VARCHAR2)
   AS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Drops the Directory
  
  -- Change description :
  -- -----------------------------------------------------------------------------   
   PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    FOR i IN (SELECT directory_name
                FROM all_directories
               WHERE directory_name = pi_directory_name) LOOP

      EXECUTE IMMEDIATE 'DROP DIRECTORY ' || i.directory_name;

    END LOOP;
   exception
    when others then
      raise_application_error(-20006,'Error in p_drop_directory with error code ' || sqlcode || sqlerrm);
  END p_drop_directory;


  FUNCTION f_get_metric_file_name(fi_flag        IN NUMBER,
                                  fi_metric_name IN VARCHAR2,
                                  fi_date        IN DATE,
                                  fi_start_time  IN VARCHAR2,
                                  fi_end_time    IN VARCHAR2) RETURN VARCHAR2 IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Gets the Metric's Filename 
  
  -- Change description :
  -- -----------------------------------------------------------------------------                                
    lv_name_format VARCHAR2(1300 CHAR);
    lv_start_time  VARCHAR2(30);
    lv_end_time    VARCHAR2(30);
    lv_date        VARCHAR2(1300 CHAR);
  BEGIN
    IF fi_flag = 1 THEN
      lv_start_time  := to_char(fi_date, 'DDMMYYYY') || fi_start_time;
      lv_end_time    := to_char(fi_date, 'DDMMYYYY') || fi_end_time;
      lv_name_format := fi_metric_name || '_' || lv_start_time || '_' ||lv_end_time || '.csv';
      RETURN lv_name_format;
    ELSIF fi_flag = 2 THEN
      SELECT to_char(fi_date, 'YYYY-MM-DD') INTO lv_date FROM dual;
      lv_name_format := 'Metric_' || fi_metric_name || '_' || lv_date || '.csv';
      RETURN lv_name_format;
    END IF;
    exception
    when others then
      raise_application_error(-20006,'Error in f_get_metric_file_name with error code ' || sqlcode || sqlerrm);
    END f_get_metric_file_name;

  PROCEDURE refresh_mviews AS
  BEGIN
    FOR i IN (SELECT * FROM user_mviews) LOOP
    begin
      dbms_mview.refresh(i.mview_name,
                         method         => 'C',
                         atomic_refresh => FALSE);
    exception
    when others then
    commons_utils_1.p_error_logging(pi_metric_id    => 'MV REFRESH',
                                  pi_procedure_name => 'refresh_mviews',
                                  pi_error_message  => 'Failed at refresh_mviews for ' ||i.mview_name || ' with error :- ' || SQLERRM,
                                  pi_error_in_code  => SQLCODE,
                                  pi_tel_error_event_date => null);
    end;
    END LOOP;
  END;


  PROCEDURE p_get_dir_list(p_directory IN VARCHAR2) AS
    -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Gets the File List on a given path
  
  -- Change description :
  -- -----------------------------------------------------------------------------
    LANGUAGE JAVA NAME 'DirList.getList( java.lang.String )';


PROCEDURE p_get_metric_details(pi_root                       IN VARCHAR2,
                               pi_file_date                  IN DATE,
                               pi_v_metric_name              IN VARCHAR2,
                               pi_data_center_id             IN NUMBER,
                               po_v_metric_table_name        OUT VARCHAR2,
                               po_v_view_name                OUT VARCHAR2,
                               po_v_metric_input_file_format OUT VARCHAR2,
                               po_v_metric_input_file_path   OUT VARCHAR2,
                               po_v_column_list              OUT VARCHAR2,
                               po_v_column_list_date         OUT CLOB,
                               po_v_column_datatype_list     OUT VARCHAR2,
                               po_v_metric_source_id         OUT NUMBER) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Gets the Metric Details
  
  -- Change description :
  -- -----------------------------------------------------------------------------                               

    lv_date_char VARCHAR2(50 CHAR);
  BEGIN
  lv_date_char := to_char(pi_file_date, 'DDMMYYYY');

    SELECT metric_table_name,
           metric_view_name,
           metric_input_file_format,
           TRIM(REPLACE(REPLACE(REPLACE(metric_input_file_path,'Root_path', pi_root), 'Datacentre_check', 'Datacentre_' || pi_data_center_id),'DDMMYYYY', lv_date_char)) metric_input_file_path,
           listagg(metric_a_column_name, ',') within GROUP(ORDER BY metric_a_order) column_names,
           listagg(metric_a_column_name || ' ' || cma.metric_a_date_format,',') within GROUP(ORDER BY metric_a_order) column_names_date,
           listagg(metric_a_column_name || ' ' || metric_a_column_datatype,',') within GROUP(ORDER BY metric_a_order) metric_columns_datatypes,
           metric_source_id
      INTO po_v_metric_table_name,
           po_v_view_name,
           po_v_metric_input_file_format,
           po_v_metric_input_file_path,
           po_v_column_list,
           po_v_column_list_date,
           po_v_column_datatype_list,
           po_v_metric_source_id
      FROM config_metrics cm
      LEFT OUTER JOIN config_metric_attributes cma
        ON cm.metric_id = cma.metric_a_metric_id
     WHERE upper(cm.metric_name) = upper(pi_v_metric_name)
     GROUP BY metric_name,
              metric_table_name,
              metric_view_name,
              metric_input_file_format,
              metric_input_file_path,
              metric_source_id,
              metric_id,
              metric_input_file_format,
              metric_external_table_name;


  EXCEPTION
    WHEN OTHERS THEN
      raise_application_error(-20006,'Error in p_get_metric_details with error code ' || sqlcode || sqlerrm);
  END p_get_metric_details;

  PROCEDURE p_job_run_fetch_SQS_metrics (pin_heap_size varchar2,pin_metric_csv_path varchar2) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Description    : Runs the Jobs for SQS metrics
  
  -- Change description :
  -- -----------------------------------------------------------------------------                                        
  BEGIN

        dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_SQS_METRIC_JOB',
                                          argument_name  => 'HEAP_SIZE',
                                          argument_value => pin_heap_size);
        dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_SQS_METRIC_JOB',
                                          argument_name  => 'METRIC_CSV_PATH',
                                          argument_value => pin_metric_csv_path);
    
   -- dbms_scheduler.enable(NAME => 'FETCH_SQS_METRIC_JOB');
    dbms_scheduler.run_job(job_name => 'FETCH_SQS_METRIC_JOB');
  exception
  when others then
    raise_application_error(-20006,'Error in p_job_run_fetch_SQS_metrics with error code ' || sqlcode || sqlerrm);
  END p_job_run_fetch_SQS_metrics;
  

  PROCEDURE p_job_run_fetch_app_metrics (
                                         pin_action     VARCHAR2,
                                         pin_start_time NUMBER,
                                         pin_end_time   NUMBER,
                                         pi_attach_string_to_filenam varchar2,
                                         pi_heap_size   VARCHAR2,
                                         PI_JOB_IDENTIFIER VARCHAR2, --- COMBINE_JOB
                                         PI_EVENT_DATE VARCHAR2) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Runs the Jobs for application metrics
  
  -- Change description :
  -- -----------------------------------------------------------------------------                                         --- COMBINE_JOB
  BEGIN


    dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_APP_METRIC_JOB',
                                          argument_name  => 'action',
                                          argument_value => pin_action);
    dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_APP_METRIC_JOB',
                                          argument_name  => 'start_time',
                                          argument_value => pin_start_time);
    dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_APP_METRIC_JOB',
                                          argument_name  => 'end_time',
                                          argument_value => pin_end_time);
    dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_APP_METRIC_JOB',
                                          argument_name  => 'FILE_IDENTIFIER',
                                          argument_value => pi_attach_string_to_filenam);
    dbms_scheduler.set_job_argument_value(job_name   => 'FETCH_APP_METRIC_JOB',
                                          argument_name  => 'HEAP_SIZE',
                                          argument_value =>  pi_heap_size);
    dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_APP_METRIC_JOB',   --- COMBINE_JOB
                                          argument_name  => 'JOB_IDENTIFIER',
                                          argument_value =>  PI_JOB_IDENTIFIER);
    dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_APP_METRIC_JOB',
                                          argument_name  => 'EVENT_DATE',
                                          argument_value =>  PI_EVENT_DATE);


   -- dbms_scheduler.enable(NAME => 'FETCH_APP_METRIC_JOB');
    dbms_scheduler.run_job(job_name => 'FETCH_APP_METRIC_JOB');
  exception
  when others then
    raise_application_error(-20006,'Error in p_job_run_fetch_app_metrics with error code ' || sqlcode || sqlerrm);
  END p_job_run_fetch_app_metrics;


  
  
  PROCEDURE p_job_run_PR_metrics (pin_metric_name     VARCHAR2,
                                  pi_attach_string_to_filenam varchar2,
                                  pi_heap_size   VARCHAR2) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Runs the Jobs for application metrics
  
  -- Change description :
  -- -----------------------------------------------------------------------------                                         --- COMBINE_JOB
  BEGIN


    dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_PROMETHEUS_METRIC_JOB',
                                          argument_name  => 'METRIC_NAME',
                                          argument_value => pin_metric_name);
    dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_PROMETHEUS_METRIC_JOB',
                                          argument_name  => 'FILE_IDENTIFIER',
                                          argument_value => pi_attach_string_to_filenam);
       dbms_scheduler.set_job_argument_value(job_name   => 'FETCH_PROMETHEUS_METRIC_JOB',
                                          argument_name  => 'HEAP_SIZE',
                                          argument_value =>  pi_heap_size);                                      


    dbms_scheduler.run_job(job_name => 'FETCH_PROMETHEUS_METRIC_JOB');
  exception
  when others then
    raise_application_error(-20006,'Error in FETCH_PROMETHEUS_METRIC_JOB with error code ' || sqlcode || sqlerrm);
  END p_job_run_PR_metrics;



  PROCEDURE p_job_run_fetch_ws_metrics (
                                         pin_metric_farm_id NUMBER,
                                         pin_metric_env_id   NUMBER,
                                         pin_metric_name   VARCHAR2,
                                         pin_metric_source_id number,
                                         pi_metric_ws_string varchar2,
                                         pi_utf_constant     varchar2) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Runs the Jobs for webservice metrics
  
  -- Change description :
  -- -----------------------------------------------------------------------------                                         
  BEGIN

    dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_WS_METRIC_JOB',
                                          argument_name  => 'METRIC_FARM_ID',
                                          argument_value => pin_METRIC_FARM_ID);
    dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_WS_METRIC_JOB',
                                          argument_name  => 'METRIC_ENV_ID',
                                          argument_value => pin_METRIC_ENV_ID);
    dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_WS_METRIC_JOB',
                                          argument_name  => 'metric_name',
                                          argument_value => pin_metric_name);
    dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_WS_METRIC_JOB',
                                            argument_name  => 'metric_source_id',
                                            argument_value => pin_metric_source_id);
    dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_WS_METRIC_JOB',
                                          argument_name  => 'metric_ws_string',
                                          argument_value => pi_metric_ws_string);
    dbms_scheduler.set_job_argument_value(job_name       => 'FETCH_WS_METRIC_JOB',
                                            argument_name  => 'UTF_constant',
                                            argument_value => pi_utf_constant);

   -- dbms_scheduler.enable(NAME => 'FETCH_WS_METRIC_JOB');
    dbms_scheduler.run_job(job_name => 'FETCH_WS_METRIC_JOB');
  exception
  when others then
    raise_application_error(-20006,'Error in p_job_run_fetch_ws_metrics with error code ' || sqlcode || sqlerrm);
  END p_job_run_fetch_ws_metrics;


 PROCEDURE p_job_run_ocm_sync  IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Runs the Jobs for OCM Sync utility
  
  -- Change description :
  -- ----------------------------------------------------------------------------- 
  BEGIN
 -- dbms_scheduler.enable(NAME => 'FETCH_APP_METRIC_JOB');
    dbms_scheduler.run_job(job_name => 'OCM_SYNC_JOB');
  exception
  when others then
    raise_application_error(-20006,'Error in p_job_run_ocm_sync with error code ' || sqlcode || sqlerrm);
  END p_job_run_ocm_sync;
  PROCEDURE p_insert_table_fetch_metrics(pin_metric_string IN varchar2,pin_processing_date IN DATE) IS
    -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Description    : Inserts into table fetch metrics
  
  -- Change description :
  -- -----------------------------------------------------------------------------
  PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN


  Insert into TABLE_FETCH_METRICS   (METRIC_FARM_ID,
                                     METRIC_ENV_ID,
                                     METRIC_OR_GROUP_NAME,
                                     METRIC_ID,
                                     FETCHED_DATE,
                                     FETCHED_FLAG,
                                     FAILURE_DESCRIPTION) select -9999 ,-9999 ,pin_metric_string,-9999,pin_processing_date,2,NULL from DUAL;

    COMMIT;

  EXCEPTION
    when DUP_VAL_ON_INDEX THEN
    rollback;
    WHEN OTHERS THEN
      ROLLBACK;
      raise_application_error(-20006,'Error in p_insert_table_fetch_metrics with error code ' || sqlcode || sqlerrm);
  END p_insert_table_fetch_metrics;


  PROCEDURE p_fetch_app_metrics_wrapper(pin_processing_date in date, pi_attach_string_to_filenam in varchar2 default 'TEST' )  is
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that fetches the application metrics
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    lv_start_epoch_time number;
    lv_end_epoch_time   number;
    lv_proc_name  VARCHAR2(4001 CHAR) ;
    lv_metric_name VARCHAR(30 CHAR) ;
    lv_start_date date;
    lv_end_date date ;
    lv_split_value pls_integer;
    lv_Addition_factor pls_integer;
    lv_fetch_flag varchar2(4001);
    lv_state varchar2(4001);
  
    le_state_of_job EXCEPTION;
    
  BEGIN
    lv_proc_name  := 'p_fetch_app_metrics_wrapper';
    lv_metric_name := 'APPLICATION_METRICS';
    
    commons_utils_1.p_error_logging(pi_metric_id    => lv_metric_name,
                                        pi_procedure_name => lv_proc_name,
                                        pi_error_message  => 'Started fetching app metrics with Input parameter ' || pin_processing_date ||'  '  ||pi_attach_string_to_filenam ,
                                        pi_error_in_code  => SQLCODE,
                                        pi_tel_error_event_date => pin_processing_date);
  
    p_insert_table_fetch_metrics(lv_metric_name,pin_processing_date);
    
     commons_utils_1.p_error_logging(pi_metric_id    => lv_metric_name,
                                        pi_procedure_name => lv_proc_name,
                                        pi_error_message  => 'After inserting into table_fetch_metrics  '  ,
                                        pi_error_in_code  => SQLCODE,
                                        pi_tel_error_event_date => pin_processing_date);
    
    
    lv_end_date := to_date(pin_processing_date,'DD-MM-RRRR') -(1/86400) ;
    begin
        SELECT distinct cmsm.SPLIT_VALUE,tfm.fetched_flag
        INTO  lv_split_value,lv_fetch_flag
        FROM table_fetch_metrics tfm ,
          config_fetch_metrics_split cfms,
          config_metrics_splits_master cmsm
        WHERE tfm.Metric_or_group_name = lv_metric_name
        AND tfm.fetched_date           = pin_processing_date
        --AND tfm.fetched_flag           = 2
        AND tfm.Metric_or_group_name   = cfms.Metric_or_group_name
        AND cfms.split_id              = cmsm.split_id
        AND cmsm.enabled_flag          = 'Y';
    exception
    when No_data_found then
      lv_fetch_flag :=  2 ;
      lv_split_value := 1 ;
     when Others then
       raise;
     end;
  
  if lv_fetch_flag = '2'    then
  
       lv_Addition_factor :=  24/lv_split_value;
      for indx in 1..lv_split_value
      loop
  
          lv_start_date       := lv_end_date + (1/86400);
          lv_end_date         := lv_start_date + (lv_Addition_factor/24) - (1/86400);
          lv_start_epoch_time := (lv_start_date - to_date('1-1-1970 00:00:00', 'MM-DD-YYYY HH24:Mi:SS')) * 86400000;
          lv_end_epoch_time   := (lv_end_date - to_date('1-1-1970 00:00:00', 'MM-DD-YYYY HH24:Mi:SS')) * 86400000;
  
          BEGIN
           p_job_run_fetch_app_metrics('-create', lv_start_epoch_time, lv_end_epoch_time, pi_attach_string_to_filenam,'-Xmx2048m' ,'FETCH_APP',NULL); ----COMBINE_JOB 
  
            LOOP
                dbms_lock.sleep(20);

            -- using this instead of user_scheduler_jobs because of oracle's bug where status is not updated at times
              SELECT STATUS
              INTO lv_state
              FROM
              (SELECT u.STATUS,
              row_number() over ( partition BY JOB_NAME order by ACTUAL_START_DATE DESC) rn
                FROM user_SCHEDULER_JOB_RUN_DETAILS u
                WHERE job_name= 'FETCH_APP_METRIC_JOB'
                )
              WHERE rn =1 ;  

                IF lv_state   IN( 'SUCCEEDED','COMPLETED','SCHEDULED') THEN
                     EXIT;
                ELSIF   lv_state = 'RUNNING' THEN
                    CONTINUE;
                ELSE
                      RAISE le_state_of_job;
                END IF;
  
          END LOOP;
  
          EXCEPTION
           WHEN le_state_of_job THEN
          commons_utils_1.p_error_logging(pi_metric_id    => lv_metric_name,
                                        pi_procedure_name => lv_proc_name,
                                        pi_error_message  => 'The state of the job  FETCH_APP_METRIC_JOB at  ' || sysdate || 'was '|| lv_state || 'hence fetching of application metrics did not take place ',
                                        pi_error_in_code  => SQLCODE,
                                        pi_tel_error_event_date => pin_processing_date);
                                       -- RAISE;
  
            WHEN OTHERS THEN
             commons_utils_1.p_error_logging(pi_metric_id    => lv_metric_name,
                                         pi_procedure_name => lv_proc_name,
                                         pi_error_message  => 'Error in p_job_run_fetch_app_metrics : '   || SQLERRM,
                                         pi_error_in_code  => SQLCODE,
                                         pi_tel_error_event_date => pin_processing_date);
                                        -- raise;
          END;
  
        END LOOP;
  
        IF lv_state   IN( 'SUCCEEDED','COMPLETED','SCHEDULED') THEN
                UPDATE table_fetch_metrics
                SET fetched_flag           = 0
                WHERE metric_or_group_name = 'APPLICATION_METRICS'
                AND fetched_date           = pin_processing_date
                AND fetched_flag           = 2;
                COMMIT;
  
        END IF;
  
  END IF;
   EXCEPTION
    WHEN OTHERS THEN
            commons_utils_1.p_error_logging(pi_metric_id    => lv_metric_name,
                                        pi_procedure_name => lv_proc_name,
                                        pi_error_message  => 'Error in p_fetch_app_metrics_wrapper : ' || SQLERRM,
                                        pi_error_in_code  => SQLCODE,
                                        pi_tel_error_event_date => pin_processing_date);
                                        raise;
  END p_fetch_app_metrics_wrapper;


  PROCEDURE p_job_create_fetch_ws_metrics IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that creates program,job for webservice metric
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
      exists_cnt pls_integer;
    BEGIN

      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_PROGRAMS
      WHERE PROGRAM_NAME = 'FETCH_WS_METRIC_PROG';

      IF exists_cnt      =0 THEN
        dbms_scheduler.create_program(program_name        => 'FETCH_WS_METRIC_PROG',
                                      program_type        => 'EXECUTABLE',
                                      program_action      => '/home/oracle/telemetry/executor_ws.sh',
                                        number_of_arguments => 6,
                                      Enabled => FALSE,
                                      comments            => 'Program to fetch webservice metrics which calls .jar file from shell script');


        dbms_scheduler.define_program_argument(program_name      => 'FETCH_WS_METRIC_PROG',
                                               argument_name     => 'METRIC_FARM_ID',
                                               argument_position => 1,
                                               argument_type     => 'number');
        dbms_scheduler.define_program_argument(program_name      => 'FETCH_WS_METRIC_PROG',
                                               argument_name     => 'METRIC_ENV_ID',
                                               argument_position => 2,
                                               argument_type     => 'number');
        dbms_scheduler.define_program_argument(program_name      => 'FETCH_WS_METRIC_PROG',
                                               argument_name     => 'metric_name',
                                               argument_position => 3,
                                               argument_type     => 'VARCHAR2');
        dbms_scheduler.define_program_argument(program_name      => 'FETCH_WS_METRIC_PROG',
                                                 argument_name     => 'metric_source_id',
                                                 argument_position => 4,
                                                 argument_type     => 'number');
          dbms_scheduler.define_program_argument(program_name      => 'FETCH_WS_METRIC_PROG',
                                               argument_name     => 'METRIC_WS_STRING',
                                                 argument_position => 5,
                                               argument_type     => 'VARCHAR2');
        dbms_scheduler.define_program_argument(program_name      => 'FETCH_WS_METRIC_PROG',
                                               argument_name     => 'UTF_constant',
                                                 argument_position => 6,
                                               argument_type     => 'VARCHAR2');
        dbms_scheduler.enable(NAME => 'FETCH_WS_METRIC_PROG');
      end if;

      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_JOBS a
      WHERE JOB_NAME = 'FETCH_WS_METRIC_JOB';

      IF exists_cnt  =0 THEN
          dbms_scheduler.create_job(job_name            => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_JOB',
                                program_name        => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_PROG',
                                start_date          => to_date(null),
                                repeat_interval     => '',
                                end_date            => to_date(null),
                                job_class           => 'DEFAULT_JOB_CLASS',
                                enabled             => false,
                                auto_drop           => false,
                                comments            => 'This job will run the FETCH_WS_METRIC_PROG program');
  dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_JOB',
                                            argument_name  => 'METRIC_FARM_ID',
                                            argument_value => '');
  dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_JOB',
                                            argument_name  => 'METRIC_ENV_ID',
                                            argument_value => '');
  dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_JOB',
                                            argument_name  => 'METRIC_NAME',
                                              argument_value => '');
  dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_JOB',
                                              argument_name  => 'metric_source_id',
                                              argument_value => '');
  dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_JOB',
                                            argument_name  => 'METRIC_WS_STRING',
                                            argument_value => '');

  dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_JOB',
                                            argument_name  => 'UTF_constant',
                                            argument_value => '');

       
      END IF;
    END p_job_create_fetch_ws_metrics;


PROCEDURE p_insert_tab_fetch_metric_ws(pin_processing_date IN DATE) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that inserts a row everyday's processing
  
  -- Change description :
  -- -----------------------------------------------------------------------------
  PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

  for met_name_indx in (select cm.metric_mapped_name,cm.metric_id from config_metrics cm where cm.metric_source_id in (7,8)
   AND (CM.METRIC_FREQUENCY = 0 OR
                 CM.METRIC_FREQUENCY =
                 TO_CHAR(pin_processing_date,'D')))
  loop
      begin
          Insert into TABLE_FETCH_METRICS (METRIC_FARM_ID,
                                               METRIC_ENV_ID,
                                               METRIC_OR_GROUP_NAME,
                                               METRIC_ID,
                                               FETCHED_DATE,
                                               FETCHED_FLAG,
                                               FAILURE_DESCRIPTION)
           select env_farm_id,ENV_ID,met_name_indx.metric_mapped_name ,met_name_indx.metric_id, trunc(pin_processing_date),2,NULL from config_environments where status = 'Y' AND (substr(ENV_VERSION,regexp_instr(ENV_VERSION,'[[:digit:]]'))  >= '17.6'
           or substr(ENV_VERSION,1,instr(ENV_VERSION , '.',4)-1) = '17.10' 
           or substr(ENV_VERSION,1,instr(ENV_VERSION , '.',4)-1) = '17.11' 
           or substr(ENV_VERSION,1,instr(ENV_VERSION , '.',4)-1) = '17.12' ) ;

      exception
      when DUP_VAL_ON_INDEX THEN
        null;
      when others then
        raise;
      end;

end loop;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      raise_application_error(-20006,'Error in p_insert_tab_fetch_metric_ws with error code ' || sqlcode || sqlerrm);
  END p_insert_tab_fetch_metric_ws;


  PROCEDURE p_fetch_ws_metrics_wrapper(pin_processing_date in date, pi_attach_string_to_filenam in varchar2 default 'TEST' )  is
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that fetches the webservice metrics
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    lv_proc_name  VARCHAR2(4001 CHAR) ;
    lv_group_name VARCHAR(30 CHAR) ;
    lv_metric_listagg VARCHAR(4001 CHAR) ;
    lv_state varchar2(4001);
    lv_metric_name varchar2(4001);
  
    le_state_of_job EXCEPTION;
  BEGIN
  
    lv_proc_name  := 'p_fetch_ws_metrics_wrapper';
    lv_metric_name := 'WEBSERVICE_METRIC';
  
    p_insert_tab_fetch_metric_ws(pin_processing_date);
  
   for indx in (
      SELECT metric_farm_id,metric_env_id,LISTAGG(trim(METRIC_OR_GROUP_NAME),',') WITHIN GROUP (  ORDER BY METRIC_OR_GROUP_NAME) metric_name ,metric_source_id
          FROM TABLE_FETCH_METRICS t
          join config_metrics cm
          on cm.metric_id=t.METRIC_ID 
        WHERE trunc(fetched_date) =trunc(pin_processing_date)
        AND fetched_flag           = 2
        AND CM.METRIC_ENABLED='Y'
          GROUP BY metric_farm_id,metric_env_id,metric_source_id
        )
        loop
  
             p_job_run_fetch_ws_metrics( indx.metric_farm_id , indx.metric_env_id,indx.metric_name,indx.metric_source_id,pi_attach_string_to_filenam,'-Dfile.encoding=UTF8');
  
            LOOP
  
              null;
               dbms_lock.sleep(5);
               -- using this instead of user_scheduler_jobs because of oracle's bug where status is not updated at times
                SELECT STATUS
                INTO lv_state
                FROM
              (SELECT u.STATUS,
              row_number() over ( partition BY JOB_NAME order by ACTUAL_START_DATE DESC) rn
                FROM user_SCHEDULER_JOB_RUN_DETAILS u
                  WHERE job_name= 'FETCH_WS_METRIC_JOB'
                  )
                WHERE rn =1 ;          
 
                IF lv_state   IN( 'SUCCEEDED','COMPLETED','SCHEDULED') THEN
                     EXIT;
                ELSIF   lv_state = 'RUNNING' THEN
                    CONTINUE;
                ELSE
                      RAISE le_state_of_job;
                END IF;
  
          END LOOP;
  
        end loop;
  
   EXCEPTION
           WHEN le_state_of_job THEN
          commons_utils_1.p_error_logging(pi_metric_id    => lv_metric_name,
                                        pi_procedure_name => lv_proc_name,
                                        pi_error_message  => 'The state of the job  FETCH_WS_METRIC_JOB at  ' || sysdate || 'was '|| lv_state || 'hence fetching of webservice metrics did not take place ',
                                        pi_error_in_code  => SQLCODE,
                                        pi_tel_error_event_date => pin_processing_date);
                                        RAISE;
  
            WHEN OTHERS THEN
             commons_utils_1.p_error_logging(pi_metric_id    => lv_metric_name,
                                         pi_procedure_name => lv_proc_name,
                                         pi_error_message  => 'Error in p_fetch_ws_metrics_wrapper : '   || SQLERRM,
                                         pi_error_in_code  => SQLCODE,
                                         pi_tel_error_event_date => pin_processing_date);
                                         --raise ;
  END p_fetch_ws_metrics_wrapper;
  
  PROCEDURE p_insert_tab_fetch_metric_PR(pin_processing_date IN DATE) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that inserts a row everyday's processing
  
  -- Change description :
  -- -----------------------------------------------------------------------------
  PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

  for met_name_indx in (select cm.metric_mapped_name,cm.metric_id from config_metrics cm where cm.metric_source_id ='9'
   AND (CM.METRIC_FREQUENCY = 0 OR
                 CM.METRIC_FREQUENCY =
                 TO_CHAR(pin_processing_date,'D')))
  loop
      begin
          Insert into TABLE_FETCH_METRICS (METRIC_FARM_ID,
                                               METRIC_ENV_ID,
                                               METRIC_OR_GROUP_NAME,
                                               METRIC_ID,
                                               FETCHED_DATE,
                                               FETCHED_FLAG,
                                               FAILURE_DESCRIPTION)
           select -9999,-9999,met_name_indx.metric_mapped_name ,met_name_indx.metric_id, trunc(pin_processing_date),2,NULL from DUAL;

      exception
      when DUP_VAL_ON_INDEX THEN
        null;
      when others then
        raise;
      end;

end loop;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      raise_application_error(-20006,'Error in p_insert_tab_fetch_metric_PR with error code ' || sqlcode || sqlerrm);
  END p_insert_tab_fetch_metric_PR;
  
  
  PROCEDURE p_fetch_PR_metrics_wrapper(pin_processing_date in date, pi_attach_string_to_filenam in varchar2 default 'TEST' )  is
  -- -----------------------------------------------------------------------------
  -- Author         : Shilpa Vinchankar
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that fetches the webservice metrics
  -- Change description :
  -- -----------------------------------------------------------------------------  
    lv_proc_name  VARCHAR2(4001 CHAR) ;
    lv_group_name VARCHAR(30 CHAR) ;
    lv_metric_listagg VARCHAR(4001 CHAR) ;
    lv_state varchar2(4001);
    lv_metric_name varchar2(4001);
    le_state_of_job EXCEPTION;
  BEGIN
    lv_proc_name  := 'p_fetch_PR_metrics_wrapper';
    lv_metric_name := 'PROMETHEUS_METRIC';
    p_insert_tab_fetch_metric_PR(pin_processing_date);
   for indx in (
      SELECT LISTAGG(trim(METRIC_OR_GROUP_NAME),',') WITHIN GROUP (  ORDER BY METRIC_OR_GROUP_NAME) metric_name
          FROM TABLE_FETCH_METRICS t
          join config_metrics cm
          on cm.metric_id=t.METRIC_ID 
        WHERE trunc(fetched_date) =trunc(pin_processing_date)
        AND fetched_flag           = 2
        AND CM.METRIC_ENABLED='Y'
         and cm.metric_source_id = 9
          GROUP BY metric_source_id
        )
        loop
             p_job_run_PR_metrics(indx.metric_name,pi_attach_string_to_filenam,'-Xmx2048m');
            LOOP
              null;
               dbms_lock.sleep(5);
               -- using this instead of user_scheduler_jobs because of oracle's bug where status is not updated at times
                SELECT STATUS
                INTO lv_state
                FROM
              (SELECT u.STATUS,
              row_number() over ( partition BY JOB_NAME order by ACTUAL_START_DATE DESC) rn
                FROM user_SCHEDULER_JOB_RUN_DETAILS u
                  WHERE job_name= 'FETCH_PROMETHEUS_METRIC_JOB'
                  )
                WHERE rn =1 ;          
                IF lv_state   IN( 'SUCCEEDED','COMPLETED','SCHEDULED') THEN
                     EXIT;
                ELSIF   lv_state = 'RUNNING' THEN
                    CONTINUE;
                ELSE
                      RAISE le_state_of_job;
                END IF;
          END LOOP;
          
             
        IF lv_state   IN( 'SUCCEEDED','COMPLETED','SCHEDULED') THEN
                UPDATE table_fetch_metrics
                SET fetched_flag           = 0
                WHERE metric_or_group_name = indx.metric_name
                AND fetched_date           = pin_processing_date
                AND fetched_flag           = 2;
                COMMIT;

        END IF;
        
          
        end loop;
        
     
   EXCEPTION
           WHEN le_state_of_job THEN
          commons_utils_1.p_error_logging(pi_metric_id    => lv_metric_name,
                                        pi_procedure_name => lv_proc_name,
                                        pi_error_message  => 'The state of the job  FETCH_PROMETHEUS_METRIC_JOB at  ' || sysdate || 'was '|| lv_state || 'hence fetching of Prometheus metrics did not take place ',
                                        pi_error_in_code  => SQLCODE,
                                        pi_tel_error_event_date => pin_processing_date);
                                        RAISE;
            WHEN OTHERS THEN
             commons_utils_1.p_error_logging(pi_metric_id    => lv_metric_name,
                                         pi_procedure_name => lv_proc_name,
                                         pi_error_message  => 'Error in p_fetch_PR_metrics_wrapper : '   || SQLERRM,
                                         pi_error_in_code  => SQLCODE,
                                         pi_tel_error_event_date => pin_processing_date);
                                         --raise ;
  END p_fetch_PR_metrics_wrapper;


  procedure p_config_history_insert (PI_CONFIG_TABLE IN VARCHAR2)
  AS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that Inserts into history of metadata history tables before the OCM sync is run each day
  
  -- Change description :
  -- -----------------------------------------------------------------------------
  PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
  case PI_CONFIG_TABLE
        when 'CONFIG_DATA_CENTERS'
      then
        insert into CONFIG_DATA_CENTERS_HISTORY  (data_center_id,
                                                  data_center_name,
                                                  data_center_ocm_url,
                                                  data_center_comments,
                                                  data_center_flag,
                                                  data_centre_graphite_connect,
                                                  time_stamp)  select data_center_id,
                                                                      data_center_name,
                                                                      data_center_ocm_url,
                                                                      data_center_comments,
                                                                      data_center_flag,
                                                                      data_centre_graphite_connect,
                                                                      CURRENT_TIMESTAMP from CONFIG_DATA_CENTERS_OCM;
  
  
        when 'CONFIG_FARMS'
      then
  
         insert into CONFIG_FARMS_HISTORY(farm_id,
                                           farm_data_center_id,
                                           farm_name,
                                           farm_comments,
                                           farm_application_url,
                                           time_stamp)  select farm_id,
                                                               farm_data_center_id,
                                                               farm_name,
                                                               farm_comments,
                                                               farm_application_url,
                                                               current_timestamp from CONFIG_FARMS_OCM;
  
        when 'CONFIG_CLIENT_PROJECTS'
      then
  
        insert into CONFIG_CLIENT_PROJECTS_HISTORY
            (cp_id,
             cp_sub_project_id,
             cp_client_name,
             cp_client_id,
             cp_client_complete_name,
             time_stamp,
             CP_DATA_CENTER_ID)
            SELECT cp_id,
                   cp_sub_project_id,
                   cp_client_name,
                   cp_client_id,
                   cp_client_complete_name,
                   current_timestamp,
                   CP_DATA_CENTER_ID
              FROM CONFIG_CLIENT_PROJECTS_OCM;
  
  
        when 'CONFIG_ENVIRONMENTS'
      then
        INSERT INTO CONFIG_ENVIRONMENTS_HISTORY (ENV_UUID,
                                                 ENV_ID,
                                                 ENV_NAME,
                                                 ENV_DATA_CENTER_ID,
                                                 ENV_ENV_TYPE_ID,
                                                 ENV_CP_ID,
                                                 ENV_FARM_ID,
                                                 ENV_START_DATE,
                                                 ENV_END_DATE,
                                                 ENV_COMMENTS,
                                                 STATUS,
                                                 TIME_STAMP,
                                                 ENV_VERSION) SELECT  ENV_UUID,  -- ENV_VERSION
                                                                     ENV_ID,
                                                                     ENV_NAME,
                                                                     ENV_DATA_CENTER_ID,
                                                                     ENV_ENV_TYPE_ID,
                                                                     ENV_CP_ID,
                                                                     ENV_FARM_ID,
                                                                     ENV_START_DATE,
                                                                     ENV_END_DATE,
                                                                     ENV_COMMENTS,
                                                                     STATUS,
                                                                     current_timestamp,
                                                                     DECODE(STATUS,'Y',ENV_VERSION,'N', NULL) FROM CONFIG_ENVIRONMENTS_OCM ;   -- ENV_VERSION
  
  end case;
  
  COMMIT;
  
  exception when others then
    rollback;
     commons_utils_1.p_error_logging(pi_metric_id            => 'p_config_history_insert',
                                        pi_procedure_name       => 'p_config_history_insert',
                                        pi_error_message        => 'Error in inserting '||PI_CONFIG_TABLE||' : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace,
                                        pi_error_in_code        => SQLCODE,
                                        pi_tel_error_event_date => null);
  
  END p_config_history_insert;


  procedure p_config_bad_rec_insert (                   pi_farm_id                    IN config_farms.farm_id%TYPE,
                                                        pi_data_center_id             IN config_data_centers.data_center_id%TYPE,
                                                        pi_data_center_name           IN config_data_centers.data_center_name%TYPE,
                                                        pi_data_center_ocm_url        IN config_data_centers.data_center_ocm_url%TYPE DEFAULT NULL,
                                                        pi_data_center_flag           IN config_data_centers.data_center_flag%TYPE,
                                                        pi_data_centre_grapht_cnnct   IN config_data_centers.data_centre_graphite_connect%TYPE DEFAULT NULL,
                                                        pi_farm_name                  IN config_farms.farm_name%TYPE DEFAULT NULL,
                                                        pi_farm_application_url       IN config_farms.farm_application_url%TYPE,
                                                        pi_cp_id                      IN config_client_projects.cp_id%TYPE,
                                                        pi_cp_client_nm               IN config_client_projects.cp_client_name%TYPE DEFAULT NULL,
                                                        pi_cp_client_id               IN config_client_projects.cp_client_id%TYPE,
                                                        pi_envi_uuid                  IN config_environments.env_uuid%TYPE,
                                                        pi_envi_id                    IN config_environments.env_id%TYPE,
                                                          PI_ENV_TYPE_ID                IN config_environments.env_env_type_id%TYPE,
                                                        pi_envi_name                  IN config_environments.env_name%TYPE,
                                                        pi_status                     IN config_environments.status%TYPE,
                                                        pi_error_message              IN VARCHAR2,
                                                        pi_config_table               IN VARCHAR2,
                                                        po_insert_status              OUT NUMBER)
  AS
    -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that inserts bad records during processing of OCM sync
  
  -- Change description :
  -- -----------------------------------------------------------------------------
  PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  case PI_CONFIG_TABLE
        when 'CONFIG_DATA_CENTERS'
      then
        insert into config_data_centers_bad_rec(data_center_id,
                                                  data_center_name,
                                                  data_center_ocm_url,
                                                  data_center_flag,
                                                  data_centre_graphite_connect,
                                                  time_stamp,
                                                  error_desc)values ( pi_data_center_id,
                                                                      pi_data_center_name,
                                                                      pi_data_center_ocm_url,
                                                                      pi_data_center_flag,
                                                                      pi_data_centre_grapht_cnnct,
                                                                      CURRENT_TIMESTAMP,
                                                                      pi_error_message);
  
  
        when 'CONFIG_FARMS'
      then
  
         insert into config_farms_bad_rec( farm_id,
                                           farm_data_center_id,
                                           farm_name,
                                           farm_application_url,
                                           time_stamp,
                                           error_desc) values (pi_farm_id,
                                                               pi_data_center_id,
                                                               pi_farm_name,
                                                               pi_farm_application_url,
                                                               current_timestamp,
                                                               pi_error_message);
        when 'CONFIG_CLIENT_PROJECTS'
      then
  
        insert into config_client_projects_bad_rec
                                                (cp_id,
                                                 cp_client_name,
                                                 cp_client_id,
                                                 time_stamp,
                                                 CP_DATA_CENTER_ID,
                                                 error_desc)
                                              values
                                                      (pi_cp_id,
                                                       pi_cp_client_nm,
                                                       pi_cp_client_id, 
                                                       current_timestamp,
                                                       pi_data_center_id,
                                                       pi_error_message);
  
  
  
        when 'CONFIG_ENVIRONMENTS'
      then
  
        INSERT INTO CONFIG_ENVIRONMENTS_BAD_REC (ENV_UUID,
                                                 ENV_ID,
                                                   ENV_ENV_TYPE_ID,
                                                 ENV_NAME,
                                                 ENV_DATA_CENTER_ID,
                                                 ENV_CP_ID,
                                                 ENV_FARM_ID,
                                                 STATUS,
                                                 TIME_STAMP,
                                                 error_desc) VALUES (pi_envi_uuid,
                                                                 pi_envi_id,
                                                                   PI_ENV_TYPE_ID,
                                                                 pi_envi_name,
                                                                 pi_data_center_id,
                                                                 pi_cp_id,
                                                                 pi_farm_id,
                                                                 pi_STATUS,
                                                                 CURRENT_TIMESTAMP,
                                                                 pi_error_message);
  end case;
     po_insert_status:=1;
  COMMIT;
  exception when others then
     rollback;
     po_insert_status:=0;
     commons_utils_1.p_error_logging(pi_metric_id            => 'p_config_bad_rec_insert',
                                        pi_procedure_name       => 'p_config_bad_rec_insert',
                                        pi_error_message        => 'Error in inserting '||PI_CONFIG_TABLE||' : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace,
                                        pi_error_in_code        => SQLCODE,
                                        pi_tel_error_event_date => null);
     raise;
  
  END p_config_bad_rec_insert;
  

    PROCEDURE p_merge_config_tables(pi_farm_id                    IN config_farms.farm_id%TYPE,
                                    pi_data_center_id             IN config_data_centers.data_center_id%TYPE,
                                    pi_data_center_name           IN config_data_centers.data_center_name%TYPE,
                                    pi_data_center_ocm_url        IN config_data_centers.data_center_ocm_url%TYPE DEFAULT NULL,
                                    pi_data_center_flag           IN config_data_centers.data_center_flag%TYPE,
                                    pi_data_centre_graphite_cnnct IN config_data_centers.data_centre_graphite_connect%TYPE DEFAULT NULL,
                                    pi_farm_name                  IN config_farms.farm_name%TYPE DEFAULT NULL,
                                    pi_farm_application_url       IN config_farms.farm_application_url%TYPE,
                                    pi_cp_id                      IN config_client_projects.cp_id%TYPE,
                                    pi_cp_client_nm               IN config_client_projects.cp_client_name%TYPE DEFAULT NULL,
                                    pi_cp_client_id               IN config_client_projects.cp_client_id%TYPE,
                                    pi_envi_uuid                  IN config_environments.env_uuid%TYPE,
                                    pi_envi_id                    IN config_environments.env_id%TYPE,
                                      pi_env_type_id                IN config_environments.env_env_type_id%TYPE,
                                    pi_envi_name                  IN config_environments.env_name%TYPE,
                                    pi_status                     IN config_environments.status%TYPE,
                                    pi_config_table               IN VARCHAR2,
                                    pi_skip_alter_flag            IN VARCHAR2 default 'N',
                                    pi_processing_date            IN DATE,
                                    pi_env_version                IN config_environments.env_version%TYPE,   -- ENV_VERSION
                                    po_insert_status              OUT NUMBER)
  IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that Merges configuration tables received from OCM 
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
      po_string varchar2(4000);
  
  
  BEGIN
  
    p_validate_insert_inputs(pi_farm_id                    => pi_farm_id,
                             pi_farm_name                  => pi_farm_name,
                             pi_farm_application_url       => pi_farm_application_url,
                             pi_data_center_id             => pi_data_center_id,
                             pi_data_center_name           => pi_data_center_name,
                             pi_data_center_ocm_url        => pi_data_center_ocm_url,
                             pi_data_center_flag           => pi_data_center_flag,
                             pi_data_centre_graphite_cnnct => pi_data_centre_graphite_cnnct,
                             pi_cp_id                      => pi_cp_id,
                             pi_cp_client_nm               => pi_cp_client_nm,
                             pi_cp_client_id               => pi_cp_client_id,
                             pi_envi_uuid                  => pi_envi_uuid,
                             pi_envi_id                    => pi_envi_id,
                               pi_env_env_type_id            => pi_env_type_id,
                             pi_envi_name                  => pi_envi_name,
                             pi_status                     => pi_status,
                             pi_config_table               => pi_config_table,
                             po_string                     => po_string);
  
  
  
   IF length(po_string)>0 THEN
        RAISE ex_invalid_entry;
   ELSE
  
      CASE upper(pi_config_table)
        WHEN 'CONFIG_ENVIRONMENTS' THEN
          IF pi_skip_alter_flag = 'N'
            THEN
            commons_utils_1.p_read_write_config(1,pi_config_table,'p_merge_config_tables');
            END IF;
            <<p_config_environments_insert>>
            BEGIN
                 MERGE INTO CONFIG_ENVIRONMENTS CEN USING
                 (SELECT PI_ENVI_UUID  ENV_UUID,
                         PI_ENVI_ID  ENV_ID,
                           PI_ENV_TYPE_ID  ENV_TYPE_ID,
                         PI_ENVI_NAME  ENV_NAME,
                         PI_DATA_CENTER_ID  ENV_DATA_CENTER,
                         PI_CP_ID  ENV_CP_ID,
                         PI_FARM_ID  ENV_FARM_ID,
                         PI_STATUS ENV_STATUS,
                         PI_ENV_VERSION ENV_VERSION FROM DUAL ) INPUT      -- ENV_VERSION
                 ON (CEN.ENV_UUID=INPUT.ENV_UUID)
                 WHEN MATCHED THEN
                 UPDATE
                     SET
                     CEN.ENV_ID = INPUT.ENV_ID,
                     CEN.ENV_ENV_TYPE_ID = INPUT.ENV_TYPE_ID,
                     CEN.ENV_NAME = INPUT.ENV_NAME,
                     CEN.ENV_DATA_CENTER_ID = INPUT.ENV_DATA_CENTER,
                     CEN.ENV_CP_ID = INPUT.ENV_CP_ID,
                     CEN.ENV_FARM_ID = INPUT.ENV_FARM_ID,
                     CEN.STATUS       = INPUT.ENV_STATUS,
                     CEN.ENV_VERSION= INPUT.ENV_VERSION   -- ENV_VERSION
                 WHEN NOT MATCHED THEN
                 INSERT (ENV_UUID,
                         ENV_ID,
                         ENV_ENV_TYPE_ID,
                         ENV_NAME,
                         ENV_DATA_CENTER_ID,
                         ENV_CP_ID,
                         ENV_FARM_ID,
                         STATUS,
                         ENV_VERSION)  -- ENV_VERSION
                 VALUES (INPUT.ENV_UUID,
                         INPUT.ENV_ID,
                         INPUT.ENV_TYPE_ID,
                         INPUT.ENV_NAME,
                         INPUT.ENV_DATA_CENTER,
                         INPUT.ENV_CP_ID,
                         INPUT.ENV_FARM_ID,
                         INPUT.ENV_STATUS,
                         INPUT.ENV_VERSION);  -- ENV_VERSION
  
                          
              EXCEPTION
                WHEN OTHERS THEN
                RAISE ex_merge_failed;
            end p_config_environments_insert;
  
        When 'CONFIG_CLIENT_PROJECTS' THEN
          IF pi_skip_alter_flag = 'N'
            THEN
            commons_utils_1.p_read_write_config(1,pi_config_table,'p_merge_config_tables');
            END IF;
            <<p_config_client_project_insert>>
            begin
                MERGE INTO CONFIG_CLIENT_PROJECTS CCP
              USING (SELECT PI_CP_ID          CP_ID,
                            PI_CP_CLIENT_ID   CLIENT_ID,
                            PI_CP_CLIENT_NM   CLIENT_NAME,
                            PI_DATA_CENTER_ID DATA_CENTER_ID
                       FROM DUAL) INPUT
              ON (CCP.CP_ID = INPUT.CP_ID AND CCP.CP_DATA_CENTER_ID=INPUT.DATA_CENTER_ID)
              WHEN MATCHED THEN
                UPDATE
                   SET CCP.CP_CLIENT_NAME    = COALESCE(INPUT.CLIENT_NAME,
                                                        CP_CLIENT_NAME),
                       CCP.CP_CLIENT_ID      = INPUT.CLIENT_ID,
                       CCP.CP_IS_DELETED     = 0
  
              WHEN NOT MATCHED THEN
                INSERT
                  (CP_ID, CP_CLIENT_NAME, CP_CLIENT_ID, CP_DATA_CENTER_ID,CP_IS_DELETED)
                VALUES
                  (INPUT.CP_ID,
                   INPUT.CLIENT_NAME,
                   INPUT.CLIENT_ID,
                   INPUT.DATA_CENTER_ID,
                   0);
                  
                EXCEPTION
                  WHEN OTHERS THEN
                    RAISE ex_merge_failed;
            end p_config_client_project_insert;
  
        WHEN 'CONFIG_DATA_CENTERS' THEN
        IF pi_skip_alter_flag = 'N'
          THEN
            commons_utils_1.p_read_write_config(1,pi_config_table,'p_merge_config_tables');
            END IF;
            <<P_CONFIG_DATA_CENTERS_INSERT>>
              begin
  
                  MERGE INTO CONFIG_DATA_CENTERS cdc
                  USING (SELECT PI_DATA_CENTER_ID DATA_CENTER_ID,
                               pi_data_center_name data_center_name,
                               pi_data_center_ocm_url data_center_ocm_url,
                               pi_data_center_flag data_center_flag,
                               PI_data_centre_graphite_cnnct data_centre_graphite_cnnc
                               FROM DUAL )  INPUT
                  ON    (cdc.DATA_CENTER_ID=INPUT.DATA_CENTER_ID)
                  WHEN MATCHED THEN
                  UPDATE
                  SET
                      cdc.data_center_name= INPUT.data_center_name,
                      cdc.data_center_ocm_url=INPUT.data_center_ocm_url,
                      cdc.data_center_flag=INPUT.data_center_flag,
                      cdc.data_centre_graphite_connect=INPUT.data_centre_graphite_cnnc
  
                  WHEN NOT MATCHED THEN
                  INSERT (cdc.data_center_id,
                         cdc.data_center_name,
                         cdc.data_center_ocm_url,
                         cdc.data_center_flag,
                         cdc.data_centre_graphite_connect)  VALUES(INPUT.DATA_CENTER_ID,
                                                                  INPUT.data_center_name,
                                                                  INPUT.data_center_ocm_url,
                                                                  INPUT.data_center_flag,
                                                                  INPUT.data_centre_graphite_cnnc);
                  EXCEPTION
                    WHEN OTHERS THEN
                      RAISE ex_merge_failed;
              end P_CONFIG_DATA_CENTERS_INSERT;
  
       WHEN 'CONFIG_FARMS' THEN
       IF pi_skip_alter_flag = 'N'
         THEN
            commons_utils_1.p_read_write_config(1,pi_config_table,'p_merge_config_tables');
            END IF;
            <<p_config_farms_insert>>
            BEGIN
  
                    MERGE INTO CONFIG_FARMS CF
                     USING (SELECT PI_FARM_ID FARM_ID,
                                   PI_DATA_CENTER_ID FARM_DATA_CENTER_ID,
                                   PI_FARM_NAME FARM_NAME,
                                   PI_FARM_APPLICATION_URL FARM_APPLICATION_URL
                                   FROM DUAL )  INPUT
                     ON    (CF.FARM_ID=INPUT.FARM_ID and CF.FARM_DATA_CENTER_ID= INPUT.FARM_DATA_CENTER_ID)
                     WHEN MATCHED THEN
                     UPDATE
                     SET  CF.FARM_NAME = COALESCE(INPUT.FARM_NAME,CF.FARM_NAME)  ,
                          CF.FARM_APPLICATION_URL = COALESCE(INPUT.FARM_APPLICATION_URL,CF.FARM_APPLICATION_URL)
                     WHEN NOT MATCHED THEN
                     INSERT (CF.FARM_ID,
                             CF.FARM_DATA_CENTER_ID,
                             CF.FARM_NAME,
                             CF.FARM_APPLICATION_URL)VALUES(INPUT.FARM_ID,
                                                            INPUT.FARM_DATA_CENTER_ID,
                                                            INPUT.FARM_NAME,
                                                            INPUT.FARM_APPLICATION_URL);
  
            EXCEPTION
              WHEN OTHERS THEN
                    RAISE ex_merge_failed;
            END p_config_farms_insert;
    END CASE;
  
      PO_INSERT_STATUS:=1;
                commit;
    END IF;
  IF pi_skip_alter_flag = 'N'
         THEN
            commons_utils_1.p_read_write_config(0,pi_config_table,'p_merge_config_tables');
            END IF;
  EXCEPTION
    when ex_invalid_entry THEN
      rollback;
      PO_INSERT_STATUS:=0;
      commons_utils_1.p_error_logging(pi_metric_id    => '',
                                    pi_procedure_name => 'p_merge_config_tables',
                                    pi_error_message  => 'Invalid entry for '||pi_config_table||' : '||po_string||' Backtraced : ' || f_get_exception_backtrace,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => pi_processing_date);
  
  IF pi_skip_alter_flag = 'N'
         THEN
            commons_utils_1.p_read_write_config(0,pi_config_table,'p_merge_config_tables');
            END IF;
                raise;
  
    when ex_merge_failed THEN
     rollback;
     PO_INSERT_STATUS:=0;
      commons_utils_1.p_error_logging(pi_metric_id    => 'p_merge_failed_details',
                                    pi_procedure_name => 'p_merge_config_tables',
                                    pi_error_message  => 'Merge failed Backtraced : ' || f_get_exception_backtrace || ' for '|| pi_config_table || ' because '|| sqlerrm || ' for the entries '|| case pi_config_table when  'CONFIG_FARMS' then 'FARM_ID : '||PI_FARM_ID||',FARM_DATA_CENTER_ID : '|| PI_DATA_CENTER_ID ||',FARM_NAME : '|| PI_FARM_NAME || ',FARM_APPLICATION_URL : '||PI_FARM_APPLICATION_URL
                                                                                                                                                                                                                                 when  'CONFIG_DATA_CENTERS' then ' DATA_CENTER_ID : '||PI_DATA_CENTER_ID||',DATA_CENTER_NAME : '|| PI_DATA_CENTER_NAME ||',DATA_CENTER_OCM_URL : '|| PI_DATA_CENTER_OCM_URL || ',DATA_CENTER_FLAG : '||PI_DATA_CENTER_FLAG||',DATA_CENTRE_GRAPHITE_CONNECT : '||PI_DATA_CENTRE_GRAPHITE_CNNCT
                                                                                                                                                                                                                                 when  'CONFIG_CLIENT_PROJECTS' then 'CP_ID, : '||PI_CP_ID||',CP_CLIENT_ID : '|| PI_CP_CLIENT_ID ||',CP_CLIENT_NAME : '|| PI_CP_CLIENT_NM || ',PI_DATA_CENTER_ID : '|| PI_DATA_CENTER_ID
                                                                                                                                                                                                                                 when  'CONFIG_ENVIRONMENTS' then ' ENV_UUID : '||PI_ENVI_UUID||',ENV_ID : '|| PI_ENVI_ID ||',ENV_NAME : '|| PI_ENVI_NAME || ',ENV_DATA_CENTER : '||PI_DATA_CENTER_ID ||',ENV_CP_ID : '||PI_CP_ID ||',ENV_FARM_ID : '||PI_FARM_ID ||',ENV_STATUS  : '||PI_STATUS
                                                                                                                                                                                                                                 ELSE  'Unknown Table'
                                                                                                                                                                                                                                 end ,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => pi_processing_date);
  IF pi_skip_alter_flag = 'N'
         THEN
            commons_utils_1.p_read_write_config(0,pi_config_table,'p_merge_config_tables');
            END IF;
               raise;
  
    when case_not_found then
     rollback;
     PO_INSERT_STATUS:=0;
      commons_utils_1.p_error_logging(pi_metric_id    => '',
                                    pi_procedure_name => 'p_merge_config_tables',
                                    pi_error_message  => 'Passed table '||pi_config_table||' is not supported Backtraced : ' || f_get_exception_backtrace,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => pi_processing_date);
      raise;
  
    when others then
     rollback;
     PO_INSERT_STATUS:=0;
      commons_utils_1.p_error_logging(pi_metric_id    => '',
                                    pi_procedure_name => 'p_merge_config_tables',
                                    pi_error_message  => 'In others handler of p_merge_config_tables Backtraced : ' || f_get_exception_backtrace || ' for '|| pi_config_table,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => pi_processing_date);
  
  IF pi_skip_alter_flag = 'N'
         THEN
            commons_utils_1.p_read_write_config(0,pi_config_table,'p_merge_config_tables');
            END IF;
               raise;
  
  END p_merge_config_tables;


PROCEDURE P_BAD_REC_INSERT_WRAPPER(PI_CONFIG_TABLE                IN VARCHAR2,
                                     PI_DATA_CENTER_ID              IN CONFIG_DATA_CENTERS.DATA_CENTER_ID%TYPE,
                                     PI_DATA_CENTER_NAME            IN CONFIG_DATA_CENTERS.DATA_CENTER_NAME%TYPE,
                                     PI_DATA_CENTER_OCM_URL         IN CONFIG_DATA_CENTERS.DATA_CENTER_OCM_URL%TYPE  DEFAULT NULL,
                                     PI_DATA_CENTER_FLAG            IN CONFIG_DATA_CENTERS.DATA_CENTER_FLAG%TYPE,
                                     PI_DATA_CENTRE_GRAPHITE_CONECT IN CONFIG_DATA_CENTERS.DATA_CENTRE_GRAPHITE_CONNECT%TYPE  DEFAULT NULL,
                                     PI_FARM_ID                     IN CONFIG_FARMS.FARM_ID%TYPE,
                                     PI_FARM_NAME                   IN CONFIG_FARMS.FARM_NAME%TYPE  DEFAULT NULL,
                                     PI_FARM_APPLICATION_URL        IN CONFIG_FARMS.FARM_APPLICATION_URL%TYPE,
                                     PI_CP_ID                       IN CONFIG_CLIENT_PROJECTS.CP_ID%TYPE,
                                     PI_CP_CLIENT_NAME              IN CONFIG_CLIENT_PROJECTS.CP_CLIENT_NAME%TYPE  DEFAULT NULL,
                                     PI_CP_CLIENT_ID                IN CONFIG_CLIENT_PROJECTS.CP_CLIENT_ID%TYPE,
                                     PI_ENVI_UUID                   IN CONFIG_ENVIRONMENTS.ENV_UUID%TYPE,
                                     PI_ENVI_ID                     IN CONFIG_ENVIRONMENTS.ENV_ID%TYPE,
                                       PI_ENV_TYPE_ID                 IN CONFIG_ENVIRONMENTS.ENV_ENV_TYPE_ID%TYPE,
                                     PI_ENVI_NAME                   IN CONFIG_ENVIRONMENTS.ENV_NAME%TYPE,
                                     PI_STATUS                      IN CONFIG_ENVIRONMENTS.STATUS%TYPE,
                                     PI_METRIC_ID                   IN VARCHAR2,
                                     PI_PROCEDURE_NAME              IN VARCHAR2,
                                     PI_ERROR_MESSAGE               IN VARCHAR2,
                                     PO_INSERT_STATUS OUT NUMBER) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that internally calls inserts for bad records during OCM sync utility's processing 
  
  -- Change description :
  -- -----------------------------------------------------------------------------                                     
    LV_CONFIG_TABLE  VARCHAR2(100) := PI_CONFIG_TABLE;
    LV_INSERT_STATUS NUMBER;
    po_string varchar2(4000);

  BEGIN

    CASE UPPER(LV_CONFIG_TABLE)
      WHEN 'CONFIG_DATA_CENTERS' THEN

        commons_utils_1.P_CONFIG_BAD_REC_INSERT(PI_FARM_ID                  => NULL,
                                              PI_DATA_CENTER_ID           => PI_DATA_CENTER_ID,
                                              PI_DATA_CENTER_NAME         => PI_DATA_CENTER_NAME,
                                              PI_DATA_CENTER_OCM_URL      => PI_DATA_CENTER_OCM_URL,
                                              PI_DATA_CENTER_FLAG         => PI_DATA_CENTER_FLAG,
                                              PI_DATA_CENTRE_GRAPHT_CNNCT => PI_DATA_CENTRE_GRAPHITE_CONECT,
                                              PI_FARM_NAME                => NULL,
                                              PI_FARM_APPLICATION_URL     => NULL,
                                              PI_CP_ID                    => NULL,
                                              PI_CP_CLIENT_NM             => NULL,
                                              PI_CP_CLIENT_ID             => NULL,
                                              PI_ENVI_UUID                => NULL,
                                              PI_ENVI_ID                  => NULL,
                                                PI_ENV_TYPE_ID              => NULL,
                                              PI_ENVI_NAME                => NULL,
                                              PI_STATUS                   => NULL,
                                              PI_ERROR_MESSAGE            => PI_ERROR_MESSAGE,
                                              PI_CONFIG_TABLE             => LV_CONFIG_TABLE,
                                              PO_INSERT_STATUS            => LV_INSERT_STATUS);

       

      WHEN 'CONFIG_FARMS' THEN

        commons_utils_1.P_CONFIG_BAD_REC_INSERT(PI_FARM_ID                  => PI_FARM_ID,
                                              PI_DATA_CENTER_ID           => PI_DATA_CENTER_ID,
                                              PI_DATA_CENTER_NAME         => NULL,
                                              PI_DATA_CENTER_OCM_URL      => NULL,
                                              PI_DATA_CENTER_FLAG         => NULL,
                                              PI_DATA_CENTRE_GRAPHT_CNNCT => NULL,
                                              PI_FARM_NAME                => PI_FARM_NAME,
                                              PI_FARM_APPLICATION_URL     => PI_FARM_APPLICATION_URL,
                                              PI_CP_ID                    => NULL,
                                              PI_CP_CLIENT_NM             => NULL,
                                              PI_CP_CLIENT_ID             => NULL,
                                              PI_ENVI_UUID                => NULL,
                                              PI_ENVI_ID                  => NULL,
                                                PI_ENV_TYPE_ID              => NULL,
                                              PI_ENVI_NAME                => NULL,
                                              PI_STATUS                   => NULL,
                                              PI_ERROR_MESSAGE            => PI_ERROR_MESSAGE,
                                              PI_CONFIG_TABLE             => LV_CONFIG_TABLE,
                                              PO_INSERT_STATUS            => LV_INSERT_STATUS);


      WHEN 'CONFIG_CLIENT_PROJECTS' THEN

        commons_utils_1.P_CONFIG_BAD_REC_INSERT(PI_FARM_ID                  => NULL,
                                              PI_DATA_CENTER_ID           => PI_DATA_CENTER_ID,
                                              PI_DATA_CENTER_NAME         => NULL,
                                              PI_DATA_CENTER_OCM_URL      => NULL,
                                              PI_DATA_CENTER_FLAG         => NULL,
                                              PI_DATA_CENTRE_GRAPHT_CNNCT => NULL,
                                              PI_FARM_NAME                => NULL,
                                              PI_FARM_APPLICATION_URL     => NULL,
                                              PI_CP_ID                    => PI_CP_ID,
                                              PI_CP_CLIENT_NM             => PI_CP_CLIENT_NAME,
                                              PI_CP_CLIENT_ID             => PI_CP_CLIENT_ID,
                                              PI_ENVI_UUID                => NULL,
                                              PI_ENVI_ID                  => NULL,
                                                PI_ENV_TYPE_ID              => NULL,
                                              PI_ENVI_NAME                => NULL,
                                              PI_STATUS                   => NULL,
                                              PI_ERROR_MESSAGE            => PI_ERROR_MESSAGE,
                                              PI_CONFIG_TABLE             => LV_CONFIG_TABLE,
                                              PO_INSERT_STATUS            => LV_INSERT_STATUS);

       

      WHEN 'CONFIG_ENVIRONMENTS' THEN

        commons_utils_1.P_CONFIG_BAD_REC_INSERT(PI_FARM_ID                  => PI_FARM_ID,
                                              PI_DATA_CENTER_ID           => PI_DATA_CENTER_ID,
                                              PI_DATA_CENTER_NAME         => NULL,
                                              PI_DATA_CENTER_OCM_URL      => NULL,
                                              PI_DATA_CENTER_FLAG         => NULL,
                                              PI_DATA_CENTRE_GRAPHT_CNNCT => NULL,
                                              PI_FARM_NAME                => NULL,
                                              PI_FARM_APPLICATION_URL     => NULL,
                                              PI_CP_ID                    => PI_CP_ID,
                                              PI_CP_CLIENT_NM             => NULL,
                                              PI_CP_CLIENT_ID             => NULL,
                                              PI_ENVI_UUID                => PI_ENVI_UUID,
                                              PI_ENVI_ID                  => PI_ENVI_ID,
                                                PI_ENV_TYPE_ID              => PI_ENV_TYPE_ID,
                                              PI_ENVI_NAME                => PI_ENVI_NAME,
                                              PI_STATUS                   => PI_STATUS,
                                              PI_ERROR_MESSAGE            => PI_ERROR_MESSAGE,
                                              PI_CONFIG_TABLE             => LV_CONFIG_TABLE,
                                              PO_INSERT_STATUS            => LV_INSERT_STATUS);

        
      ELSE
        NULL;

    END CASE;
    PO_INSERT_STATUS := 1;

    EXCEPTION
    when ex_invalid_entry THEN
      rollback;
      PO_INSERT_STATUS := 0;
      commons_utils_1.p_error_logging(pi_metric_id            => '',
                                    pi_procedure_name       => 'P_BAD_REC_INSERT_WRAPPER',
                                    pi_error_message        => 'Invalid entry for ' ||
                                                               pi_config_table ||
                                                               ' : ' ||
                                                               po_string ||
                                                               ' Backtraced : ' ||
                                                               f_get_exception_backtrace,
                                    pi_error_in_code        => SQLCODE,
                                    pi_tel_error_event_date => null);
                                    
                                    
   when others THEN
      rollback;
            PO_INSERT_STATUS := 0;
      commons_utils_1.p_error_logging(pi_metric_id            => '',
                                    pi_procedure_name       => 'P_BAD_REC_INSERT_WRAPPER',
                                    pi_error_message        => 'In when others for ' ||
                                                               LV_CONFIG_TABLE ||
                                                               ' : ' ||
                                                               po_string ||
                                                               ' Backtraced : ' ||
                                                               f_get_exception_backtrace,
                                    pi_error_in_code        => SQLCODE,
                                    pi_tel_error_event_date => null);
  END P_BAD_REC_INSERT_WRAPPER;


 /* procedure p_config_tables_merge_ocm (pin_processing_date  in date, PIN_ITERATION_NUMBER IN NUMBER)
  is
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that is called which takes care of OCM utility running
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    lv_config_table varchar2(100);
    lv_insert_status  number;
    lv_row_count number;
    OCM_TABLES_EMPTY EXCEPTION;
  begin
           p_job_run_ocm_sync;--Fetch into the staging tables of OCM sync
           
           SELECT count(*) INTO lv_row_count FROM CONFIG_FARMS_OCM where rownum =1 ;
            IF lv_row_count=0
              then
              SELECT count(*) INTO lv_row_count FROM CONFIG_CLIENT_PROJECTS_OCM where rownum =1 ;
                              IF lv_row_count=0
                                then
                                   SELECT count(*) INTO lv_row_count FROM CONFIG_ENVIRONMENTS_OCM where rownum =1 ;
                                                    IF lv_row_count=0
                                                        THEN
                                                          RAISE OCM_TABLES_EMPTY;
                                                    END IF;
                              END IF;
            END IF;
        
          -- dump the current iteration set into history tables 
          lv_config_table:= 'CONFIG_FARMS';
          P_CONFIG_HISTORY_INSERT(PI_CONFIG_TABLE =>lv_config_table );
          lv_config_table:= 'CONFIG_CLIENT_PROJECTS';
          P_CONFIG_HISTORY_INSERT(PI_CONFIG_TABLE =>lv_config_table );
          lv_config_table:= 'CONFIG_ENVIRONMENTS';
          P_CONFIG_HISTORY_INSERT(PI_CONFIG_TABLE =>lv_config_table );
  
      -- lets open up all tables in write mode
      commons_utils_1.p_read_write_config(1,'CONFIG_FARMS','p_config_tables_merge_ocm');
      commons_utils_1.p_read_write_config(1,'CONFIG_CLIENT_PROJECTS','p_config_tables_merge_ocm');
      commons_utils_1.p_read_write_config(1,'CONFIG_ENVIRONMENTS','p_config_tables_merge_ocm');
      
        lv_config_table:= 'CONFIG_FARMS';
        for i in (select * from config_farms_ocm)
        LOOP
               begin
                commons_utils_1.p_merge_config_tables( pi_farm_id                    => i.farm_id,
                                                     pi_data_center_id             =>  i.farm_data_center_id,
                                                     pi_data_center_name           => null,
                                                     pi_data_center_ocm_url        => null,
                                                     pi_data_center_flag           => null,
                                                     pi_data_centre_graphite_cnnct => null,
                                                     pi_farm_name                  => i.farm_name,
                                                     pi_farm_application_url       => i.farm_application_url,
                                                     pi_cp_id                      => null,
                                                     pi_cp_client_nm               => null,
                                                     pi_cp_client_id               => null,
                                                     pi_envi_uuid                  => null,
                                                     pi_envi_id                    => null,
                                                       pi_env_type_id                => null,
                                                     pi_envi_name                  => null,
                                                     pi_status                     => null,
                                                     pi_config_table               => lv_config_table,
                                                     pi_skip_alter_flag            => 'Y',
                                                     pi_processing_date            => pin_processing_date,
                                                     pi_env_version                => null,   -- ENV_VERSION
                                                     po_insert_status              => lv_insert_status );
              exception
                WHEN ex_invalid_entry THEN
                   raise; -- we have already done an error logging inside hence skipping here 
                WHEN OTHERS THEN
                P_BAD_REC_INSERT_WRAPPER(PI_CONFIG_TABLE                =>lv_config_table ,
                                                  PI_DATA_CENTER_ID              =>i.farm_data_center_id,
                                                  PI_DATA_CENTER_NAME            =>null ,
                                                  PI_DATA_CENTER_OCM_URL         =>null ,
                                                  PI_DATA_CENTER_FLAG            =>null ,
                                                  PI_DATA_CENTRE_GRAPHITE_CONECT =>null ,
                                                  PI_FARM_ID                     =>i.farm_id ,
                                                  PI_FARM_NAME                   =>i.farm_name ,
                                                  PI_FARM_APPLICATION_URL        =>i.farm_application_url ,
                                                  PI_CP_ID                       =>null ,
                                                  PI_CP_CLIENT_NAME              =>null ,
                                                  PI_CP_CLIENT_ID                =>null ,
                                                  PI_ENVI_UUID                   =>null ,
                                                  PI_ENVI_ID                     =>null ,
                                                    PI_ENV_TYPE_ID                 =>null ,
                                                  PI_ENVI_NAME                   =>null ,
                                                  PI_STATUS                      =>null ,
                                                  PI_METRIC_ID                   =>'p_config_tables_merge_ocm',
                                                  PI_PROCEDURE_NAME              =>'p_config_tables_merge_ocm',
                                                  PI_ERROR_MESSAGE               =>'Error in inserting/updating ' ||
                                                                                 LV_CONFIG_TABLE ,
                                                  PO_INSERT_STATUS=> lv_insert_status)   ;
                raise;
              end;
       end loop;

       lv_config_table:= 'CONFIG_CLIENT_PROJECTS';
      for i in (select * from config_client_projects_ocm)
        LOOP
            begin
        
                  commons_utils_1.p_merge_config_tables( pi_farm_id                    => null,
                                                       pi_data_center_id             => i.cp_data_center_id,
                                                       pi_data_center_name           => null,
                                                       pi_data_center_ocm_url        => null,
                                                       pi_data_center_flag           => null,
                                                       pi_data_centre_graphite_cnnct => null,
                                                       pi_farm_name                  => null,
                                                       pi_farm_application_url       => null,
                                                       pi_cp_id                      => i.cp_id,
                                                       pi_cp_client_nm               => i.cp_client_name,
                                                       pi_cp_client_id               => i.cp_client_id,
                                                       pi_envi_uuid                  => null,
                                                       pi_envi_id                    => null,
                                                         pi_env_type_id                => null,
                                                       pi_envi_name                  => null,
                                                       pi_status                     => null,
                                                       pi_config_table               => lv_config_table,
                                                       pi_skip_alter_flag            => 'Y',
                                                       pi_processing_date            => pin_processing_date,
                                                       pi_env_version                => null,  -- ENV_VERSION
                                                       po_insert_status              => lv_insert_status
                                                                                                         );
        
             exception
              WHEN ex_invalid_entry THEN
                   raise; -- we have already done an error logging inside hence skipping here 
              WHEN OTHERS THEN
                      P_BAD_REC_INSERT_WRAPPER(PI_CONFIG_TABLE                =>lv_config_table ,
                                                        PI_DATA_CENTER_ID              =>i.CP_DATA_CENTER_ID,
                                                        PI_DATA_CENTER_NAME            =>null ,
                                                        PI_DATA_CENTER_OCM_URL         =>null ,
                                                        PI_DATA_CENTER_FLAG            =>null ,
                                                        PI_DATA_CENTRE_GRAPHITE_CONECT =>null ,
                                                        PI_FARM_ID                     =>null ,
                                                        PI_FARM_NAME                   =>null ,
                                                        PI_FARM_APPLICATION_URL        =>null ,
                                                        PI_CP_ID                       =>i.cp_id ,
                                                        PI_CP_CLIENT_NAME              =>i.cp_client_name ,
                                                        PI_CP_CLIENT_ID                =>i.cp_client_id ,
                                                        PI_ENVI_UUID                   =>null ,
                                                        PI_ENVI_ID                     =>null ,
                                                          PI_ENV_TYPE_ID                 =>null ,
                                                        PI_ENVI_NAME                   =>null ,
                                                        PI_STATUS                      =>null ,
                                                        PI_METRIC_ID                   =>'p_config_tables_merge_ocm',
                                                        PI_PROCEDURE_NAME              =>'p_config_tables_merge_ocm',
                                                        PI_ERROR_MESSAGE               =>'Error in inserting/updating ' ||
                                                                                       LV_CONFIG_TABLE ,
                                                        PO_INSERT_STATUS=> lv_insert_status)   ;
              
                    raise;
             end;
        end loop;
  
          lv_config_table:= 'CONFIG_ENVIRONMENTS';
          for i in (select * from config_environments_ocm where (PIN_ITERATION_NUMBER<2 or (STATUS='Y' and PIN_ITERATION_NUMBER>=2 ))) -- 4 times ocm sync
            LOOP         
            begin
                    commons_utils_1.p_merge_config_tables( pi_farm_id                    => i.env_farm_id,
                                                         pi_data_center_id             => i.env_data_center_id,
                                                         pi_data_center_name           => null,
                                                         pi_data_center_ocm_url        => null,
                                                         pi_data_center_flag           => null,
                                                         pi_data_centre_graphite_cnnct => null,
                                                         pi_farm_name                  => null,
                                                         pi_farm_application_url       => null,
                                                         pi_cp_id                      => i.env_cp_id,
                                                         pi_cp_client_nm               => null,
                                                         pi_cp_client_id               => null,
                                                         pi_envi_uuid                  => i.env_uuid,
                                                         pi_envi_id                    => i.env_id,
                                                           pi_env_type_id                => i.env_env_type_id,
                                                         pi_envi_name                  => i.env_name,
                                                         pi_status                     => i.status,
                                                         pi_config_table               => lv_config_table,
                                                         pi_skip_alter_flag            => 'Y',
                                                         pi_processing_date            => pin_processing_date,
                                                         pi_env_version                => I.ENV_VERSION,  -- ENV_VERSION
                                                         po_insert_status              => lv_insert_status
                                                                                                           );
          
              exception
              WHEN ex_invalid_entry THEN
                   raise; -- we have already done an error logging inside hence skipping here 
              WHEN OTHERS THEN
                   P_BAD_REC_INSERT_WRAPPER(PI_CONFIG_TABLE                =>lv_config_table ,
                                            PI_DATA_CENTER_ID              =>i.env_data_center_id,
                                            PI_DATA_CENTER_NAME            =>null ,
                                            PI_DATA_CENTER_OCM_URL         =>null ,
                                            PI_DATA_CENTER_FLAG            =>null ,
                                            PI_DATA_CENTRE_GRAPHITE_CONECT =>null ,
                                            PI_FARM_ID                     =>i.env_farm_id ,
                                            PI_FARM_NAME                   =>null ,
                                            PI_FARM_APPLICATION_URL        =>null ,
                                            PI_CP_ID                       =>i.env_cp_id ,
                                            PI_CP_CLIENT_NAME              =>null ,
                                            PI_CP_CLIENT_ID                =>null ,
                                            PI_ENVI_UUID                   =>i.env_uuid ,
                                            PI_ENVI_ID                     =>i.env_id ,
                                              PI_ENV_TYPE_ID                 =>i.env_env_type_id,
                                            PI_ENVI_NAME                   =>i.env_name ,
                                            PI_STATUS                      =>i.status ,
                                            PI_METRIC_ID                   =>'p_config_tables_merge_ocm',
                                            PI_PROCEDURE_NAME              =>'p_config_tables_merge_ocm',
                                            PI_ERROR_MESSAGE               =>'Error in inserting/updating ' ||
                                                                           LV_CONFIG_TABLE ,
                                            PO_INSERT_STATUS=> lv_insert_status)   ;
          
                   raise;
              end;
            end loop;
  
     update CONFIG_ENVIRONMENTS
     set STATUS = 'D' where (ENV_UUID) not in (select ENV_UUID from CONFIG_ENVIRONMENTS_OCM);  

     update config_client_projects
     set cp_is_deleted = 1
     where (cp_id,cp_data_center_id) not in  (select cp_id,cp_data_center_id from config_client_projects_ocm  ); 
     update config_farms cf 
     set status = 'D'  
     where not exists ( select 1 from config_farms_ocm o where o.farm_id = cf.farm_id );
     
     update config_farms cf 
     set status = 'D'  
     where not exists ( select 1 from config_farms_ocm o where o.farm_id = cf.farm_id );


     UPDATE TABLE_OCM_SYNC 
     SET TOC_FLAG='Y'
     WHERE TOC_EVENT_DATE=pin_processing_date
     AND TOC_ITERATION_NUMBER=PIN_ITERATION_NUMBER;
     commit;  
      
      -- lets close up all tables in read mode
      commons_utils_1.p_read_write_config(0,'CONFIG_FARMS','p_config_tables_merge_ocm');
      commons_utils_1.p_read_write_config(0,'CONFIG_CLIENT_PROJECTS','p_config_tables_merge_ocm');
      commons_utils_1.p_read_write_config(0,'CONFIG_ENVIRONMENTS','p_config_tables_merge_ocm');

  
   exception
      WHEN OCM_TABLES_EMPTY THEN
        commons_utils_1.p_error_logging(pi_metric_id            => 'p_config_tables_merge_ocm',
                                        pi_procedure_name       => 'p_config_tables_merge_ocm',
                                        pi_error_message        => ' Raised OCM_TABLES_EMPTY Exception as all ocm tables are empty .Please check',
                                        pi_error_in_code        => SQLCODE,
                                        pi_tel_error_event_date => pin_processing_date);
  
      WHEN OTHERS THEN
          rollback;
          commons_utils_1.p_error_logging(pi_metric_id            => 'p_config_tables_merge_ocm',
                                        pi_procedure_name       => 'p_config_tables_merge_ocm',
                                        pi_error_message        => 'Error in when others : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace,
                                        pi_error_in_code        => SQLCODE,
                                        pi_tel_error_event_date => pin_processing_date);

      -- lets close up all tables in read mode
      commons_utils_1.p_read_write_config(0,'CONFIG_FARMS','p_config_tables_merge_ocm');
      commons_utils_1.p_read_write_config(0,'CONFIG_CLIENT_PROJECTS','p_config_tables_merge_ocm');
      commons_utils_1.p_read_write_config(0,'CONFIG_ENVIRONMENTS','p_config_tables_merge_ocm');                                        
  
  end p_config_tables_merge_ocm;
  */


  PROCEDURE p_delete_config_environment ( pi_envi_uuid      IN VARCHAR2,
                                          pi_config_table   IN VARCHAR2,
                                          po_row_count      OUT NUMBER
                                         )
  AS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that soft deletes an environment
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
  BEGIN
  
    commons_utils_1.p_read_write_config(1,pi_config_table,'p_delete_config_environment');
    UPDATE CONFIG_ENVIRONMENTS
    SET STATUS= 'D'
    WHERE ENV_UUID = PI_ENVI_UUID;
    PO_ROW_COUNT:=SQL%ROWCOUNT;
    COMMIT;
    commons_utils_1.p_read_write_config(0,pi_config_table,'p_delete_config_environment');
  
  
  
  EXCEPTION
      WHEN OTHERS THEN
  commons_utils_1.p_error_logging(pi_metric_id    => '',
                                    pi_procedure_name => 'p_delete_config_environment',
                                    pi_error_message  => 'Failed to mark status of environment as ''D'' '||pi_config_table||' : '||sqlerrm|| ' Backtraced : ' || f_get_exception_backtrace,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => null);
      commons_utils_1.p_read_write_config(0,pi_config_table,'p_delete_config_environment');
      RAISE ;
  END p_delete_config_environment;
  

  PROCEDURE p_delete_client_project ( pi_cp_id            IN VARCHAR2,
                                      pi_data_center_id   IN NUMBER,
                                      pi_config_table   IN VARCHAR2,
                                      po_row_count        OUT NUMBER
                                     )
  AS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that soft deletes an client project
  
  -- Change description :
  -- -----------------------------------------------------------------------------
  BEGIN
  
    commons_utils_1.p_read_write_config(1,pi_config_table,'p_delete_client_project');
    commons_utils_1.p_read_write_config(1,'CONFIG_ENVIRONMENTS','p_delete_client_project');
    UPDATE CONFIG_CLIENT_PROJECTS
    SET CP_IS_DELETED=1
    WHERE CP_ID =PI_CP_ID AND CP_DATA_CENTER_ID=pi_data_center_id;
    PO_ROW_COUNT:=SQL%ROWCOUNT;
    COMMIT;
    commons_utils_1.p_read_write_config(0,'CONFIG_ENVIRONMENTS','p_delete_client_project');
    commons_utils_1.p_read_write_config(0,pi_config_table,'p_delete_client_project');
  
  
  EXCEPTION
      WHEN OTHERS THEN
        commons_utils_1.p_error_logging(pi_metric_id    => '',
                                    pi_procedure_name => 'p_delete_client_project',
                                    pi_error_message  => 'Failed to mark status of Client project as ''1'' '||pi_config_table||' : '||sqlerrm|| ' Backtraced : ' || f_get_exception_backtrace,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => null);
        commons_utils_1.p_read_write_config(0,'CONFIG_ENVIRONMENTS','p_delete_client_project');
        commons_utils_1.p_read_write_config(0,pi_config_table,'p_delete_client_project');
      RAISE ;
  END p_delete_client_project;


  PROCEDURE p_delete_config_data_centers (pi_data_center_id      IN NUMBER,
                                          pi_config_table        IN VARCHAR2,
                                          po_row_count           OUT NUMBER
                                         )
  AS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that soft deletes a Data centre
  
  -- Change description :
  -- -----------------------------------------------------------------------------
  BEGIN
  
    commons_utils_1.p_read_write_config(1,pi_config_table,'p_delete_config_data_centers');
    commons_utils_1.p_read_write_config(1,'CONFIG_FARMS','p_delete_config_data_centers');
    commons_utils_1.p_read_write_config(1,'CONFIG_ENVIRONMENTS','p_delete_config_data_centers');
    UPDATE CONFIG_DATA_CENTERS
    SET DATA_CENTER_FLAG = 0
    WHERE DATA_CENTER_ID=PI_DATA_CENTER_ID;
    PO_ROW_COUNT:=SQL%ROWCOUNT;
    COMMIT;
    commons_utils_1.p_read_write_config(0,'CONFIG_FARMS','p_delete_config_data_centers');
    commons_utils_1.p_read_write_config(0,'CONFIG_ENVIRONMENTS','p_delete_config_data_centers');
    commons_utils_1.p_read_write_config(0,pi_config_table,'p_delete_config_data_centers');
  
  EXCEPTION
      WHEN OTHERS THEN
        commons_utils_1.p_error_logging(pi_metric_id    => '',
                                    pi_procedure_name => 'p_delete_config_data_centers',
                                    pi_error_message  => 'Failed to mark Data center flag as 0 '||pi_config_table||' : '||sqlerrm|| ' Backtraced : ' || f_get_exception_backtrace,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => null);
       commons_utils_1.p_read_write_config(0,'CONFIG_FARMS','p_delete_config_data_centers');
       commons_utils_1.p_read_write_config(0,'CONFIG_ENVIRONMENTS','p_delete_config_data_centers');
       commons_utils_1.p_read_write_config(0,pi_config_table,'p_delete_config_data_centers');
      RAISE ;
  END p_delete_config_data_centers;


  PROCEDURE p_delete_config_farms (pi_farm_id          IN VARCHAR2,
                                   pi_data_center_id   IN NUMBER,
                                   pi_config_table   IN VARCHAR2,
                                   po_row_count        OUT NUMBER
                                  )
  AS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that soft deletes a farm in meta data table
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
  BEGIN
      commons_utils_1.p_read_write_config(1,pi_config_table,'p_delete_config_farms');
      commons_utils_1.p_read_write_config(1,'CONFIG_ENVIRONMENTS','p_delete_config_farms');
      IF PI_DATA_CENTER_ID IS NULL THEN
        UPDATE CONFIG_FARMS
        SET STATUS = 'D'
        WHERE FARM_ID =PI_FARM_ID;
      ELSE
        UPDATE CONFIG_FARMS
        SET STATUS = 'D'
        WHERE FARM_ID=PI_FARM_ID AND FARM_DATA_CENTER_ID=PI_DATA_CENTER_ID;
      END IF;
      PO_ROW_COUNT:=SQL%ROWCOUNT;
      COMMIT;
      commons_utils_1.p_read_write_config(0,pi_config_table,'p_delete_config_farms');
      commons_utils_1.p_read_write_config(0,'CONFIG_ENVIRONMENTS','p_delete_config_farms');
  
  EXCEPTION
      WHEN OTHERS THEN
  
        commons_utils_1.p_error_logging(pi_metric_id    => '',
                                    pi_procedure_name => 'p_delete_config_farms',
                                    pi_error_message  => 'Failed to mark status of farm as ''D'' '||pi_config_table||' : '||sqlerrm|| ' Backtraced : ' || f_get_exception_backtrace,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => null);
        commons_utils_1.p_read_write_config(0,pi_config_table,'p_delete_config_farms');
        commons_utils_1.p_read_write_config(0,'CONFIG_ENVIRONMENTS','p_delete_config_farms');
      RAISE ;
  END p_delete_config_farms;


  PROCEDURE p_delete_config_tables(pi_envi_uuid      IN config_environments.env_uuid%TYPE,
                                   pi_cp_id          IN config_client_projects.cp_id%TYPE,
                                   pi_data_center_id IN config_data_centers.data_center_id%TYPE,
                                   pi_farm_id        IN config_farms.farm_id%TYPE,
                                   pi_config_table   IN VARCHAR2,
                                   po_row_count      OUT NUMBER)
  IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that soft deletes an metadata tables - a wrapper procedure 
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
      po_string varchar2(4000);
  
  
      record_not_present EXCEPTION;
      PRAGMA EXCEPTION_INIT(record_not_present, -20016);
  BEGIN
     p_validate_delete_inputs(pi_envi_uuid      =>pi_envi_uuid
                             ,pi_cp_id          =>pi_cp_id
                             ,pi_data_center_id =>pi_data_center_id
                             ,pi_farm_id        =>pi_farm_id
                             ,pi_config_table   =>pi_config_table
                             ,po_string         =>po_string );
  
  
     IF length(po_string)>0
        THEN
          RAISE ex_invalid_entry;
       ELSE
        CASE upper (pi_config_table)
              WHEN 'CONFIG_ENVIRONMENTS'THEN
                    p_delete_config_environment(pi_envi_uuid=>pi_envi_uuid,po_row_count=>po_row_count,pi_config_table=>pi_config_table);
  
              WHEN 'CONFIG_CLIENT_PROJECTS'THEN
                    p_delete_client_project(pi_cp_id =>pi_cp_id,pi_data_center_id=>pi_data_center_id,po_row_count=>po_row_count,pi_config_table=>pi_config_table);
  
              WHEN 'CONFIG_DATA_CENTERS'THEN
                    p_delete_config_data_centers(pi_data_center_id =>pi_data_center_id,po_row_count=>po_row_count,pi_config_table=>pi_config_table);
  
              WHEN 'CONFIG_FARMS'THEN
                    p_delete_config_farms(pi_data_center_id =>pi_data_center_id,pi_farm_id =>pi_farm_id,po_row_count=>po_row_count,pi_config_table=>pi_config_table);
        END CASE;
        IF PO_ROW_COUNT=0   THEN
           RAISE record_not_present;
        END IF;
     END IF;
  EXCEPTION
     when record_not_present THEN
      rollback;
      commons_utils_1.p_error_logging(pi_metric_id    => '',
                                    pi_procedure_name => 'p_delete_config_tables',
                                    pi_error_message  => 'Updating status for '||pi_config_table||' not possible as row is not present.'|| ' Backtraced : ' || f_get_exception_backtrace,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => null);
     when ex_invalid_entry THEN
      rollback;
      commons_utils_1.p_error_logging(pi_metric_id    => '',
                                    pi_procedure_name => 'p_delete_config_tables',
                                    pi_error_message  => 'Invalid entry entry passed for '||pi_config_table||' : '||po_string|| ' Backtraced : ' || f_get_exception_backtrace,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => null);
  
    when case_not_found then
     rollback;
      commons_utils_1.p_error_logging(pi_metric_id    => '',
                                    pi_procedure_name => 'p_delete_config_tables',
                                    pi_error_message  => 'Passed table '||pi_config_table||' is not supported Backtraced : ' || f_get_exception_backtrace,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => null);
    when others then
       rollback;
      commons_utils_1.p_error_logging(pi_metric_id    => '',
                                    pi_procedure_name => 'p_delete_config_tables',
                                    pi_error_message  => 'In when others of  p_delete_config_tables Backtraced : ' || f_get_exception_backtrace,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => null);
  END p_delete_config_tables;



  PROCEDURE p_insert_table_load_metrics(pin_processing_date IN DATE,pin_metric_string IN varchar2) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that inserts a row for loading of a metric for a given day
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
  PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN

        INSERT INTO table_load_metrics(data_centre_id,metric_id, loaded_date)
        SELECT cmdcm.data_centre_id,cmdcm.metric_id,pin_processing_date from
       (WITH DATA AS( SELECT pin_metric_string rcv_metric_id FROM dual)
                              SELECT trim(regexp_substr(rcv_metric_id, '[^,]+', 1, LEVEL)) rcv_metric_id
                              FROM DATA
                              CONNECT BY regexp_substr(rcv_metric_id , '[^,]+', 1, LEVEL) IS NOT NULL) received_tab
        inner join
        config_metrics cm   on (cm.metric_id = received_tab.rcv_metric_id )
        inner join config_metric_data_centre_map cmdcm  on (cm.metric_id =cmdcm.metric_id)
        left outer join config_data_centers cdc on (cmdcm.data_centre_id =to_char(cdc.data_center_id))
        where cmdcm.is_enabled = 'Y'
        and  (cdc.data_center_flag = 1        or cdc.data_center_flag is null) AND (CM.METRIC_FREQUENCY = 0 OR
                 CM.METRIC_FREQUENCY =
                 TO_CHAR(pin_processing_date,'D'));
      
    COMMIT;

  EXCEPTION
    WHEN dup_val_on_index THEN
        INSERT INTO table_load_metrics(data_centre_id,metric_id, loaded_date)

        SELECT temp.data_centre_id,temp.metric_id,temp.pin_processing_date from (
            SELECT cmdcm.data_centre_id,cmdcm.metric_id,pin_processing_date from
           (WITH DATA AS( SELECT pin_metric_string rcv_metric_id FROM dual)
                                  SELECT trim(regexp_substr(rcv_metric_id, '[^,]+', 1, LEVEL)) rcv_metric_id
                                  FROM DATA
                                  CONNECT BY regexp_substr(rcv_metric_id , '[^,]+', 1, LEVEL) IS NOT NULL) received_tab
            inner join
            config_metrics cm   on (cm.metric_id = received_tab.rcv_metric_id )
            inner join config_metric_data_centre_map cmdcm  on (cm.metric_id =cmdcm.metric_id)
            left outer join config_data_centers cdc on (cmdcm.data_centre_id =to_char(cdc.data_center_id))
            where cmdcm.is_enabled = 'Y'
            and  (cdc.data_center_flag = 1
            or cdc.data_center_flag is null) and (CM.METRIC_FREQUENCY = 0 OR
                 CM.METRIC_FREQUENCY =
                 TO_CHAR(pin_processing_date,'D')) ) temp
        where NOT EXISTS(SELECT 1 FROM table_load_metrics tlm WHERE tlm.metric_id = temp.metric_id and tlm.data_centre_id = temp.data_centre_id and tlm.loaded_date = temp.pin_processing_date );
       
      COMMIT;
    WHEN OTHERS THEN
      ROLLBACK;
      raise_application_error(-20006,'Error in p_insert_table_load_metrics with error code ' || sqlcode || sqlerrm);
  END p_insert_table_load_metrics;


  PROCEDURE p_load_app_metrics_wrapper(pin_processing_date date) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Wrapper procedure for loading of application metrics
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    lv_metric_string varchar2(4001);
  BEGIN
     SELECT LISTAGG(CM.METRIC_ID,',') within GROUP(ORDER BY CM.METRIC_ID) INTO lv_metric_string
     FROM CONFIG_METRICS CM WHERE CM.METRIC_SOURCE_ID=1 AND CM.METRIC_ENABLED='Y';
    --lv_metric_string := '21,1,4,30,31,37,38,39,40,44,45,52,53,56,58,61';                    ----OF-86556 , OF-86557

    p_insert_table_load_metrics(pin_processing_date,lv_metric_string);

    FOR indx_metric_id IN (SELECT metric_id
                             FROM table_load_metrics
                            WHERE loaded_flag = 'N'
                              AND loaded_date = pin_processing_date
                              and metric_id in (21,1,4,30,31,37,38,39,40,44,45,52,53,56,58,61,112) )LOOP  ----OF-86556 , OF-86557

      <<case_metrics_function_call>>
     case indx_metric_id.metric_id
      when 44 then
           SAVEPOINT s_44;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>44,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');

       when 45 then
           SAVEPOINT s_45;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>45,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
       when 30 then
           SAVEPOINT s_30;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>30,
                                    pi_extra_derived_cols_val =>'DECODE(service_subtype,
                                                                                    ''adjust'',1,
                                                                                    ''read_records'',0,
                                                                                    ''read_table_metadata'',0,
                                                                                    ''read_tables_metadata'',0,
                                                                                    ''create_user'',1,
                                                                                    ''delete_user'',1,
                                                                                    ''email_user'',1,
                                                                                    ''disable_user'',1,
                                                                                    ''enable_user'',1,
                                                                                    ''add_user'',1,
                                                                                    ''job_trigger'',1,
                                                                                    ''job_status'',0,
                                                                                    ''job_abort'',1
                                                                                    ),
                                                                   DECODE(service_subtype,
                                                                    ''adjust'',updated_records_count,
                                                                    ''read_records'',read_records_count,
                                                                    ''read_table_metadata'',NULL,
                                                                    ''read_tables_metadata'',NULL,
                                                                    ''create_user'',NULL,
                                                                    ''delete_user'',updated_records_count,
                                                                    ''email_user'',NULL,
                                                                    ''disable_user'',NULL,
                                                                    ''enable_user'',NULL,
                                                                    ''add_user'',updated_records_count,
                                                                    ''job_trigger'',NULL,
                                                                    ''job_status'',NULL,
                                                                    ''job_abort'',NULL),
                                                                    DURATION,
                                                                    CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
       when 21 then
           SAVEPOINT s_21;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>21,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
       when 1 then
           SAVEPOINT s_1;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>1,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
         
       when 4 then
           SAVEPOINT s_4;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>4,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
      when 31 then
          SAVEPOINT s_31;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>31,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
      when 37 then
           SAVEPOINT s_37;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>37,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
      when 38 then
           SAVEPOINT s_38;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>38,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
      when 39 then
           SAVEPOINT s_39;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>39,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
       when 40 then
           SAVEPOINT s_40;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>40,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
         when 52 then
           SAVEPOINT s_52;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>52,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');      
                                    
       when 53 then
           SAVEPOINT s_53;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>53,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');    
                                    
           when 56 then
           SAVEPOINT s_56;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>56,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');  
                                    
           when 58 then
           SAVEPOINT s_58;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>58,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT'); 
           when 61 then
           SAVEPOINT s_61;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>61,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');      
                                    
            when 112 then
           SAVEPOINT s_112;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>112,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                                                         
                                    
      END CASE case_metrics_function_call;
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      commons_utils_1.p_error_logging(pi_metric_id    => 'APPLICATION_METRICS',
                                  pi_procedure_name => 'p_load_app_metrics_wrapper',
                                  pi_error_message  => 'In  When others (last) of p_load_app_metrics_wrapper ' || SQLERRM || SQLCODE,
                                  pi_error_in_code  => SQLERRM || SQLCODE,
                                  pi_tel_error_event_date => pin_processing_date);
      RAISE;
  END p_load_app_metrics_wrapper;


PROCEDURE p_load_OS_reports_wrapper(pin_processing_date date) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Wrapper procedure for loading of OS metrics
  
  -- Change description :
  -- -----------------------------------------------------------------------------
    lv_metric_string varchar2(4001);
  BEGIN
    /*('Used_Space')*/
    -- lv_metric_string := '25';--add 32 -- add ,27
 SELECT LISTAGG(CM.METRIC_ID,',') within GROUP(ORDER BY CM.METRIC_ID) INTO lv_metric_string
     FROM CONFIG_METRICS CM WHERE CM.METRIC_SOURCE_ID=3 AND CM.METRIC_ENABLED='Y';


    p_insert_table_load_metrics(pin_processing_date,lv_metric_string);
    FOR indx_metric_id IN (SELECT distinct metric_id
                             FROM table_load_metrics
                            WHERE loaded_flag = 'N'
                              AND loaded_date = pin_processing_date
                              and metric_id in (25))LOOP
      <<case_metrics_function_call>>
    case indx_metric_id.metric_id
       when 25 then
          begin
            SAVEPOINT s_25;
            telemetry.p_used_space(pin_processing_date);
            UPDATE table_load_metrics
               SET loaded_flag = 'Y'
             WHERE metric_id = 25
             AND loaded_date = pin_processing_date;
          exception
          when others then
                commons_utils_1.p_error_logging(pi_metric_id    => '25',
                                    pi_procedure_name => 'p_used_space',
                                    pi_error_message  => 'Error in p_used_space : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace,
                                    pi_error_in_code  => SQLCODE,
                                    pi_tel_error_event_date => pin_processing_date); 
          end;
      END CASE case_metrics_function_call;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      commons_utils_1.p_error_logging(pi_metric_id    => 'OS_Metrics',
                                  pi_procedure_name => 'p_load_OS_reports_wrapper',
                                  pi_error_message  => 'In  When others (last) of load_phs_reports_wrapper' || SQLERRM || SQLCODE,
                                  pi_error_in_code  => SQLERRM || SQLCODE,
                                  pi_tel_error_event_date => pin_processing_date);
  END p_load_OS_reports_wrapper;
  

  PROCEDURE p_load_phs_reports_wrapper(pin_processing_date date) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Wrapper procedure for loading of PHS metrics
  
  -- Change description :
  -- -----------------------------------------------------------------------------
    lv_metric_string varchar2(4001);
  BEGIN
    /*('Objects_count','Optymyze_Version','Studio_App_Allowed','Studio_App_Count','Widget_Count','Used_Space')*/
    lv_metric_string := '11';--'15,3,2,5,11,28,29'--add 32 -- add ,27 (Keeping only data processed volume OF-91240)
    
     SELECT LISTAGG(CM.METRIC_ID,',') within GROUP(ORDER BY CM.METRIC_ID) INTO lv_metric_string
     FROM CONFIG_METRICS CM WHERE CM.METRIC_SOURCE_ID=2 AND CM.METRIC_ENABLED='Y';

    p_insert_table_load_metrics(pin_processing_date,lv_metric_string);

    FOR indx_metric_id IN (SELECT distinct metric_id
                             FROM table_load_metrics
                            WHERE loaded_flag = 'N'
                              AND loaded_date = pin_processing_date
                              --and metric_id in (15,3,2,5,11,/*27,*/28,29/*,32*/)
			      and metric_id =11 --(Keeping only data processed volume OF-91240)
			      ) LOOP

      <<case_metrics_function_call>>
      CASE indx_metric_id.metric_id
       when 11 then
          begin
            telemetry.p_data_processed_volume(pin_processing_date);
          exception
          when others then
          null ;
          end;

       /*when 15 then
          begin
            telemetry.p_objects_count(pin_processing_date);
          exception
          when others then
          null ;
          end;

       WHEN 3 THEN

          begin
            telemetry.p_studio_app_allowed(pin_processing_date);
          exception
          when others then
          null ;
          end;

       when 2 then
          begin
            telemetry.p_studio_app_count(pin_processing_date);
          exception
          when others then
          null ;
          end;

       when 28 then
          begin
            telemetry.p_user_languages(pin_processing_date);
          exception
          when others then
          null ;
          end;

       when 29 then
          begin
            telemetry.p_Languages_Per_Client_Count(pin_processing_date);
          exception
          when others then
          null ;
          end;

       when 5 then
          begin
            telemetry.p_widget_count(pin_processing_date);
          exception
          when others then
          null ;
          end; */
       
      END CASE case_metrics_function_call;
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      commons_utils_1.p_error_logging(pi_metric_id    => 'PHS_Metrics',
                                  pi_procedure_name => 'p_load_phs_reports_wrapper',
                                  pi_error_message  => 'In  When others (last) of load_phs_reports_wrapper' || SQLERRM || SQLCODE,
                                  pi_error_in_code  => SQLERRM || SQLCODE,
                                  pi_tel_error_event_date => pin_processing_date);

  END p_load_phs_reports_wrapper;


PROCEDURE p_load_ws_wrapper(pin_processing_date date) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Wrapper procedure for loading of Webservice metric
  
  -- Change description :
  -- -----------------------------------------------------------------------------
    lv_metric_string varchar2(4001);
  BEGIN
    SELECT LISTAGG(CM.METRIC_ID,',') within GROUP(ORDER BY CM.METRIC_ID) INTO lv_metric_string
     FROM CONFIG_METRICS CM WHERE CM.METRIC_SOURCE_ID IN (7,8) AND CM.METRIC_ENABLED='Y';
  
   -- lv_metric_string := '32,33,34,35,36,41,42,43,48,49,50,51,54,55,57,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77';   ----OF-86041
    
    p_insert_table_load_metrics(pin_processing_date,lv_metric_string);
    FOR indx_metric_id IN (SELECT distinct metric_id
                             FROM table_load_metrics
                            WHERE loaded_flag = 'N'
                              AND loaded_date = pin_processing_date
                              and metric_id in (32,33,34,35,36,41,42,43,48,49,50,51,54,55,57,59,60,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,79,80,81,82,83,84,85,86,87,88,89,90,107,113)) LOOP                          ----OF-86041
      <<case_metrics_function_call>>
      CASE indx_metric_id.metric_id
      when 32 then
           SAVEPOINT S_32;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>32,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');

         when 33 then
           SAVEPOINT S_33;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>33,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');

           when 34 then
           SAVEPOINT S_34;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>34,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
           when 35 then
           SAVEPOINT S_35;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>35,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
           when 36 then
           SAVEPOINT S_36;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>36,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
          when 41 then
           SAVEPOINT S_41;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>41,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
          when 42 then
           SAVEPOINT S_42;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>42,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
                                    
             when 43 then
           SAVEPOINT S_43;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>43,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
            
                                    
           
                                   
           when 48 then
           SAVEPOINT S_48;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>48,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
                                    
                                    
          when 49 then
           SAVEPOINT S_49;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>49,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
                                    
          when 50 then
           SAVEPOINT S_50;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>50,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
                                    
                                    
          when 51 then
           SAVEPOINT S_51;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>51,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
                                    
            when 54 then
           SAVEPOINT S_54;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>54,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
                                    
           when 55 then
           SAVEPOINT S_55;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>55,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');  
                
           when 57 then
           SAVEPOINT S_57;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>57,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                      
           when 59 then
           SAVEPOINT S_59;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>59,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                         


           when 60 then
           SAVEPOINT S_60;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>60,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');             
                                    
           when 62 then
           SAVEPOINT S_62;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>62,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                             
                                                  
              
           when 63 then
           SAVEPOINT S_63;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>63,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');        
                                    
           when 64 then
           SAVEPOINT S_64;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>64,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT'); 
                                    
           when 65 then
           SAVEPOINT S_65;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>65,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT'); 
                                    
           when 66 then
           SAVEPOINT S_66;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>66,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
                                    
           when 67 then
           SAVEPOINT S_67;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>67,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');  
                                    
          when 68 then
           SAVEPOINT S_68;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>68,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');   
                                    
                                      
          when 69 then
           SAVEPOINT S_69;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>69,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');  
                                    
           when 70 then
           SAVEPOINT S_70;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>70,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');   
                                    
           when 71 then
           SAVEPOINT S_71;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>71,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT',
                                    Pi_Merge_insert_flag        => 'Y');
                                    
           when 72 then
           SAVEPOINT S_72;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>72,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                                                
            
           when 73 then
           SAVEPOINT S_73;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>73,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');   
            
           
            when 74 then
           SAVEPOINT S_74;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>74,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT'); 
                                    
           when 75 then
           SAVEPOINT S_75;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>75,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT'); 
           
            when 76 then
           SAVEPOINT S_76;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>76,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT',
                                    Pi_Merge_insert_flag        => 'Y'); 
             
           when 77 then
           SAVEPOINT S_77;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>77,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT'); 
                                    
           when 79 then
           SAVEPOINT S_79;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>79,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
                                    
           when 80 then
           SAVEPOINT S_80;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>80,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
                                    
           when 81 then
           SAVEPOINT S_81;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>81,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                                                   
              
                                      
           when 82 then
           SAVEPOINT S_82;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>82,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT'); 
                                    
                                      
           when 83 then
           SAVEPOINT S_83;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>83,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                             
           
           when 84 then
           SAVEPOINT S_84;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>84,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');   
                                    
           when 85 then
           SAVEPOINT S_85;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>85,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                            
           
            when 86 then
           SAVEPOINT S_86;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>86,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');  
           when 87 then
           SAVEPOINT S_87;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>87,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');  
                                    
           when 88 then
           SAVEPOINT S_88;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>88,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');  
                                    
           when 89 then
           SAVEPOINT S_89;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>89,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');  
                                    
           when 90 then
           SAVEPOINT S_90;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>90,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                                                                              
          
           when 107 then
           SAVEPOINT S_107;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>107,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');  
           
           when 113 then
           SAVEPOINT S_113;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>113,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE,TO_DATE(TO_CHAR(TO_DATE('''||pin_processing_date||''',''DD-MON-YYYY''),''DD-MON-YY''),''DD-MM-YY'')',
                                    pi_attach_string_to_filenam => 'DW_INPUT');  
                               
      END CASE case_metrics_function_call;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      commons_utils_1.p_error_logging(pi_metric_id    => 'WS_Metrics',
                                  pi_procedure_name => 'p_load_ws_wrapper',
                                  pi_error_message  => 'In  When others (last) of load of Webservice wrapper' || SQLERRM || SQLCODE,
                                  pi_error_in_code  => SQLERRM || SQLCODE,
                                  pi_tel_error_event_date => pin_processing_date);
      RAISE;
  END p_load_ws_wrapper;
  
  
  PROCEDURE p_load_PR_wrapper(pin_processing_date date) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Shilpa Vinchankar
  -- Reviewer       : Rajput Gaurav
  -- Description    : Wrapper procedure for loading of Webservice metric
  
  -- Change description :
  -- -----------------------------------------------------------------------------
    lv_metric_string varchar2(4001);
  BEGIN
    
      SELECT LISTAGG(CM.METRIC_ID,',') within GROUP(ORDER BY CM.METRIC_ID) INTO lv_metric_string
     FROM CONFIG_METRICS CM WHERE CM.METRIC_SOURCE_ID =9 AND CM.METRIC_ENABLED='Y';
    
    --lv_metric_string := '78'; 
    
    p_insert_table_load_metrics(pin_processing_date,lv_metric_string);
    FOR indx_metric_id IN (SELECT distinct metric_id
                             FROM table_load_metrics
                            WHERE loaded_flag = 'N'
                              AND loaded_date = pin_processing_date
                              and metric_id in (78,108,109,110,111)) LOOP                      
      <<case_metrics_function_call>>
      CASE indx_metric_id.metric_id
            
           when 78 then
           SAVEPOINT S_78;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>78,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');  

           when 108 then
           SAVEPOINT S_108;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>108,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');
                                    
           when 109 then
           SAVEPOINT S_109;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>109,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');                          
           
           when 110 then
           SAVEPOINT S_110;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>110,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');  
                                    
           when 111 then
           SAVEPOINT S_111;
           commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                    pi_metric_id =>111,
                                    pi_extra_derived_cols_val =>'CURRENT_DATE',
                                    pi_attach_string_to_filenam => 'DW_INPUT');  
                                    
                                                                             
      END CASE case_metrics_function_call;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      commons_utils_1.p_error_logging(pi_metric_id    => 'Prometheus_metrics',
                                  pi_procedure_name => 'p_load_PR_wrapper',
                                  pi_error_message  => 'In  When others (last) of load of prometheus wrapper' || SQLERRM || SQLCODE,
                                  pi_error_in_code  => SQLERRM || SQLCODE,
                                  pi_tel_error_event_date => pin_processing_date);
      RAISE;
  END p_load_PR_wrapper;
  

 /* PROCEDURE p_merge_config_environmnt_http(pi_processing_date DATE)
  IS
  -- -----------------------------------------------------------------------------
  -- Author         : Chowdhary Paanshul
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that merges optymyze version inot config_environments 
  
  -- Change description :
  -- -----------------------------------------------------------------------------     
    pragma autonomous_transaction;
  BEGIN
    commons_utils_1.p_read_write_config(1,'CONFIG_ENVIRONMENTS','p_merge_config_environmnt_http');
    merge INTO config_environments ce USING
    (SELECT ENVIRONMENT_UUID,
      APP_NAME,
      RN
    FROM
      (SELECT ENVIRONMENT_UUID,
        APP_NAME,
        ROW_NUMBER() OVER (PARTITION BY ENVIRONMENT_UUID ORDER BY EVENT_TIME DESC ) RN
      FROM table_http_sessions
      WHERE TRUNC(EVENT_TIME) =TRUNC(pi_processing_date)
      )
    WHERE RN                             =1
    ) res ON (TRIM(res.ENVIRONMENT_UUID) = TRIM(CE.ENV_UUID) )
  WHEN matched THEN
    UPDATE
    SET ce.env_version=COALESCE(SUBSTR(APP_NAME,regexp_instr(APP_NAME,'[[:digit:]]')),env_version);
    COMMIT;
    commons_utils_1.p_read_write_config(0,'CONFIG_ENVIRONMENTS','p_merge_config_environmnt_http');
  EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    commons_utils_1.p_read_write_config(0,'CONFIG_ENVIRONMENTS','p_merge_config_environmnt_http');
  END p_merge_config_environmnt_http;*/
  procedure p_get_a_row_byte_val as
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that updates average row length for all envs in config_environments
  -- Change description :
  -- -----------------------------------------------------------------------------
  pragma autonomous_transaction;
  lv_check_flag varchar2(2);
  begin
        commons_utils_1.p_read_write_config(1,'CONFIG_ENVIRONMENTS','p_get_a_row_byte_val');
      -- calculating the average row length across an environment
        lv_check_flag := 'N';
        loop
            begin
                update config_environments ce 
                set a_row_byte_val = 
                coalesce( (
                    select round(sum(SPACE_OCCUPIED)/sum(number_of_rows),2) calc
                    from TABLE_OBJECT_USAGE_WS touw
                    where TABLE_NAME is not null and CATEGORY = 'TABLE'
                    and touw.EVENT_TIME = gv_processing_date
                    and touw.ENV_UUID = ce.env_uuid
                ),a_row_byte_val);
                lv_check_flag := 'Y';
            exception
            when others then 
              if sqlcode = -00054  then
               dbms_lock.sleep(10);
              else
                rollback;
                commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_get_a_row_byte_val',pi_description =>'Error in updating config_environments : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace );
                lv_check_flag := 'Y';
              end if;
           end;
        
           if lv_check_flag = 'Y' then
              exit;
           end if;   
       end loop;
       commit;
       commons_utils_1.p_read_write_config(0,'CONFIG_ENVIRONMENTS','p_get_a_row_byte_val');
  end p_get_a_row_byte_val;
 
 /* PROCEDURE p_load_metrics_wrapper(P_check_flag varchar2 default 'N') is
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Master Wrapper procedure that is invoked from scheduler
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    lv_processing_date date;
    lv_bad_file_seq pls_integer;
    lv_attach_string_to_filename varchar2(4001);
    lv_mail_flag varchar2(4001);
    lv_ocm_flag  varchar2(4001);
    lv_check_flag varchar2(1);
    lv_loader_seq_val number;
    
  begin
    lv_check_flag :=P_check_flag;
    IF lv_check_flag='Y'
    then
    p_set_context_loader_seq;   ---- setting context gc_loader_seq_cur_val
    end if;
    select sys_context('gc_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_val from dual; 
  
    lv_bad_file_seq:=lv_loader_seq_val;                   ----- enhancement for timely mail alert OF-87697
    
    --- Making the MV blank
    IF lv_bad_file_seq = 1 THEN
    commons_utils_1.P_UPDATE_MVIEW_STATUS(lv_bad_file_seq);
    FOR I IN (SELECT *
                FROM CONFIG_MATERIALIZED_VIEWS C
               WHERE C.CMV_REFRESH_STATUS IN ('N')) LOOP
        DBMS_MVIEW.REFRESH(I.CMV_MV_NAME);
    end loop;
    END IF;
    
    BEGIN
    p_table_ocm_sync_insert (pi_processing_date=>(gv_processing_date+1),PI_ITERATION_NUMBER=>lv_bad_file_seq);  -- 4 TIMES OCM SYNC
    select TOC_FLAG into lv_ocm_flag from table_ocm_sync where TOC_EVENT_DATE=gv_processing_date+1 AND TOC_ITERATION_NUMBER=lv_bad_file_seq; -- 4 TIMES OCM SYNC
      if lv_ocm_flag='N' then
          Delete from config_environments_ocm;
          Delete from config_farms_ocm;
          Delete from config_client_projects_ocm;-- temporary commnt until FETCH CALL OF OCM is not in place
          COMMIT;
          -- Merge master config tables from _ocm staging tables that are fetched via ocm_sync_job 
          p_config_tables_merge_ocm (pin_processing_date=>(gv_processing_date+1), PIN_ITERATION_NUMBER=>lv_bad_file_seq );  -- 4 TIMES OCM SYNC
          execute immediate ' alter session set nls_date_format = ''dd-mon-yy''';
      END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
           commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_load_metrics_wrapper',pi_description =>'Error in p_table_ocm_sync_insert/p_config_tables_merge_ocm : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace );
    end;
  
    Begin
     p_fetch_app_metrics_wrapper(gv_processing_date,pi_attach_string_to_filenam => 'DW_INPUT');
     execute immediate ' alter session set nls_date_format = ''dd-mon-yy''';
     p_load_app_metrics_wrapper(gv_processing_date);
  
    EXCEPTION
      WHEN OTHERS THEN
           commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_load_metrics_wrapper',pi_description =>'Error in p_fetch_app_metrics_wrapper/p_load_app_metrics_wrapper : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace );
    end;
  
    --merge to update config_environment with latest Optymye_version
     --p_merge_config_environmnt_http(pi_processing_date=>gv_processing_date );
execute immediate ' alter session set nls_date_format = ''dd-mon-yy''';
    BEGIN
     p_load_phs_reports_wrapper(gv_processing_date);
     p_load_OS_reports_wrapper(gv_processing_date);
    EXCEPTION
    WHEN OTHERS THEN
          commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_load_metrics_wrapper',pi_description =>'Error in p_load_phs_reports_wrapper/p_load_OS_reports_wrapper : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace );
    end;
  
      Begin
      execute immediate ' alter session set nls_date_format = ''dd-mon-yy''';
       p_fetch_ws_metrics_wrapper(gv_processing_date+1,pi_attach_string_to_filenam => 'DW_INPUT'); -- ADD lv_attach_string_to_filename for determining the input string for prod or testing
       p_load_ws_wrapper(gv_processing_date);
       EXCEPTION
          WHEN OTHERS THEN
           commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_load_metrics_wrapper',pi_description =>'Error in p_fetch_ws_metrics_wrapper/p_load_ws_wrapper : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace );
        end;
        
        ------- prometheus metrics
        
         Begin
       p_fetch_PR_metrics_wrapper(gv_processing_date,pi_attach_string_to_filenam => 'DW_INPUT'); -- ADD lv_attach_string_to_filename for determining the input string for prod or testing
       p_load_PR_wrapper(gv_processing_date);
       EXCEPTION
          WHEN OTHERS THEN
           commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_load_metrics_wrapper',pi_description =>'Error in p_fetch_PR_metrics_wrapper/p_load_PR_wrapper : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace );
        end;
     
    -- get the average row length for all envs;
    p_get_a_row_byte_val;
      
     ---- MV refresh call
    Begin
      p_mview_refresh(lv_bad_file_seq);
    EXCEPTION
      WHEN OTHERS THEN
           commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_load_metrics_wrapper',pi_description =>'Error in p_mview_refresh : '|| SQLERRM|| 'Backtraced : ' || f_get_exception_backtrace );
    end;
     select PR_VALUE into lv_mail_flag from properties WHERE PR_ID=4 ;
     if lv_mail_flag ='Y'
       then
     commons_utils_1.p_send_alert_email(pin_processing_date=> gv_processing_date,pin_load_current_iteration=>lv_bad_file_seq);
     end if;
     
     commit;
    EXCEPTION
      WHEN OTHERS THEN
        commons_utils_1.p_error_logging(pi_metric_id    => 'p_load_metrics_wrapper',
                                    pi_procedure_name => 'p_load_metrics_wrapper',
                                    pi_error_message  => 'In  When others (last) of p_load_metrics_wrapper'|| ' Backtraced: ' || f_get_exception_backtrace,
                                    pi_error_in_code  => SQLERRM || SQLCODE,
                                    pi_tel_error_event_date => gv_processing_date);
        RAISE;
  END p_load_metrics_wrapper; */


 /* PROCEDURE p_job_create_ws_app_metrics IS
      exists_cnt pls_integer;
    BEGIN

      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_PROGRAMS
      WHERE PROGRAM_NAME = 'FETCH_WS_METRIC_PROG';

      IF exists_cnt      =0 THEN
                            sys.dbms_scheduler.create_program(program_name        => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_PROG',
                                                              program_type        => 'EXECUTABLE',
                                                              program_action      => '/home/oracle/telemetry/executor_ws.sh',
                                                              number_of_arguments => 4,
                                                              enabled             => false,
                                                              comments            => 'Program to fetch webservice metrics which calls .jar file from shell script');
                            sys.dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_PROG',
                                                                       argument_position   => 1,
                                                                       argument_name       => 'METRIC_FARM_ID',
                                                                       argument_type       => 'NUMBER',
                                                                       default_value       => '');
                            sys.dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_PROG',
                                                                       argument_position   => 2,
                                                                       argument_name       => 'METRIC_ENV_ID',
                                                                       argument_type       => 'NUMBER',
                                                                       default_value       => '');
                            sys.dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_PROG',
                                                                       argument_position   => 3,
                                                                       argument_name       => 'METRIC_NAME',
                                                                       argument_type       => 'VARCHAR2',
                                                                       default_value       => '');
                            sys.dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_PROG',
                                                                       argument_position   => 4,
                                                                       argument_name       => 'METRIC_WS_STRING',
                                                                       argument_type       => 'VARCHAR2',
                                                                       default_value       => '');
                            sys.dbms_scheduler.enable(name => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_PROG');
      end if;

      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_JOBS a
      WHERE JOB_NAME = 'FETCH_WS_METRIC_PROG';

      IF exists_cnt  =0 THEN


                            sys.dbms_scheduler.create_job(job_name            => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_JOB',
                                                          program_name        => 'optymyze_telemetry_dw_dev.FETCH_WS_METRIC_PROG',
                                                          job_class           => 'DEFAULT_JOB_CLASS',
                                                          enabled             => false,
                                                          auto_drop           => false,
                                                          comments            => 'This job will run the FETCH_WS_METRIC_PROG program');
      END IF;
    END p_job_create_ws_app_metrics;*/


    PROCEDURE p_job_create_fetch_app_metrics IS
      exists_cnt pls_integer;
   /* BEGIN

      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_PROGRAMS
      WHERE PROGRAM_NAME = 'FETCH_APP_METRIC_PROG';

      IF exists_cnt      =0 THEN

      dbms_scheduler.create_program(program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',
                                    program_type        => 'EXECUTABLE',
                                    program_action      => '/home/oracle/telemetry/executor.sh',
                                    number_of_arguments => 5,
                                    enabled             => false,
                                    comments            => 'Program to fetch application metrics which calls .jar file from shell script');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',
                                             argument_position   => 1,
                                             argument_name       => 'ACTION',
                                             argument_type       => 'VARCHAR2',
                                             default_value       => '');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',
                                             argument_position   => 2,
                                             argument_name       => 'START_TIME',
                                             argument_type       => 'NUMBER',
                                             default_value       => '');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',
                                             argument_position   => 3,
                                             argument_name       => 'END_TIME',
                                             argument_type       => 'NUMBER',
                                             default_value       => '');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',
                                             argument_position   => 4,
                                             argument_name       => 'FILE_IDENTIFIER',
                                             argument_type       => 'VARCHAR2',
                                             default_value       => 'TEST');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',
                                             argument_position   => 5,
                                             argument_name       => 'HEAP_SIZE',
                                             argument_type       => 'VARCHAR2',
                                             default_value       => '');
      dbms_scheduler.enable(name => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG');
      end if;

      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_JOBS a
      WHERE JOB_NAME = 'FETCH_APP_METRIC_JOB';

      IF exists_cnt  =0 THEN
          dbms_scheduler.create_job(job_name            => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_JOB',
                                program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',
                                start_date          => to_date(null),
                                repeat_interval     => '',
                                end_date            => to_date(null),
                                job_class           => 'DEFAULT_JOB_CLASS',
                                enabled             => false,
                                auto_drop           => false,
                                comments            => 'This job will run the FETCH_APP_METRIC_PROG program');
          dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_JOB',
                                            argument_name  => 'ACTION',
                                            argument_value => '-create');
          dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_JOB',
                                            argument_name  => 'START_TIME',
                                            argument_value => '');
          dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_JOB',
                                            argument_name  => 'END_TIME',
                                            argument_value => '');
          dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_JOB',
                                            argument_name  => 'FILE_IDENTIFIER',
                                            argument_value => 'DW_INPUT');
          dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_JOB',
                                            argument_name  => 'HEAP_SIZE',
                                            argument_value => '-Xmx1048m');

      END IF;*/
      BEGIN
      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_PROGRAMS
      WHERE PROGRAM_NAME = 'FETCH_APP_METRIC_PROG';
      IF exists_cnt      =0 THEN
     dbms_scheduler.create_program(program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',
                                    program_type        => 'EXECUTABLE',
                                    program_action      => '/home/oracle/telemetry/executor_combine_call.sh', ---- combine_job
                                    number_of_arguments => 7,
                                    enabled             => false,
                                    comments            => 'Combine program for FETCH_APP and GEO_LOCATION');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',
                                             argument_position   => 1,
                                             argument_name       => 'ACTION',
                                             argument_type       => 'VARCHAR2',
                                             default_value       => '');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',
                                             argument_position   => 2,
                                             argument_name       => 'START_TIME',
                                             argument_type       => 'NUMBER',
                                             default_value       => '');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',
                                             argument_position   => 3,
                                             argument_name       => 'END_TIME',
                                             argument_type       => 'NUMBER',
                                             default_value       => '');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',
                                             argument_position   => 4,
                                             argument_name       => 'FILE_IDENTIFIER',
                                             argument_type       => 'VARCHAR2',
                                             default_value       => 'TEST');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',
                                             argument_position   => 5,
                                             argument_name       => 'HEAP_SIZE',
                                             argument_type       => 'VARCHAR2',
                                             default_value       => '');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',  ---- combine_job
                                             argument_position   => 6,
                                             argument_name       => 'JOB_IDENTIFIER',
                                             argument_type       => 'VARCHAR2',
                                             default_value       => '');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',  ---- combine_job
                                             argument_position   => 7,
                                             argument_name       => 'EVENT_DATE',
                                             argument_type       => 'VARCHAR2',
                                             default_value       => '');
      dbms_scheduler.enable(name => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG');
      END IF;
      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_JOBS a
      WHERE JOB_NAME = 'FETCH_APP_METRIC_JOB';
      IF exists_cnt  =0 THEN
          dbms_scheduler.create_job(job_name            => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_JOB',
                                program_name        => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_PROG',
                                start_date          => to_date(null),
                                repeat_interval     => '',
                                end_date            => to_date(null),
                                job_class           => 'DEFAULT_JOB_CLASS',
                                    Enabled => FALSE,
                                    auto_drop => FALSE,
                                comments            => 'This job will run the FETCH_APP_METRIC_PROG program');
          dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_JOB',
                                            argument_name  => 'ACTION',
                                            argument_value => '-create');
          dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_JOB',
                                            argument_name  => 'START_TIME',
                                            argument_value => '');
          dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_JOB',
                                            argument_name  => 'END_TIME',
                                            argument_value => '');
          dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_JOB',
                                            argument_name  => 'FILE_IDENTIFIER',
                                            argument_value => 'DW_INPUT');
          dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_JOB',
                                            argument_name  => 'HEAP_SIZE',
                                            argument_value => '-Xmx1048m');
                                                 ---- combine_job
          dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_JOB',
                                            argument_name  => 'JOB_IDENTIFIER',
                                            argument_value => '');
          dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_APP_METRIC_JOB',
                                            argument_name  => 'EVENT_DATE',
                                            argument_value => '');                                  
      END IF;
    END p_job_create_fetch_app_metrics;
    
    
PROCEDURE p_job_create_SQS_metrics IS
      exists_cnt pls_integer;
     BEGIN
      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_PROGRAMS
      WHERE PROGRAM_NAME = 'FETCH_SQS_METRIC_PROG';
      IF exists_cnt      =0 THEN
     dbms_scheduler.create_program(program_name        => 'optymyze_telemetry_dw_dev.FETCH_SQS_METRIC_PROG',
                                    program_type        => 'EXECUTABLE',
                                    program_action      => '/home/oracle/telemetry/SQS/executor_SQS_metric.sh', ---- combine_job
                                    number_of_arguments => 2,
                                    enabled             => false,
                                    comments            => 'Shell script call for fetching of event based metrics through SQS');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_SQS_METRIC_PROG',
                                             argument_position   => 1,
                                             argument_name       => 'HEAP_SIZE',
                                             argument_type       => 'VARCHAR2',
                                             default_value       => '');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_SQS_METRIC_PROG',
                                             argument_position   => 2,
                                             argument_name       => 'METRIC_CSV_PATH',
                                             argument_type       => 'VARCHAR2',
                                             default_value       => '');

      dbms_scheduler.enable(name => 'optymyze_telemetry_dw_dev.FETCH_SQS_METRIC_PROG');
      END IF;
      
      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_JOBS a
      WHERE JOB_NAME = 'FETCH_SQS_METRIC_JOB';
      IF exists_cnt  =0 THEN
          dbms_scheduler.create_job(job_name            => 'optymyze_telemetry_dw_dev.FETCH_SQS_METRIC_JOB',
                                    program_name        => 'optymyze_telemetry_dw_dev.FETCH_SQS_METRIC_PROG',
                                    start_date          => to_date(null),
                                    repeat_interval     => '',
                                    end_date            => to_date(null),
                                    job_class           => 'DEFAULT_JOB_CLASS',
                                    Enabled => FALSE,
                                    auto_drop => FALSE,
                                    comments            => 'This job will run the FETCH_SQS_METRIC_PROG program');
                                          
        dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_SQS_METRIC_JOB',
                                          argument_name  => 'HEAP_SIZE',
                                          argument_value => '');
        dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_SQS_METRIC_JOB',
                                          argument_name  => 'METRIC_CSV_PATH',
                                          argument_value => '');
                                          
      END IF;
      
    END p_job_create_SQS_metrics;
    
    
    
    PROCEDURE p_job_create_PR_metrics IS
      exists_cnt pls_integer;
     BEGIN
      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_PROGRAMS
      WHERE PROGRAM_NAME = 'FETCH_PROMETHEUS_METRIC_PROG';
      IF exists_cnt      =0 THEN
     dbms_scheduler.create_program(program_name        => 'optymyze_telemetry_dw_dev.FETCH_PROMETHEUS_METRIC_PROG',
                                    program_type        => 'EXECUTABLE',
                                    program_action      => '/home/oracle/telemetry/executor_prometheus_metric.sh', ---- combine_job
                                    number_of_arguments => 3,
                                    enabled             => false,
                                    comments            => 'Shell script call for fetching prometheus metrics');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_PROMETHEUS_METRIC_PROG',
                                             argument_position   => 1,
                                             argument_name       => 'METRIC_NAME',
                                             argument_type       => 'VARCHAR2',
                                             default_value       => '');
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_PROMETHEUS_METRIC_PROG',
                                             argument_position   => 2,
                                             argument_name       => 'FILE_IDENTIFIER',
                                             argument_type       => 'VARCHAR2',
                                             default_value       => 'DW_INPUT');
                                             
                                             
      dbms_scheduler.define_program_argument(program_name        => 'optymyze_telemetry_dw_dev.FETCH_PROMETHEUS_METRIC_PROG',
                                             argument_position   => 3,
                                             argument_name       => 'HEAP_SIZE',
                                             argument_type       => 'VARCHAR2',
                                             default_value       => '');
                                             
      dbms_scheduler.enable(name => 'optymyze_telemetry_dw_dev.FETCH_PROMETHEUS_METRIC_PROG');
      END IF;
      
      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_JOBS a
      WHERE JOB_NAME = 'FETCH_PROMETHEUS_METRIC_JOB';
      IF exists_cnt  =0 THEN
          dbms_scheduler.create_job(job_name            => 'optymyze_telemetry_dw_dev.FETCH_PROMETHEUS_METRIC_JOB',
                                program_name        => 'optymyze_telemetry_dw_dev.FETCH_PROMETHEUS_METRIC_PROG',
                                start_date          => to_date(null),
                                repeat_interval     => '',
                                end_date            => to_date(null),
                                job_class           => 'DEFAULT_JOB_CLASS',
                                    Enabled => FALSE,
                                    auto_drop => FALSE,
                                comments            => 'This job will run the FETCH_PROMETHEUS_METRIC_PROG program');
          dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_PROMETHEUS_METRIC_JOB',
                                            argument_name  => 'METRIC_NAME',
                                            argument_value => '');
          dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_PROMETHEUS_METRIC_JOB',
                                            argument_name  => 'FILE_IDENTIFIER',
                                            argument_value => 'DW_INPUT');
           
          dbms_scheduler.set_job_argument_value(job_name       => 'optymyze_telemetry_dw_dev.FETCH_PROMETHEUS_METRIC_JOB',
                                            argument_name  => 'HEAP_SIZE',
                                            argument_value => '-Xmx1048m');                                 
                        
      END IF;
      
    END p_job_create_PR_metrics;
    
    
    PROCEDURE p_job_create_ocm_sync IS
      exists_cnt pls_integer;
    BEGIN

      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_PROGRAMS
      WHERE PROGRAM_NAME = 'OCM_SYNC_PROG';
      IF exists_cnt      =0 THEN
     dbms_scheduler.create_program(program_name        => 'optymyze_telemetry_dw_dev.OCM_SYNC_PROG',
                                    program_type        => 'EXECUTABLE',
                                    program_action      => '/home/oracle/telemetry/executor_ocm_sync.sh',
                                    number_of_arguments => 0,
                                    enabled             => false,
                                    comments            => 'Program to fetch application metrics which calls .jar file from shell script');
      dbms_scheduler.enable(name => 'optymyze_telemetry_dw_dev.OCM_SYNC_PROG');
      end if;
      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_JOBS a
      WHERE JOB_NAME = 'OCM_SYNC_JOB';
      IF exists_cnt  =0 THEN
          dbms_scheduler.create_job(job_name            => 'optymyze_telemetry_dw_dev.OCM_SYNC_JOB',
                                program_name        => 'optymyze_telemetry_dw_dev.OCM_SYNC_PROG',
                                start_date          => to_date(null),
                                repeat_interval     => '',
                                end_date            => to_date(null),
                                job_class           => 'DEFAULT_JOB_CLASS',
                                enabled             => false,
                                auto_drop           => false,
                                comments            => 'This job will run the OCM_SYNC_PROG program');
     /* dbms_scheduler.create_job(job_name     => 'FETCH_APP_METRIC_JOB',
                                    program_name => 'FETCH_APP_METRIC_PROG',
                                    Enabled => FALSE,
                                    auto_drop => FALSE,
                                    Comments => 'This job will run the FETCH_APP_METRIC_PROG program');*/
      END IF;
    END p_job_create_ocm_sync;
    

    PROCEDURE p_job_creation
    IS
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Wrapper procedure that creates all jobs that are required 
  
  -- Change description :
  -- -----------------------------------------------------------------------------    
      exists_cnt pls_integer;
    BEGIN

        SELECT COUNT(1)
        INTO exists_cnt
        FROM user_SCHEDULER_SCHEDULES
        WHERE schedule_name = 'SIX_HOURS_SCHEDULE';

        IF exists_cnt       =0 THEN
          -- schedule Creation
          Dbms_scheduleR.create_schedule (schedule_name => 'SIX_HOURS_SCHEDULE', Repeat_interval => 'FREQ=HOURLY; INTERVAL=6',start_date => TRUNC(SYSDATE)-900/86400, Comments => '6 hourly schedule');
       END IF;

        SELECT COUNT(1)
        INTO exists_cnt
        FROM user_SCHEDULER_PROGRAMS
        WHERE PROGRAM_NAME = 'LOAD_METRIC_PROG';

        IF exists_cnt      =0 THEN
          --Program Creation
         /* Dbms_scheduler.create_program (program_name => 'LOAD_METRIC_PROG',
          Program_type =>'STORED_PROCEDURE',
          Program_action => 'commons_utils_1.p_load_metrics_wrapper',
          Enabled => TRUE,
          Comments => 'This would load all the metrics to the database'
          );*/
            Dbms_scheduler.create_program (program_name => 'LOAD_METRIC_PROG',
          Program_type =>'STORED_PROCEDURE',
          Program_action => 'commons_utils_1.p_load_metrics_wrapper',
          Enabled => False,
          number_of_arguments => 1,                   ---- enhancement for timely mail alert
          Comments => 'This would load all the metrics to the database'
          );
     dbms_scheduler.define_program_argument(program_name      => 'LOAD_METRIC_PROG',
                                         argument_position => 1,
                                         argument_name     => 'P_check_flag',
                                         argument_type     => 'VARCHAR2',
                                         default_value     => 'Y');
     dbms_scheduler.enable(name =>'LOAD_METRIC_PROG' );

        END IF;

        SELECT COUNT(1)
        INTO exists_cnt
        FROM user_SCHEDULER_JOBS a
        WHERE JOB_NAME = 'LOAD_METRIC_JOB';

        IF exists_cnt  =0 THEN
          -- Job creation
        Dbms_scheduler.create_job
        (Job_name => 'LOAD_METRIC_JOB',
        Program_name => 'LOAD_METRIC_PROG',
        Schedule_name => 'SIX_HOURS_SCHEDULE',
        Enabled => TRUE,
        auto_drop => FALSE,
        Comments => 'This job will run the LOAD_METRIC_PROG program according to the SIX_HOURS_SCHEDULE schedule.');

    END IF;
/*
------------- geo location job      ---- OF-80673
        SELECT COUNT(1)
        INTO exists_cnt
        FROM user_SCHEDULER_SCHEDULES
        WHERE schedule_name = 'SIX_HOURS_SCHEDULE_3AM';
        IF exists_cnt       =0 THEN
          -- schedule Creation
          --Dbms_scheduleR.create_schedule (schedule_name => 'SIX_HOURS_SCHEDULE', Repeat_interval => 'FREQ=HOURLY; INTERVAL=6',start_date => TRUNC(SYSDATE)-900/86400, Comments => '6 hourly schedule');
            Dbms_scheduleR.create_schedule(schedule_name   => 'SIX_HOURS_SCHEDULE_3AM',
                                 Repeat_interval => 'FREQ=HOURLY; INTERVAL=6',
                                 start_date      => TRUNC(SYSDATE)-32400/86400,
                                 Comments        => 'SIX HOURS SCHEDULE START WITH 3AM');
       END IF;
        SELECT COUNT(1)
        INTO exists_cnt
        FROM user_SCHEDULER_PROGRAMS
        WHERE PROGRAM_NAME = 'GEO_LOCATION_PROG';
        IF exists_cnt      =0 THEN
          --Program Creation
           Dbms_scheduler.create_program(program_name        => 'GEO_LOCATION_PROG',
                                Program_type        => 'STORED_PROCEDURE',
                                Program_action      => 'commons_utils_1.p_geo_location_insert',
                                Enabled             => TRUE,
                                number_of_arguments => 0,
                                Comments            => 'Program for geo location scheduler');
        END IF;
        SELECT COUNT(1)
        INTO exists_cnt
        FROM user_SCHEDULER_JOBS a
        WHERE JOB_NAME = 'GEO_LOCATION_JOB';
        IF exists_cnt  =0 THEN
          -- Job creation
        Dbms_scheduler.create_job(Job_name      => 'GEO_LOCATION_JOB',
                            Program_name  => 'GEO_LOCATION_PROG',
                            Schedule_name => 'SIX_HOURS_SCHEDULE_3AM',
                            Enabled       => TRUE,
                            auto_drop     => FALSE,
                            Comments      => 'This job will run the P_GEO_LOCATION_INSERT procedure according to the SIX_HOURS_SCHEDULE_3AM schedule.');
        END IF;
-----------------------------
*/

        -- create job for the fetching of application metrics from the graphite server to be invoked from the wrapper code
        p_job_create_fetch_app_metrics;
        -- create job for the fetching of WEB SERVICE metrics from the graphite server to be invoked from the wrapper code
        p_job_create_fetch_ws_metrics;
        -- create job for ocm sync
        p_job_create_ocm_sync;
        
          -- create job for the fetching of application metrics through SQS
        p_job_create_SQS_metrics;
        
         -- create job for the fetching of PROMETHEUS metrics
        p_job_create_PR_metrics;
        --- create job for the loading and mv refresh  of SQS metrics
        p_job_create_load_mv_Sqs;
        
    END p_job_creation;


  PROCEDURE p_job_delete_fetch_app_metrics IS
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Wrapper procedure that deletes jobs that are required for fetching application metrics
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    exists_cnt pls_integer;
  BEGIN

    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_PROGRAMS
    WHERE PROGRAM_NAME = 'FETCH_APP_METRIC_PROG';

    IF exists_cnt      =1 THEN
      dbms_scheduler.drop_program('FETCH_APP_METRIC_PROG',TRUE);
    end if;

    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_JOBS a
    WHERE JOB_NAME = 'FETCH_APP_METRIC_JOB';

    IF exists_cnt  =1 THEN
        dbms_scheduler.drop_job('FETCH_APP_METRIC_JOB',TRUE);
    END IF;

  END p_job_delete_fetch_app_metrics;
  
   PROCEDURE p_job_delete_SQS_metrics IS

    exists_cnt pls_integer;
  BEGIN

    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_PROGRAMS
    WHERE PROGRAM_NAME = 'FETCH_SQS_METRIC_PROG';

    IF exists_cnt      =1 THEN
      dbms_scheduler.drop_program('FETCH_SQS_METRIC_PROG',TRUE);
    end if;

    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_JOBS a
    WHERE JOB_NAME = 'FETCH_SQS_METRIC_JOB';

    IF exists_cnt  =1 THEN
        dbms_scheduler.drop_job('FETCH_SQS_METRIC_JOB',TRUE);
    END IF;

  END p_job_delete_SQS_metrics;
  
  
  PROCEDURE p_job_delete_PR_metrics IS

    exists_cnt pls_integer;
  BEGIN

    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_PROGRAMS
    WHERE PROGRAM_NAME = 'FETCH_PROMETHEUS_METRIC_PROG';

    IF exists_cnt      =1 THEN
      dbms_scheduler.drop_program('FETCH_PROMETHEUS_METRIC_PROG',TRUE);
    end if;

    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_JOBS a
    WHERE JOB_NAME = 'FETCH_PROMETHEUS_METRIC_JOB';

    IF exists_cnt  =1 THEN
        dbms_scheduler.drop_job('FETCH_PROMETHEUS_METRIC_JOB',TRUE);
    END IF;

  END p_job_delete_PR_metrics;
  
   PROCEDURE p_job_delete_ws_metrics IS
    exists_cnt pls_integer;
  BEGIN
    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_PROGRAMS
    WHERE PROGRAM_NAME = 'FETCH_WS_METRIC_PROG';
    IF exists_cnt      =1 THEN
      dbms_scheduler.drop_program('FETCH_WS_METRIC_PROG',TRUE);
    end if;
    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_JOBS a
    WHERE JOB_NAME = 'OCM_SYNC_JOB';
    IF exists_cnt  =1 THEN
        dbms_scheduler.drop_job('OCM_SYNC_JOB',TRUE);
    END IF;
  END p_job_delete_ws_metrics;
  PROCEDURE p_job_delete_ocm_sync IS
    exists_cnt pls_integer;
  BEGIN
    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_PROGRAMS
    WHERE PROGRAM_NAME = 'OCM_SYNC_PROG';
    IF exists_cnt      =1 THEN
      dbms_scheduler.drop_program('OCM_SYNC_PROG',TRUE);
    end if;
    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_JOBS a
    WHERE JOB_NAME = 'FETCH_WS_METRIC_JOB';
    IF exists_cnt  =1 THEN
        dbms_scheduler.drop_job('FETCH_WS_METRIC_JOB',TRUE);
    END IF;
  END p_job_delete_ocm_sync;


    PROCEDURE p_job_deletion
    IS
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Wrapper procedure that deletes all jobs
  
  -- Change description :
  -- -----------------------------------------------------------------------------
      exists_cnt pls_integer;
    BEGIN
        SELECT COUNT(1)
        INTO exists_cnt
        FROM user_SCHEDULER_SCHEDULES
        WHERE schedule_name = 'SIX_HOURS_SCHEDULE';

        IF exists_cnt       =1 THEN
          -- schedule Creation
          Dbms_scheduleR.drop_schedule('SIX_HOURS_SCHEDULE',TRUE);
        END IF;
/*
        SELECT COUNT(1)
        INTO exists_cnt
        FROM user_SCHEDULER_PROGRAMS
        WHERE PROGRAM_NAME = 'GEO_LOCATION_PROG';
        IF exists_cnt      =1 THEN
          --Program Creation
          Dbms_scheduler.drop_program ('GEO_LOCATION_PROG', TRUE);
        END IF;
        SELECT COUNT(1)
        INTO exists_cnt
        FROM user_SCHEDULER_JOBS a
        WHERE JOB_NAME = 'GEO_LOCATION_JOB';
        IF exists_cnt  =1 THEN
          -- Job creation
          Dbms_scheduler.drop_job ( 'GEO_LOCATION_JOB',TRUE);
        END IF;
--------------------------------- geo location job      ---- OF-80673
  SELECT COUNT(1)
        INTO exists_cnt
        FROM user_SCHEDULER_SCHEDULES
        WHERE schedule_name = 'SIX_HOURS_SCHEDULE_3AM';
        IF exists_cnt       =1 THEN
          -- schedule Creation
          Dbms_scheduleR.drop_schedule('SIX_HOURS_SCHEDULE_3AM',TRUE);
        END IF;
*/
        SELECT COUNT(1)
        INTO exists_cnt
        FROM user_SCHEDULER_PROGRAMS
        WHERE PROGRAM_NAME = 'LOAD_METRIC_PROG';

        IF exists_cnt      =1 THEN
          --Program Creation
          Dbms_scheduler.drop_program ('LOAD_METRIC_PROG', TRUE);
        END IF;

        SELECT COUNT(1)
        INTO exists_cnt
        FROM user_SCHEDULER_JOBS a
        WHERE JOB_NAME = 'LOAD_METRIC_JOB';

        IF exists_cnt  =1 THEN
          -- Job creation
          Dbms_scheduler.drop_job ( 'LOAD_METRIC_JOB',TRUE);
        END IF;

    -- delete job for the fetching of application metrics from the graphite server to be invoked from the wrapper code
    p_job_delete_fetch_app_metrics;
    -- delete job for the fetching of webservice metrics to be invoked from the wrapper code
    p_job_delete_ws_metrics;
     -- delete job for ocm_sync tables
    p_job_delete_ocm_sync;
    
     -- delete job for the fetching of application metrics through SQS
    p_job_delete_SQS_metrics;
    
     -- delete job for the fetching of prometheus metrics
    p_job_delete_PR_metrics;
    
    -- delete job for the loading and mv refresh  of SQS metrics
    p_job_deletion_load_mv_sqs;
    
    END p_job_deletion;

  
    PROCEDURE p_job_create_app_met_fol_del IS
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Folder deletion job creation
  
  -- Change description :
  -- -----------------------------------------------------------------------------     
    exists_cnt pls_integer;
    BEGIN

      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_PROGRAMS
      WHERE PROGRAM_NAME = 'DEL_APP_METRIC_FOLDER_PROG';

      IF exists_cnt      =0 THEN
        dbms_scheduler.create_program(program_name        => 'DEL_APP_METRIC_FOLDER_PROG',
                                      program_type        => 'EXECUTABLE',
                                      program_action      => '/home/oracle/telemetry/Drop_Application_Metrics_folders.sh',
                                      number_of_arguments => 3,
                                      Enabled => FALSE,
                                      comments            => 'Program to delete all application metrics folders from the  shell script');

        dbms_scheduler.define_program_argument(program_name      => 'DEL_APP_METRIC_FOLDER_PROG',
                                               argument_name     => 'path_csv_folder',
                                               argument_position => 1,
                                               argument_type     => 'VARCHAR2');
        dbms_scheduler.define_program_argument(program_name      => 'DEL_APP_METRIC_FOLDER_PROG',
                                               argument_name     => 'path_logging_folder',
                                               argument_position => 2,
                                               argument_type     => 'VARCHAR2');
        dbms_scheduler.define_program_argument(program_name      => 'DEL_APP_METRIC_FOLDER_PROG',
                                               argument_name     => 'metric_name_date',
                                               argument_position => 3,
                                               argument_type     => 'VARCHAR2');

        dbms_scheduler.enable(NAME => 'DEL_APP_METRIC_FOLDER_PROG');
      end if;

      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_JOBS a
      WHERE JOB_NAME = 'DEL_APP_METRIC_FOLDER_JOB';

      IF exists_cnt  =0 THEN
          dbms_scheduler.create_job(job_name     => 'DEL_APP_METRIC_FOLDER_JOB',
                                    program_name => 'DEL_APP_METRIC_FOLDER_PROG',
                                    Enabled => FALSE,
                                    auto_drop => FALSE,
                                    Comments => 'This job will run the DEL_APP_METRIC_FOLDER_PROG program');
      END IF;
    END p_job_create_app_met_fol_del;

  
    PROCEDURE p_job_delete_app_met_fol_del IS
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Folder deletion job creation
  
  -- Change description :
  -- -----------------------------------------------------------------------------     
    exists_cnt pls_integer;
  BEGIN

    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_PROGRAMS
    WHERE PROGRAM_NAME = 'DEL_APP_METRIC_FOLDER_PROG';

    IF exists_cnt      =1 THEN
      dbms_scheduler.drop_program('DEL_APP_METRIC_FOLDER_PROG',TRUE);
    end if;

    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_JOBS a
    WHERE JOB_NAME = 'DEL_APP_METRIC_FOLDER_JOB';

    IF exists_cnt  =1 THEN
        dbms_scheduler.drop_job('DEL_APP_METRIC_FOLDER_JOB',TRUE);
    END IF;

  END p_job_delete_app_met_fol_del;

 /*PROCEDURE p_job_create_ws_met_fol_del IS
    exists_cnt pls_integer;
    BEGIN

      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_PROGRAMS
      WHERE PROGRAM_NAME = 'DEL_WS_METRIC_FOLDER_PROG';

      IF exists_cnt      =0 THEN
        dbms_scheduler.create_program(program_name        => 'DEL_WS_METRIC_FOLDER_PROG',
                                      program_type        => 'EXECUTABLE',
                                      program_action      => '/home/oracle/telemetry/Drop_WS_Metrics_folders.sh',
                                      number_of_arguments => 2,
                                      Enabled => FALSE,
                                      comments            => 'Program to delete all webservice metrics folders from the  shell script');

        dbms_scheduler.define_program_argument(program_name      => 'DEL_WS_METRIC_FOLDER_PROG',
                                               argument_name     => 'path_logging_folder',
                                               argument_position => 1,
                                               argument_type     => 'VARCHAR2');
        dbms_scheduler.define_program_argument(program_name      => 'DEL_WS_METRIC_FOLDER_PROG',
                                               argument_name     => 'metric_name_date',
                                               argument_position => 2,
                                               argument_type     => 'VARCHAR2');

        dbms_scheduler.enable(NAME => 'DEL_WS_METRIC_FOLDER_PROG');
      end if;

      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_JOBS a
      WHERE JOB_NAME = 'DEL_WS_METRIC_FOLDER_JOB';

      IF exists_cnt  =0 THEN
          dbms_scheduler.create_job(job_name     => 'DEL_WS_METRIC_FOLDER_JOB',
                                    program_name => 'DEL_WS_METRIC_FOLDER_PROG',
                                    Enabled => FALSE,
                                    auto_drop => FALSE,
                                    Comments => 'This job will run the DEL_WS_METRIC_FOLDER_PROG program');
      END IF;
    END p_job_create_ws_met_fol_del;

      PROCEDURE p_job_delete_ws_met_fol_del IS
    exists_cnt pls_integer;
  BEGIN

    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_PROGRAMS
    WHERE PROGRAM_NAME = 'DEL_WS_METRIC_FOLDER_PROG';

    IF exists_cnt      =1 THEN
      dbms_scheduler.drop_program('DEL_WS_METRIC_FOLDER_PROG',TRUE);
    end if;

    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_JOBS a
    WHERE JOB_NAME = 'DEL_WS_METRIC_FOLDER_JOB';

    IF exists_cnt  =1 THEN
        dbms_scheduler.drop_job('DEL_WS_METRIC_FOLDER_JOB',TRUE);
    END IF;

  END p_job_delete_ws_met_fol_del;*/

    PROCEDURE p_job_cr_Logging_bad_file_del IS
      exists_cnt pls_integer;
    BEGIN

      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_PROGRAMS
      WHERE PROGRAM_NAME = 'DEL_PHS_METRIC_LOGFILE_PROG';

      IF exists_cnt      =0 THEN
        dbms_scheduler.create_program(program_name        => 'DEL_PHS_METRIC_LOGFILE_PROG',
                                      program_type        => 'EXECUTABLE',
                                      program_action      => '/home/oracle/telemetry/Drop_Bad_Logging_file_PHS.sh',
                                      number_of_arguments => 2,
                                      Enabled => FALSE,
                                      comments            => 'Program to delete all .bad and .log files from the logging folder for a metric from the  shell script');

        dbms_scheduler.define_program_argument(program_name      => 'DEL_PHS_METRIC_LOGFILE_PROG',
                                               argument_name     => 'path_logging_folder',
                                               argument_position => 1,
                                               argument_type     => 'VARCHAR2');
        dbms_scheduler.define_program_argument(program_name      => 'DEL_PHS_METRIC_LOGFILE_PROG',
                                               argument_name     => 'metric_name_date',
                                               argument_position => 2,
                                               argument_type     => 'VARCHAR2');

        dbms_scheduler.enable(NAME => 'DEL_PHS_METRIC_LOGFILE_PROG');
      end if;

      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_JOBS a
      WHERE JOB_NAME = 'DEL_PHS_METRIC_LOGFILE_JOB';

      IF exists_cnt  =0 THEN
          dbms_scheduler.create_job(job_name     => 'DEL_PHS_METRIC_LOGFILE_JOB',
                                    program_name => 'DEL_PHS_METRIC_LOGFILE_PROG',
                                    Enabled => FALSE,
                                    auto_drop => FALSE,
                                    Comments => 'This job will run the DEL_PHS_METRIC_LOGFILE_PROG program');
      END IF;
    END p_job_cr_Logging_bad_file_del;

    PROCEDURE p_job_del_Logging_bad_file_del IS
    exists_cnt pls_integer;
  BEGIN

    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_PROGRAMS
    WHERE PROGRAM_NAME = 'DEL_PHS_METRIC_LOGFILE_PROG';

    IF exists_cnt      =1 THEN
      dbms_scheduler.drop_program('DEL_PHS_METRIC_LOGFILE_PROG',TRUE);
    end if;

    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_JOBS a
    WHERE JOB_NAME = 'DEL_PHS_METRIC_LOGFILE_JOB';

    IF exists_cnt  =1 THEN
        dbms_scheduler.drop_job('DEL_PHS_METRIC_LOGFILE_JOB',TRUE);
    END IF;

  END p_job_del_Logging_bad_file_del;
    PROCEDURE p_job_OS_Log_bad_file_cr IS
      exists_cnt pls_integer;
    BEGIN

      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_PROGRAMS
      WHERE PROGRAM_NAME = 'DEL_OS_METRIC_LOGFILE_PROG';

      IF exists_cnt      =0 THEN
        dbms_scheduler.create_program(program_name        => 'DEL_OS_METRIC_LOGFILE_PROG',
                                      program_type        => 'EXECUTABLE',
                                      program_action      => '/home/oracle/telemetry/Drop_Bad_Logging_file_OS.sh',
                                      number_of_arguments => 2,
                                      Enabled => FALSE,
                                      comments            => 'Program to delete all .bad and .log files from the logging folder for a metric from the  shell script');
        dbms_scheduler.define_program_argument(program_name      => 'DEL_OS_METRIC_LOGFILE_PROG',
                                               argument_name     => 'path_logging_folder',
                                               argument_position => 1,
                                               argument_type     => 'VARCHAR2');
        dbms_scheduler.define_program_argument(program_name      => 'DEL_OS_METRIC_LOGFILE_PROG',
                                               argument_name     => 'metric_name_date',
                                               argument_position => 2,
                                               argument_type     => 'VARCHAR2');
        dbms_scheduler.enable(NAME => 'DEL_OS_METRIC_LOGFILE_PROG');
      end if;
      SELECT COUNT(1)
      INTO exists_cnt
      FROM user_SCHEDULER_JOBS a
      WHERE JOB_NAME = 'DEL_OS_METRIC_LOGFILE_JOB';
      IF exists_cnt  =0 THEN
          dbms_scheduler.create_job(job_name     => 'DEL_OS_METRIC_LOGFILE_JOB',
                                    program_name => 'DEL_OS_METRIC_LOGFILE_PROG',
                                    Enabled => FALSE,
                                    auto_drop => FALSE,
                                    Comments => 'This job will run the DEL_OS_METRIC_LOGFILE_PROG program');
      END IF;
    END p_job_OS_Log_bad_file_cr;
    
    PROCEDURE p_job_OS_Log_bad_file_del IS
    exists_cnt pls_integer;
  BEGIN
    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_PROGRAMS
    WHERE PROGRAM_NAME = 'DEL_OS_METRIC_LOGFILE_PROG';
    IF exists_cnt      =1 THEN
      dbms_scheduler.drop_program('DEL_OS_METRIC_LOGFILE_PROG',TRUE);
    end if;
    SELECT COUNT(1)
    INTO exists_cnt
    FROM user_SCHEDULER_JOBS a
    WHERE JOB_NAME = 'DEL_OS_METRIC_LOGFILE_JOB';
    IF exists_cnt  =1 THEN
        dbms_scheduler.drop_job('DEL_OS_METRIC_LOGFILE_JOB',TRUE);
    END IF;
  END p_job_OS_Log_bad_file_del;

  
    PROCEDURE p_geo_location_insert IS            ---- OF-80673
  -- -----------------------------------------------------------------------------
  -- Author         : Vinchankar Shilpa
  -- Reviewer       : Rajput Gaurav
  -- Description    : Geolocation Insert table
  
  -- Change description :
  -- -----------------------------------------------------------------------------     
      pragma autonomous_transaction;
      v_geo_loc_last_run_date date;
    BEGIN
    
    select sys_context('gc_geo_loc_last_run_date', 'global_attribute') into v_geo_loc_last_run_date from dual; 
    
    
    ---- UPDATION OF EXPIRED RECORDS
    UPDATE TABLE_GEOLOCATION T
       SET T.IS_INTERNAL = NULL
     WHERE TRUNC(T.EVENT_DATE) < TRUNC(ADD_MONTHS(SYSDATE, -1))
       AND EXISTS
     (SELECT 1
          from (WITH DATA AS (SELECT T.CLIENT_IP_ADDRESS CLIENT_IPS
                                    FROM TABLE_USER_LOGIN_INFORMATION T
                                   WHERE TRUNC(T.EVENT_TIME) BETWEEN
                                         v_geo_loc_last_run_date + 1 AND
                                         gv_processing_date)
                 SELECT trim(regexp_substr(CLIENT_IPS, '[^,]+', 1, LEVEL)) CLIENT_IPS
                   FROM DATA 
                     CONNECT BY REGEXP_SUBSTR(CLIENT_IPS, '[^,]+', 1, LEVEL) IS NOT NULL)
                     WHERE CLIENT_IPS = T.IP_ADDRESS
            );
      INSERT INTO TABLE_GEOLOCATION
        (IP_ADDRESS_INTERNAL, IS_INTERNAL, EVENT_DATE)
       SELECT DISTINCT CLIENT_IPS, NULL, EVENT_TIME
            FROM (WITH DATA AS (SELECT T.CLIENT_IP_ADDRESS CLIENT_IPS,
                                       TRUNC(T.EVENT_TIME) EVENT_TIME
                                  FROM TABLE_USER_LOGIN_INFORMATION T
                                 WHERE TRUNC(T.EVENT_TIME) BETWEEN
                                       v_geo_loc_last_run_date+1 AND gv_processing_date)
                   SELECT TRIM(REGEXP_SUBSTR(CLIENT_IPS, '[^,]+', 1, LEVEL)) CLIENT_IPS,
                          EVENT_TIME
                     FROM DATA
                 CONNECT BY regexp_substr(CLIENT_IPS, '[^,]+', 1, LEVEL) IS NOT NULL) A
                  WHERE NOT EXISTS
                  (SELECT 1
                           FROM TABLE_GEOLOCATION G
                          WHERE G.IP_ADDRESS_INTERNAL = A.CLIENT_IPS);
    commit;
    ----- CALL JAVA UTILITY
     p_job_run_fetch_app_metrics(NULL, NULL, NULL, 'DW_INPUT' ,NULL ,'GEO_LOCATION',to_char(TO_DATE(gv_processing_date,'DD-MM-RRRR'),'DD-MM-RRRR')); ----COMBINE_JOB 
    --dbms_session.set_context('gc_geo_loc_last_run_date', 'global_attribute', gv_processing_date-1);
    p_set_context_geo_location;
    EXCEPTION
      WHEN OTHERS THEN
        commons_utils_1.p_error_logging(pi_metric_id            => 'p_geo_location_insert',
                                      pi_procedure_name       => 'p_geo_location_insert',
                                      pi_error_message        => 'Error in inserting TABLE_GEOLOCATION  due to : '|| f_get_exception_backtrace,
                                      pi_error_in_code        => SQLCODE,
                                      pi_tel_error_event_date => gv_processing_date);
    END p_geo_location_insert;
  
  procedure p_set_context_geo_location(pin_last_run_date date default gv_processing_date-1 )IS
  begin
   dbms_session.set_context('gc_geo_loc_last_run_date', 'global_attribute',pin_last_run_date);   
  end p_set_context_geo_location;
  
  procedure p_set_context_loader_seq(pin_loader_seq pls_integer default loader_seq.nextval ) IS
  begin
     dbms_session.set_context('gc_loader_seq_cur_val', 'global_attribute', pin_loader_seq);   
  end p_set_context_loader_seq;
  
  procedure p_set_context_logging(pin_logging pls_integer default commons_utils_1.c_logging_disable) IS
  begin
  dbms_session.set_context('gc_logging', 'global_attribute', pin_logging);  
  end;
  
  
  procedure p_create_context_logging IS
  begin
   execute immediate'create context gc_logging using commons_utils_1 accessed globally'; 
   p_set_context_logging;
  end  p_create_context_logging;

  procedure p_create_context_geo_location IS
  begin
   execute immediate'create context gc_geo_loc_last_run_date using commons_utils_1 accessed globally';
   p_set_context_geo_location;
  end p_create_context_geo_location;
  
  procedure p_create_context_loader_seq IS
  begin
   execute immediate'create context gc_loader_seq_cur_val using commons_utils_1 accessed globally'; 
  end p_create_context_loader_seq;
  
  procedure p_set_context_new_loader_seq(pin_loader_seq pls_integer default new_loader_seq.nextval ) IS
  begin
     dbms_session.set_context('gc_new_loader_seq_cur_val', 'global_attribute', pin_loader_seq);   
  end p_set_context_new_loader_seq;
  
  procedure p_create_context_nw_loadr_seq IS
  begin
   execute immediate'create context gc_new_loader_seq_cur_val using commons_utils_1 accessed globally'; 
  end p_create_context_nw_loadr_seq;  
  
 PROCEDURE p_set_context_load_mv_seq(pin_loader_seq pls_integer DEFAULT new_loader_seq.nextval ) 
IS
  BEGIN
     dbms_session.set_context('gc_load_mv_seq_cur_val', 'global_attribute', pin_loader_seq);   
  END p_set_context_load_mv_seq;
  
PROCEDURE p_create_context_load_mv_seq 
IS
  BEGIN
   EXECUTE IMMEDIATE 'create context gc_load_mv_seq_cur_val using commons_utils_1 accessed globally'; 
  END p_create_context_load_mv_seq;  
  
 procedure p_create_contexts IS
  begin
   --p_create_context_logging;
   --p_create_context_geo_location;
   --p_create_context_loader_seq;
   p_create_context_nw_loadr_seq;
   p_create_context_load_mv_seq;
  end  p_create_contexts;
  
 ----COMMENTED FOR NEW ARCHITECTURE--- 

--  FUNCTION f_get_mv_data_count(P_MV_NAME IN VARCHAR2, P_MV_REFRESH_FREQ IN NUMBER)
--  RETURN NUMBER IS
--
--  -- -----------------------------------------------------------------------------
--  -- Author         : Vinchankar Shilpa
--  -- Reviewer       : Rajput Gaurav
--  -- Description    : Materialized views count based on its refresh frequency daily , monthly so on
--  
--  -- Change description :
--  -- -----------------------------------------------------------------------------  
--  lv_MV_PROPER_DATA_COUNT NUMBER :=0;
--  
--  BEGIN
--   IF P_MV_REFRESH_FREQ = 1  THEN
--          ----- daily
--          IF P_MV_NAME='VIEW_OPTYMYZE_VERSION_HISTORY'
--            THEN
--              lv_MV_PROPER_DATA_COUNT:=1;
--              ELSE
--          EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM ' || P_MV_NAME ||
--                            ' MV WHERE TRUNC(TO_DATE(MV.METRIC_DATE,''DD/MM/RRRR''))=TRUNC(SYSDATE-1) AND ROWNUM=1'
--            INTO lv_MV_PROPER_DATA_COUNT;
--            END IF;
--        ELSIF P_MV_REFRESH_FREQ = 2 THEN
--          ---- monthly
--          EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM ' || P_MV_NAME ||
--                            ' MV WHERE TRUNC(TO_DATE(MV.METRIC_DATE,''DD/MM/RRRR'')) BETWEEN LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE), -2)) + 1 AND LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE), -1))
--        AND ROWNUM=1'
--            INTO lv_MV_PROPER_DATA_COUNT;
--        ELSIF P_MV_REFRESH_FREQ = 3 THEN
--          ----- weekly
--          EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM ' || P_MV_NAME ||
--                            ' MV WHERE TRUNC(TO_DATE(MV.METRIC_DATE,''DD/MM/RRRR'')) BETWEEN NEXT_DAY(sysdate, ''MONDAY'') - 14 AND NEXT_DAY(sysdate, ''SUNDAY'') - 7 AND ROWNUM=1'
--            INTO lv_MV_PROPER_DATA_COUNT;
--        END IF;
--  RETURN lv_MV_PROPER_DATA_COUNT;
--  END f_get_mv_data_count;
--
--  PROCEDURE p_update_mview_status(P_ITERATION_NUMBER NUMBER) AS
--  -- -----------------------------------------------------------------------------
--  -- Author         : Vinchankar Shilpa
--  -- Reviewer       : Rajput Gaurav
--  -- Description    : Updates the MV status based on the provided Iteration number
--  
--  -- Change description :
--  -- -----------------------------------------------------------------------------  
--    PRAGMA AUTONOMOUS_TRANSACTION;
--    v_try_out_days NUMBER;
--  BEGIN
--    IF P_ITERATION_NUMBER = 1 THEN
--      ----- SET STATUS='N' FOR MVIEWS TO BE REFRESHED TODAY
--      UPDATE CONFIG_MATERIALIZED_VIEWS C
--         SET C.CMV_REFRESH_STATUS = 'N'
--       WHERE (C.CMV_SCHEDULED_REFRESH_DAY = 0 OR
--             (C.CMV_SCHEDULED_REFRESH_DAY = TO_CHAR(SYSDATE, 'D') AND
--             C.CMV_REFRESH_FREQUENCY = 3) OR
--             (TO_CHAR(TO_DATE(C.CMV_SCHEDULED_REFRESH_DAY, 'DD'), 'DD') =
--             TO_CHAR(SYSDATE, 'DD') AND C.CMV_REFRESH_FREQUENCY = 2));
--      ----- FAIL SCENERIO TILL 4TH ITERATION
--    ELSIF P_ITERATION_NUMBER = 4 THEN
--      UPDATE CONFIG_MATERIALIZED_VIEWS C
--         SET C.CMV_REFRESH_STATUS = 'B'
--       WHERE C.CMV_REFRESH_STATUS = 'N';
--      FOR I IN (SELECT *
--                  FROM CONFIG_MATERIALIZED_VIEWS C
--                 WHERE C.CMV_REFRESH_STATUS = 'B') LOOP
--        IF I.CMV_REFRESH_FREQUENCY = 2 THEN
--          SELECT TO_CHAR(TO_DATE(I.CMV_SCHEDULED_REFRESH_DAY +
--                                 C_MV_MONTHLY_REF_TRYOUT_DAYS,
--                                 'DD'),
--                         'DD') - TO_CHAR(SYSDATE, 'DD')
--            into v_try_out_days
--            FROM dual;
--        ELSIF I.CMV_REFRESH_FREQUENCY = 3 THEN
--          SELECT MOD((I.CMV_SCHEDULED_REFRESH_DAY +
--                     C_MV_MONTHLY_REF_TRYOUT_DAYS),
--                     7) - TO_CHAR(SYSDATE, 'D')
--            into v_try_out_days
--            FROM dual;
--        END IF;
--        commons_utils_1.P_ERROR_LOGGING(PI_METRIC_ID            => 'MV_REFRESH_ALERT_MAIL',
--                                      PI_PROCEDURE_NAME       => 'p_mview_refresh',
--                                      PI_ERROR_MESSAGE        => I.CMV_MV_NAME ||
--                                                                 '  MV is not refreshed till 4th iteration so MV status is marked as B(broken).'
--                                                                 --|| 'Iteration number:' ||--OF-103077
--                                                                 --P_ITERATION_NUMBER
--																 ||' This MV was scheduled to be refreshed ' || case
--                                                                  I.CMV_REFRESH_FREQUENCY
--                                                                   WHEN 1 THEN
--                                                                    'Daily'
--                                                                   WHEN 2 THEN
--                                                                    'Monthly on day ' ||
--                                                                    I.CMV_SCHEDULED_REFRESH_DAY ||
--                                                                    ' of month. Try out days left:' ||
--                                                                    v_try_out_days
--                                                                   WHEN 3 THEN
--                                                                    'Weekly on day ' ||
--                                                                    I.CMV_SCHEDULED_REFRESH_DAY ||
--                                                                    ' of week.'||chr(10)||' Try out days left:' ||
--                                                                    v_try_out_days
--                                                                 end,
--                                      PI_ERROR_IN_CODE        => c_ex_mv_refresh_alert,
--                                      PI_TEL_ERROR_EVENT_DATE => gv_processing_date);
--      END LOOP;
--    END IF;
--    COMMIT;
--  EXCEPTION
--    WHEN OTHERS THEN
--      commons_utils_1.P_ERROR_LOGGING(PI_METRIC_ID            => 'UPDATE_MVIEW_STATUS',
--                                    PI_PROCEDURE_NAME       => 'P_UPDATE_MVIEW_STATUS',
--                                    PI_ERROR_MESSAGE        => 'Procedure P_UPDATE_MVIEW_STATUS failed'||
--                                                               f_get_exception_backtrace,
--                                    PI_ERROR_IN_CODE        => SQLCODE,
--                                    PI_TEL_ERROR_EVENT_DATE => gv_processing_date);
--  END P_UPDATE_MVIEW_STATUS;
--
--
--  PROCEDURE p_mview_refresh(P_ITERATION_NUMBER NUMBER) AS
--  -- -----------------------------------------------------------------------------
--  -- Author         : Vinchankar Shilpa
--  -- Reviewer       : Rajput Gaurav
--  -- Description    : Sends 
--  
--  -- Change description :
--  -- -----------------------------------------------------------------------------  
--    lv_MV_PROPER_DATA_COUNT number := 0;
--  BEGIN
--/*    --- For updating status of mview='N' for mviews scheduled to be refreshed today
--    IF P_ITERATION_NUMBER = 1 THEN
--      commons_utils_1.P_UPDATE_MVIEW_STATUS(P_ITERATION_NUMBER);
--    END IF; */
--    FOR I IN (SELECT *
--                FROM CONFIG_MATERIALIZED_VIEWS C
--               WHERE C.CMV_REFRESH_STATUS IN ('N', 'B')) LOOP
--      BEGIN
--        DBMS_MVIEW.REFRESH(I.CMV_MV_NAME);
--        ---- if sucessful
--        lv_MV_PROPER_DATA_COUNT := F_GET_MV_DATA_COUNT(I.CMV_MV_NAME,
--                                                       I.CMV_REFRESH_FREQUENCY);
--        IF lv_MV_PROPER_DATA_COUNT > 0 THEN
--          UPDATE CONFIG_MATERIALIZED_VIEWS C
--             SET C.CMV_REFRESH_STATUS      = 'Y',
--                 C.CMV_ACTUAL_REFRESH_DATE = TRUNC(SYSDATE)
--           WHERE C.CMV_MV_ID = I.CMV_MV_ID;
--        ELSE
--          IF P_ITERATION_NUMBER < 4 THEN
--            commons_utils_1.P_ERROR_LOGGING(PI_METRIC_ID            => 'MV_REFRESH_ALERT_MAIL',
--                                          PI_PROCEDURE_NAME       => 'p_mview_refresh',
--                                          PI_ERROR_MESSAGE        => I.CMV_MV_NAME ||
--                                                                     '  MV is refreshed but it is empty.' ||chr(10)||'This MV was scheduled to be refreshed ' || case
--                                                                      I.CMV_REFRESH_FREQUENCY
--                                                                       WHEN 1 THEN
--                                                                        'Daily'
--                                                                       WHEN 2 THEN
--                                                                        'Monthly on day ' ||
--                                                                        I.CMV_SCHEDULED_REFRESH_DAY ||
--                                                                        ' of month'
--                                                                       WHEN 3 THEN
--                                                                        'Weekly on day ' ||
--                                                                        I.CMV_SCHEDULED_REFRESH_DAY ||
--                                                                        ' of week'
--                                                                     end,
--                                          PI_ERROR_IN_CODE        => c_ex_mv_refresh_alert,
--                                          PI_TEL_ERROR_EVENT_DATE => gv_processing_date);
--          END IF;
--        END IF;
--      EXCEPTION
--        WHEN OTHERS THEN
--          IF P_ITERATION_NUMBER < 4 THEN
--            commons_utils_1.P_ERROR_LOGGING(PI_METRIC_ID            => 'MV_REFRESH_ALERT_MAIL',
--                                          PI_PROCEDURE_NAME       => 'p_mview_refresh',
--                                          PI_ERROR_MESSAGE        => I.CMV_MV_NAME ||
--                                                                     ' MV refresh failed because refresh job failed.' ||CHR(10)||'So MV can contain old data'||CHR(10) ||'Backtraced : ' ||
--                                                                     f_get_exception_backtrace ||
--                                                                     ' because ' ||
--                                                                     sqlerrm ||chr(10)||
--                                                                     ' This MV was scheduled to be refreshed ' || case
--                                                                      I.CMV_REFRESH_FREQUENCY
--                                                                       WHEN 1 THEN
--                                                                        'Daily'
--                                                                       WHEN 2 THEN
--                                                                        'Monthly on day ' ||
--                                                                        I.CMV_SCHEDULED_REFRESH_DAY ||
--                                                                        ' of month'
--                                                                       WHEN 3 THEN
--                                                                        'Weekly on day ' ||
--                                                                        I.CMV_SCHEDULED_REFRESH_DAY ||
--                                                                        ' of week'
--                                                                     end,
--                                          PI_ERROR_IN_CODE        => c_ex_mv_refresh_alert,
--                                          PI_TEL_ERROR_EVENT_DATE => gv_processing_date);
--          END IF;
--      END;
--    END LOOP;
--    ------ mark F if try out day is over
--    FOR I IN (SELECT *
--                FROM CONFIG_MATERIALIZED_VIEWS C
--               WHERE C.CMV_REFRESH_STATUS = 'B'
--                 AND ((C.CMV_REFRESH_FREQUENCY = 3 AND MOD((C.CMV_SCHEDULED_REFRESH_DAY +
--                          C_MV_MONTHLY_REF_TRYOUT_DAYS),
--                          7) < TO_CHAR(SYSDATE, 'D'))
--                  OR (C.CMV_REFRESH_FREQUENCY = 2 AND TO_CHAR(TO_DATE(C.CMV_SCHEDULED_REFRESH_DAY +
--                                      C_MV_MONTHLY_REF_TRYOUT_DAYS,
--                                      'DD'),
--                              'DD') < TO_CHAR(SYSDATE, 'DD')))) LOOP
--      UPDATE CONFIG_MATERIALIZED_VIEWS C
--         SET C.CMV_REFRESH_STATUS = 'F'
--       WHERE C.CMV_MV_ID=I.CMV_MV_ID;
--    END LOOP;
--    --- For updating status of mview='B' failing after 4th iteration
--    IF P_ITERATION_NUMBER = 4 THEN
--      commons_utils_1.P_UPDATE_MVIEW_STATUS(P_ITERATION_NUMBER);
--      FOR I IN (SELECT *
--                  FROM CONFIG_MATERIALIZED_VIEWS C
--                 WHERE C.CMV_REFRESH_STATUS = 'F') LOOP
--       lv_MV_PROPER_DATA_COUNT := F_GET_MV_DATA_COUNT(I.CMV_MV_NAME,
--                                                       I.CMV_REFRESH_FREQUENCY); 
--      IF lv_MV_PROPER_DATA_COUNT=0 THEN
--        commons_utils_1.P_ERROR_LOGGING(PI_METRIC_ID            => 'MV_REFRESH_ALERT_MAIL',
--                                      PI_PROCEDURE_NAME       => 'p_mview_refresh',
--                                      PI_ERROR_MESSAGE        => I.CMV_MV_NAME ||
--                                                                 ' MV refresh failed after try out period of ' ||
--                                                                 C_MV_MONTHLY_REF_TRYOUT_DAYS ||
--                                                                 ' days.' ||chr(10)||' So MV is still in failed state(''F'')
--                                        This MV was scheduled to be refreshed ' || case
--                                                                  I.CMV_REFRESH_FREQUENCY
--                                                                   WHEN 1 THEN
--                                                                    'Daily'
--                                                                   WHEN 2 THEN
--                                                                    'Monthly on day ' ||
--                                                                    I.CMV_SCHEDULED_REFRESH_DAY ||
--                                                                    ' of month'
--                                                                   WHEN 3 THEN
--                                                                    'Weekly on day ' ||
--                                                                    I.CMV_SCHEDULED_REFRESH_DAY ||
--                                                                    ' of week'
--                                                                 end,
--                                      PI_ERROR_IN_CODE        => c_ex_mv_refresh_alert,
--                                      PI_TEL_ERROR_EVENT_DATE => gv_processing_date);
--      END IF;
--      END LOOP;
--    END IF;
--  EXCEPTION
--    WHEN OTHERS THEN
--      commons_utils_1.P_ERROR_LOGGING(PI_METRIC_ID            => 'REFRESH_ALERT_FOR_LOGGING',
--                                    PI_PROCEDURE_NAME       => 'p_mview_refresh',
--                                    PI_ERROR_MESSAGE        => 'Procedure p_mview_refresh failed' ||
--                                                               f_get_exception_backtrace,
--                                    PI_ERROR_IN_CODE        => SQLCODE,
--                                    PI_TEL_ERROR_EVENT_DATE => gv_processing_date);
--  END p_mview_refresh;

----COMMENTED FOR NEW ARCHITECTURE *end*--- 

  

Function  f_get_exception_backtrace return varchar2 AS
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Description    : Returns error backtrace and error stack 
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
lv_message_1 varchar2(32767);
lv_message varchar2(32767);
BEGIN

    SELECT '***** Backtrace Start ***** '
      || chr(10)
      || 'Execution Order'
      || chr(32)
      ||chr(32)
      ||'BTrace Line'
      || Chr(32)
      ||' Btrace Unit '
      ||chr(10)
      ||'-----------------'
      || chr(32)
      ||'-----------'
      || chr(32)
      ||'-------------'
      ||chr(10)
      || listagg(RPAD(level, 17)
      || RPAD(TO_CHAR(UTL_CALL_STACK.backtrace_line(level),'99'), 12)
      || UTL_CALL_STACK.backtrace_unit(level), chr(10) ) within GROUP (
    ORDER BY NULL)
      || chr(10)
      || '***** Backtrace End *****'
    INTO lv_message
    FROM dual
      CONNECT BY level < = UTL_CALL_STACK.backtrace_depth;
      
    SELECT '***** Error Stack Start ***** '
      || chr(10)
      || 'Depth'
      || chr(32)
      ||chr(32)
      ||'Error code '
      || Chr(32)
      ||' Error Message '
      ||chr(10)
      ||'------'
      || chr(32)
      ||'------------'
      || chr(32)
      ||'-------------'
      ||chr(10)
      || listagg(RPAD(level, 8)
      || RPAD('ORA-'
      || LPAD(UTL_CALL_STACK.error_number(level), 5, '0'), 12)
      || UTL_CALL_STACK.error_msg(level), chr(10) ) within GROUP (
    ORDER BY NULL)
      || chr(10)
      || '***** Error Stack End *****'
    INTO lv_message_1
    FROM dual
      CONNECT BY level < = UTL_CALL_STACK.error_depth;
    
    lv_message        := substr(lv_message||chr(10)||lv_message_1,1,32767);
    
    return lv_message;
exception
when others then
    commons_utils_1.P_ERROR_LOGGING(PI_METRIC_ID            => 'OTHER ERRORS',
                                    PI_PROCEDURE_NAME       => 'f_get_exception_backtrace',
                                    PI_ERROR_MESSAGE        => 'Procedure f_get_exception_backtrace failed' ||
                                                               dbms_utility.format_error_backtrace,
                                    PI_ERROR_IN_CODE        => SQLCODE,
                                    PI_TEL_ERROR_EVENT_DATE => gv_processing_date);
end f_get_exception_backtrace; 

PROCEDURE p_create_metric_base_table(pi_metric_id IN config_metrics.metric_id%type) IS

  lv_metric_table_name     config_metrics.metric_table_name%type;
  lv_metric_parameter_list commons_utils_1.optimizedvarchar2;
  lv_create_table          commons_utils_1.optimizedvarchar2;

begin

  select cm.metric_table_name
    into lv_metric_table_name
    from config_metrics cm
   where metric_id = pi_metric_id;

  SELECT listagg(metric_a_column_name || chr(32) ||
                 upper(metric_a_column_datatype),
                 ',') within GROUP(ORDER BY metric_a_order)
    into lv_metric_parameter_list
    from config_metric_attributes cma
   where cma.metric_a_metric_id = pi_metric_id;

  lv_create_table := 'CREATE TABLE ' || lv_metric_table_name || '(' ||
                     lv_metric_parameter_list || ')';

  execute immediate lv_create_table;

end p_create_metric_base_table;

PROCEDURE p_create_metric_tables(pi_metric_id IN config_metrics.metric_id%type) IS

---- external table
begin
  
commons_utils_1.p_create_external_table (pi_metric_id                => pi_metric_id,
                                       pi_file_date                => trunc(sysdate-1),
                                       pi_attach_string_to_filenam => 'DW_INPUT',
                                       pi_is_create_required       => 1);


---- base table

  commons_utils_1.p_create_metric_base_table(pi_metric_id =>  pi_metric_id);

end p_create_metric_tables;

  PROCEDURE p_fetch_SQS_metrics_wrapper(pin_processing_date in date, pi_attach_string_to_filenam in varchar2 default 'TEST' )  is
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Description    : Procedure that fetches the SQS metrics
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    lv_start_epoch_time number;
    lv_end_epoch_time   number;
    lv_proc_name  VARCHAR2(4001 CHAR) ;
    lv_metric_name VARCHAR(30 CHAR) ;
    lv_start_date date;
    lv_end_date date ;
    lv_split_value pls_integer;
    lv_Addition_factor pls_integer;
    lv_fetch_flag varchar2(4001);
    lv_state varchar2(4001);
    lv_json optimizedvarchar2;
    lv_heap_size optimizedvarchar2;
  
    le_state_of_job EXCEPTION;
    
  BEGIN
    lv_proc_name  := 'p_fetch_SQS_metrics_wrapper';
    lv_metric_name := 'SQS_METRICS';

    begin
       select '"'||
        replace (
        '{' || 
        rtrim (xmlagg (xmlelement (e, json_val || ', ')).extract ('//text()'), ', ')
        || '}' ,'&quot;','\"') || '"'
        into lv_json
        from
        (
        select metric_id,
        '"'|| lower(METRIC_MAPPED_NAME) || '" : "'|| TRIM(REPLACE(REPLACE(metric_input_file_path,'Root_path', (SELECT pr_value      FROM properties     WHERE pr_name = 'Telemetry_new_root_path')),'DDMMYYYY', to_char(sysdate, 'DDMMRRRR'))) || '"' json_val
        from config_metrics
        -- where METRIC_ENABLED='Y' (use it if required to fetch only active one's )
        where metric_source_id in (10) 
        );
    exception
    when no_data_found then 
      null;
    when others then 
    commons_utils_1.p_error_logging(pi_metric_id    => lv_metric_name,
                                        pi_procedure_name => lv_proc_name,
                                        pi_error_message  => 'Failed at forming JSON for the utility call',
                                        pi_error_in_code  => SQLCODE,
                                        pi_tel_error_event_date => pin_processing_date);
      raise;
    end;

    begin
      select '-' || PR_VALUE  into lv_heap_size from properties  where pr_name = 'SQS_HEAP_SIZE' ;
    exception
    when no_data_found then 
      null;
    when others then 
    commons_utils_1.p_error_logging(pi_metric_id    => lv_metric_name,
                                        pi_procedure_name => lv_proc_name,
                                        pi_error_message  => 'Failed at fetching heap size for SQS utility ',
                                        pi_error_in_code  => SQLCODE,
                                        pi_tel_error_event_date => pin_processing_date);
      raise;
    end;    
    
    BEGIN
            p_job_run_fetch_SQS_metrics(lv_heap_size,lv_json); 
  
            LOOP
                dbms_lock.sleep(20);
            -- using this instead of user_scheduler_jobs because of oracle's bug where status is not updated at times
              SELECT STATUS
              INTO lv_state
              FROM
              (SELECT u.STATUS,
              row_number() over ( partition BY JOB_NAME order by ACTUAL_START_DATE DESC) rn
                FROM user_SCHEDULER_JOB_RUN_DETAILS u
                WHERE job_name= 'FETCH_SQS_METRIC_JOB'
                )
              WHERE rn =1 ;  

                IF lv_state   IN( 'SUCCEEDED','COMPLETED','SCHEDULED') THEN
                     EXIT;
                ELSIF   lv_state = 'RUNNING' THEN
                    CONTINUE;
                ELSE
                      RAISE le_state_of_job;
                END IF;
            END LOOP;
          EXCEPTION
           WHEN le_state_of_job THEN
          commons_utils_1.p_error_logging(pi_metric_id    => lv_metric_name,
                                        pi_procedure_name => lv_proc_name,
                                        pi_error_message  => 'The state of the job  FETCH_SQS_METRIC_JOB at  ' || sysdate || 'was '|| lv_state || 'hence fetching of SQS metrics did not take place ',
                                        pi_error_in_code  => SQLCODE,
                                        pi_tel_error_event_date => pin_processing_date);
  
            WHEN OTHERS THEN
             commons_utils_1.p_error_logging(pi_metric_id    => lv_metric_name,
                                         pi_procedure_name => lv_proc_name,
                                         pi_error_message  => 'Error in p_fetch_SQS_metrics_wrapper : '   || SQLERRM,
                                         pi_error_in_code  => SQLCODE,
                                         pi_tel_error_event_date => pin_processing_date);
          END;
   EXCEPTION
    WHEN OTHERS THEN
            commons_utils_1.p_error_logging(pi_metric_id    => lv_metric_name,
                                        pi_procedure_name => lv_proc_name,
                                        pi_error_message  => 'Error in p_fetch_SQS_metrics_wrapper : ' || SQLERRM,
                                        pi_error_in_code  => SQLCODE,
                                        pi_tel_error_event_date => pin_processing_date);
                                        raise;
  END p_fetch_SQS_metrics_wrapper; 
  
PROCEDURE p_load_SQS_wrapper(pin_processing_date date) IS
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav
  -- Reviewer       : Rajput Gaurav
  -- Description    : Wrapper procedure for loading of SQS metric
  
  -- Change description :
  -- -----------------------------------------------------------------------------
    lv_metric_string varchar2(4001);
  BEGIN
    SELECT LISTAGG(CM.METRIC_ID,',') within GROUP(ORDER BY CM.METRIC_ID) INTO lv_metric_string FROM CONFIG_METRICS CM WHERE CM.METRIC_SOURCE_ID = 10  AND CM.METRIC_ENABLED='Y';
    commons_utils_1.p_insert_table_load_metrics(pin_processing_date,lv_metric_string);
    
    FOR indx_metric_id IN (SELECT distinct metric_id
                             FROM table_load_metrics
                            WHERE loaded_flag = 'N'
                              AND loaded_date = pin_processing_date
                              and metric_id in (91,92,93,94,95,96,98,99,100,101,102,103,104,105,106)) LOOP  
        begin                              
              <<case_metrics_function_call>>
              CASE indx_metric_id.metric_id
              when 91 then
                   SAVEPOINT S_91;
                   commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                            pi_metric_id =>91,
                                            pi_extra_derived_cols_val =>'CURRENT_DATE',
                                            pi_attach_string_to_filenam => 'DW_INPUT');
        /*     
             when 92 then
                   SAVEPOINT S_92;
                   commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                            pi_metric_id =>92,
                                            pi_extra_derived_cols_val =>'CURRENT_DATE',
                                            pi_attach_string_to_filenam => 'DW_INPUT');
          
            when 93 then
                   SAVEPOINT S_93;
                   commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                            pi_metric_id =>93,
                                            pi_extra_derived_cols_val =>'CURRENT_DATE',
                                            pi_attach_string_to_filenam => 'DW_INPUT');
        
            when 94 then
                   SAVEPOINT S_94;
                   commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                            pi_metric_id =>94,
                                            pi_extra_derived_cols_val =>'CURRENT_DATE',
                                            pi_attach_string_to_filenam => 'DW_INPUT');                                    
        
            when 95 then
                   SAVEPOINT S_95;
                   commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                            pi_metric_id =>95,
                                            pi_extra_derived_cols_val =>'CURRENT_DATE',
                                            pi_attach_string_to_filenam => 'DW_INPUT');                                    
        
            when 96 then
                   SAVEPOINT S_96;
                   commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                            pi_metric_id =>96,
                                            pi_extra_derived_cols_val =>'CURRENT_DATE',
                                            pi_attach_string_to_filenam => 'DW_INPUT');                                    
                                           
            when 98 then
                   SAVEPOINT S_98;
                   commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                            pi_metric_id =>98,
                                            pi_extra_derived_cols_val =>'CURRENT_DATE',
                                            pi_attach_string_to_filenam => 'DW_INPUT');                                    
            when 99 then
                   SAVEPOINT S_99;
                   commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                            pi_metric_id =>99,
                                            pi_extra_derived_cols_val =>'CURRENT_DATE',
                                            pi_attach_string_to_filenam => 'DW_INPUT');                                    
        
            when 100 then
                   SAVEPOINT S_100;
                   commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                            pi_metric_id =>100,
                                            pi_extra_derived_cols_val =>'CURRENT_DATE',
                                            pi_attach_string_to_filenam => 'DW_INPUT');                                    
        
            when 101 then
                   SAVEPOINT S_101;
                   commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                            pi_metric_id =>101,
                                            pi_extra_derived_cols_val =>'CURRENT_DATE',
                                            pi_attach_string_to_filenam => 'DW_INPUT'); */                                   
            when 102 then
                   SAVEPOINT S_102;
                   commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                            pi_metric_id =>102,
                                            pi_extra_derived_cols_val =>'CURRENT_DATE',
                                            pi_attach_string_to_filenam => 'DW_INPUT');                                    
            when 103 then
                   SAVEPOINT S_103;
                   commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                            pi_metric_id =>103,
                                            pi_extra_derived_cols_val =>'CURRENT_DATE',
                                            pi_attach_string_to_filenam => 'DW_INPUT');                                    
            when 104 then
                   SAVEPOINT S_104;
                   commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                            pi_metric_id =>104,
                                            pi_extra_derived_cols_val =>'CURRENT_DATE',
                                            pi_attach_string_to_filenam => 'DW_INPUT');                                   
            when 105 then
                   SAVEPOINT S_105;
                   commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                            pi_metric_id =>105,
                                            pi_extra_derived_cols_val =>'CURRENT_DATE',
                                            pi_attach_string_to_filenam => 'DW_INPUT');                                    
            when 106 then
                   SAVEPOINT S_106;
                   commons_utils_1.p_load_metric(pi_file_date =>pin_processing_date,
                                            pi_metric_id =>106,
                                            pi_extra_derived_cols_val =>'CURRENT_DATE',
                                            pi_attach_string_to_filenam => 'DW_INPUT');                                    
                                          
        
              END CASE case_metrics_function_call;
        EXCEPTION 
        WHEN CASE_NOT_FOUND THEN
            NULL;
        END;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      commons_utils_1.p_error_logging(pi_metric_id    => 'SQS_Metrics',
                                  pi_procedure_name => 'p_load_SQS_wrapper',
                                  pi_error_message  => 'In  When others (last) of load of SQS wrapper' || SQLERRM || SQLCODE,
                                  pi_error_in_code  => SQLERRM || SQLCODE,
                                  pi_tel_error_event_date => pin_processing_date);
      RAISE;
END p_load_SQS_wrapper;

------ADDING MV REFRESH PROCEDURES--------------------
FUNCTION f_get_mv_data_count(P_MV_NAME IN VARCHAR2, P_MV_REFRESH_FREQ IN NUMBER)
  RETURN NUMBER IS

  -- -----------------------------------------------------------------------------
  -- Author         : Vinchankar Shilpa
  -- Reviewer       : Rajput Gaurav
  -- Description    : Materialized views count based on its refresh frequency daily , monthly so on
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
  lv_MV_PROPER_DATA_COUNT NUMBER :=0;
  
  BEGIN
   IF P_MV_REFRESH_FREQ = 1  THEN
          ----- daily
          IF P_MV_NAME='VIEW_OPTYMYZE_VERSION_HISTORY'
            THEN
              lv_MV_PROPER_DATA_COUNT:=1;
              ELSE
          EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM ' || P_MV_NAME ||
                            ' MV WHERE TRUNC(TO_DATE(MV.METRIC_DATE,''DD/MM/RRRR''))=TRUNC(SYSDATE-1) AND ROWNUM=1'
            INTO lv_MV_PROPER_DATA_COUNT;
            END IF;
        ELSIF P_MV_REFRESH_FREQ = 2 THEN
          ---- monthly
          EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM ' || P_MV_NAME ||
                            ' MV WHERE TRUNC(TO_DATE(MV.METRIC_DATE,''DD/MM/RRRR'')) BETWEEN LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE), -2)) + 1 AND LAST_DAY(ADD_MONTHS(TRUNC(SYSDATE), -1))
        AND ROWNUM=1'
            INTO lv_MV_PROPER_DATA_COUNT;
        ELSIF P_MV_REFRESH_FREQ = 3 THEN
          ----- weekly
          EXECUTE IMMEDIATE 'SELECT COUNT(1) FROM ' || P_MV_NAME ||
                            ' MV WHERE TRUNC(TO_DATE(MV.METRIC_DATE,''DD/MM/RRRR'')) BETWEEN NEXT_DAY(sysdate, ''MONDAY'') - 14 AND NEXT_DAY(sysdate, ''SUNDAY'') - 7 AND ROWNUM=1'
            INTO lv_MV_PROPER_DATA_COUNT;
        END IF;
  RETURN lv_MV_PROPER_DATA_COUNT;
  END f_get_mv_data_count;

  PROCEDURE p_update_mview_status(P_ITERATION_NUMBER NUMBER) AS
  -- -----------------------------------------------------------------------------
  -- Author         : Vinchankar Shilpa
  -- Reviewer       : Rajput Gaurav
  -- Description    : Updates the MV status based on the provided Iteration number
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    PRAGMA AUTONOMOUS_TRANSACTION;
    v_try_out_days NUMBER;
  BEGIN
    IF P_ITERATION_NUMBER = 1 THEN
      ----- SET STATUS='N' FOR MVIEWS TO BE REFRESHED TODAY
      UPDATE CONFIG_MATERIALIZED_VIEWS_NEW C
         SET C.CMV_REFRESH_STATUS = 'N'
       WHERE (C.CMV_SCHEDULED_REFRESH_DAY = 0 OR
             (C.CMV_SCHEDULED_REFRESH_DAY = TO_CHAR(SYSDATE, 'D') AND
             C.CMV_REFRESH_FREQUENCY = 3) OR
             (TO_CHAR(TO_DATE(C.CMV_SCHEDULED_REFRESH_DAY, 'DD'), 'DD') =
             TO_CHAR(SYSDATE, 'DD') AND C.CMV_REFRESH_FREQUENCY = 2));
      ----- FAIL SCENERIO TILL 4TH ITERATION
    ELSIF P_ITERATION_NUMBER = 4 THEN
      UPDATE CONFIG_MATERIALIZED_VIEWS_NEW C
         SET C.CMV_REFRESH_STATUS = 'B'
       WHERE C.CMV_REFRESH_STATUS = 'N';
      FOR I IN (SELECT distinct C.CMV_MV_NAME, C.CMV_SCHEDULED_REFRESH_DAY, C.CMV_REFRESH_FREQUENCY    ---- OF-106067
                  FROM CONFIG_MATERIALIZED_VIEWS_NEW C
                 WHERE C.CMV_REFRESH_STATUS = 'B') LOOP
        IF I.CMV_REFRESH_FREQUENCY = 2 THEN
          SELECT TO_CHAR(TO_DATE(I.CMV_SCHEDULED_REFRESH_DAY +
                                 C_MV_MONTHLY_REF_TRYOUT_DAYS,
                                 'DD'),
                         'DD') - TO_CHAR(SYSDATE, 'DD')
            into v_try_out_days
            FROM dual;
        ELSIF I.CMV_REFRESH_FREQUENCY = 3 THEN
          SELECT MOD((I.CMV_SCHEDULED_REFRESH_DAY +
                     C_MV_MONTHLY_REF_TRYOUT_DAYS),
                     7) - TO_CHAR(SYSDATE, 'D')
            into v_try_out_days
            FROM dual;
        END IF;
        COMMONS_UTILS.P_ERROR_LOGGING(PI_METRIC_ID            => 'MV_REFRESH_ALERT_MAIL',
                                      PI_PROCEDURE_NAME       => 'p_mview_refresh',
                                      PI_ERROR_MESSAGE        => I.CMV_MV_NAME ||
                                                                 '  MV is not refreshed till 4th iteration so MV status is marked as B(broken).'
                                                                 --|| 'Iteration number:' ||--OF-103077
                                                                 --P_ITERATION_NUMBER
                                                                 --||chr(10)
                                 ||' This MV was scheduled to be refreshed ' || case
                                                                  I.CMV_REFRESH_FREQUENCY
                                                                   WHEN 1 THEN
                                                                    'Daily'
                                                                   WHEN 2 THEN
                                                                    'Monthly on day ' ||
                                                                    I.CMV_SCHEDULED_REFRESH_DAY ||
                                                                    ' of month. Try out days left:' ||
                                                                    v_try_out_days
                                                                   WHEN 3 THEN
                                                                    'Weekly on day ' ||
                                                                    I.CMV_SCHEDULED_REFRESH_DAY ||
                                                                    ' of week.'||chr(10)||' Try out days left:' ||
                                                                    v_try_out_days
                                                                 end,
                                      PI_ERROR_IN_CODE        => c_ex_mv_refresh_alert,
                                      PI_TEL_ERROR_EVENT_DATE => gv_processing_date);
      END LOOP;
    END IF;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      COMMONS_UTILS.P_ERROR_LOGGING(PI_METRIC_ID            => 'UPDATE_MVIEW_STATUS',
                                    PI_PROCEDURE_NAME       => 'P_UPDATE_MVIEW_STATUS',
                                    PI_ERROR_MESSAGE        => 'Procedure P_UPDATE_MVIEW_STATUS failed'||
                                                               f_get_exception_backtrace,
                                    PI_ERROR_IN_CODE        => SQLCODE,
                                    PI_TEL_ERROR_EVENT_DATE => gv_processing_date);
  END P_UPDATE_MVIEW_STATUS;


  PROCEDURE p_mview_refresh(P_ITERATION_NUMBER NUMBER) AS
  -- -----------------------------------------------------------------------------
  -- Author         : Vinchankar Shilpa
  -- Reviewer       : Rajput Gaurav
  -- Description    : Sends 
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    lv_MV_PROPER_DATA_COUNT number := 0;
  BEGIN
    --- For updating status of mview='N' for mviews scheduled to be refreshed today
    IF P_ITERATION_NUMBER = 1 THEN
      COMMONS_UTILS.P_UPDATE_MVIEW_STATUS(P_ITERATION_NUMBER);
    END IF;
    FOR I IN (SELECT distinct C.CMV_MV_NAME, C.CMV_REFRESH_FREQUENCY, c.CMV_SCHEDULED_REFRESH_DAY   --- OF-106067
                FROM CONFIG_MATERIALIZED_VIEWS_NEW C
               WHERE C.CMV_REFRESH_STATUS IN ('N', 'B') order by C.CMV_MV_NAME) LOOP    --- OF-106067
      BEGIN
        DBMS_MVIEW.REFRESH(I.CMV_MV_NAME);
        ---- if sucessful
        lv_MV_PROPER_DATA_COUNT := F_GET_MV_DATA_COUNT(I.CMV_MV_NAME,
                                                       I.CMV_REFRESH_FREQUENCY);
        IF lv_MV_PROPER_DATA_COUNT > 0 THEN
          UPDATE CONFIG_MATERIALIZED_VIEWS_NEW C
             SET C.CMV_REFRESH_STATUS      = 'Y',
                 C.CMV_ACTUAL_REFRESH_DATE = TRUNC(SYSDATE),
                 C.CMV_ITERATION_NUMBER=P_ITERATION_NUMBER      --- OF-106067
           WHERE C.CMV_MV_NAME = I.CMV_MV_NAME;
        ELSE
          IF P_ITERATION_NUMBER < 4 THEN
            COMMONS_UTILS.P_ERROR_LOGGING(PI_METRIC_ID            => 'MV_REFRESH_ALERT_MAIL',
                                          PI_PROCEDURE_NAME       => 'p_mview_refresh',
                                          PI_ERROR_MESSAGE        => I.CMV_MV_NAME ||
                                                                     '  MV is refreshed but it is empty.' ||chr(10)||'This MV was scheduled to be refreshed ' || case
                                                                      I.CMV_REFRESH_FREQUENCY
                                                                       WHEN 1 THEN
                                                                        'Daily'
                                                                       WHEN 2 THEN
                                                                        'Monthly on day ' ||
                                                                        I.CMV_SCHEDULED_REFRESH_DAY ||
                                                                        ' of month'
                                                                       WHEN 3 THEN
                                                                        'Weekly on day ' ||
                                                                        I.CMV_SCHEDULED_REFRESH_DAY ||
                                                                        ' of week'
                                                                     end,
                                          PI_ERROR_IN_CODE        => c_ex_mv_refresh_alert,
                                          PI_TEL_ERROR_EVENT_DATE => gv_processing_date);
          END IF;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          IF P_ITERATION_NUMBER < 4 THEN
            COMMONS_UTILS.P_ERROR_LOGGING(PI_METRIC_ID            => 'MV_REFRESH_ALERT_MAIL',
                                          PI_PROCEDURE_NAME       => 'p_mview_refresh',
                                          PI_ERROR_MESSAGE        => I.CMV_MV_NAME ||
                                                                     ' MV refresh failed because refresh job failed.' ||CHR(10)||'So MV can contain old data'||CHR(10) ||'Backtraced : ' ||
                                                                     f_get_exception_backtrace ||
                                                                     ' because ' ||
                                                                     sqlerrm ||chr(10)||
                                                                     ' This MV was scheduled to be refreshed ' || case
                                                                      I.CMV_REFRESH_FREQUENCY
                                                                       WHEN 1 THEN
                                                                        'Daily'
                                                                       WHEN 2 THEN
                                                                        'Monthly on day ' ||
                                                                        I.CMV_SCHEDULED_REFRESH_DAY ||
                                                                        ' of month'
                                                                       WHEN 3 THEN
                                                                        'Weekly on day ' ||
                                                                        I.CMV_SCHEDULED_REFRESH_DAY ||
                                                                        ' of week'
                                                                     end,
                                          PI_ERROR_IN_CODE        => c_ex_mv_refresh_alert,
                                          PI_TEL_ERROR_EVENT_DATE => gv_processing_date);
          END IF;
      END;
    END LOOP;
    ------ mark F if try out day is over
    FOR I IN (SELECT distinct c.CMV_MV_NAME         --- OF-106067
                FROM CONFIG_MATERIALIZED_VIEWS_NEW C
               WHERE C.CMV_REFRESH_STATUS = 'B'
                 AND ((C.CMV_REFRESH_FREQUENCY = 3 AND MOD((C.CMV_SCHEDULED_REFRESH_DAY +
                          C_MV_MONTHLY_REF_TRYOUT_DAYS),
                          7) < TO_CHAR(SYSDATE, 'D'))
                  OR (C.CMV_REFRESH_FREQUENCY = 2 AND TO_CHAR(TO_DATE(C.CMV_SCHEDULED_REFRESH_DAY +
                                      C_MV_MONTHLY_REF_TRYOUT_DAYS,
                                      'DD'),
                              'DD') < TO_CHAR(SYSDATE, 'DD')))) LOOP
      UPDATE CONFIG_MATERIALIZED_VIEWS_NEW C
         SET C.CMV_REFRESH_STATUS = 'F'
       WHERE C.CMV_MV_NAME=I.CMV_MV_NAME;          --- OF-106067
    END LOOP;
    --- For updating status of mview='B' failing after 4th iteration
    IF P_ITERATION_NUMBER = 4 THEN
      COMMONS_UTILS.P_UPDATE_MVIEW_STATUS(P_ITERATION_NUMBER);
      FOR I IN (SELECT DISTINCT C.CMV_MV_NAME, C.CMV_REFRESH_FREQUENCY, C.CMV_SCHEDULED_REFRESH_DAY      ---- OF-106067
                  FROM CONFIG_MATERIALIZED_VIEWS_NEW C
                 WHERE C.CMV_REFRESH_STATUS = 'F') LOOP
       lv_MV_PROPER_DATA_COUNT := F_GET_MV_DATA_COUNT(I.CMV_MV_NAME,
                                                       I.CMV_REFRESH_FREQUENCY); 
      IF lv_MV_PROPER_DATA_COUNT=0 THEN
        COMMONS_UTILS.P_ERROR_LOGGING(PI_METRIC_ID            => 'MV_REFRESH_ALERT_MAIL',
                                      PI_PROCEDURE_NAME       => 'p_mview_refresh',
                                      PI_ERROR_MESSAGE        => I.CMV_MV_NAME ||
                                                                 ' MV refresh failed after try out period of ' ||
                                                                 C_MV_MONTHLY_REF_TRYOUT_DAYS ||
                                                                 ' days.' ||chr(10)||' So MV is still in failed state(''F'')
                                        This MV was scheduled to be refreshed ' || case
                                                                  I.CMV_REFRESH_FREQUENCY
                                                                   WHEN 1 THEN
                                                                    'Daily'
                                                                   WHEN 2 THEN
                                                                    'Monthly on day ' ||
                                                                    I.CMV_SCHEDULED_REFRESH_DAY ||
                                                                    ' of month'
                                                                   WHEN 3 THEN
                                                                    'Weekly on day ' ||
                                                                    I.CMV_SCHEDULED_REFRESH_DAY ||
                                                                    ' of week'
                                                                 end,
                                      PI_ERROR_IN_CODE        => c_ex_mv_refresh_alert,
                                      PI_TEL_ERROR_EVENT_DATE => gv_processing_date);
      END IF;
      END LOOP;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      COMMONS_UTILS.P_ERROR_LOGGING(PI_METRIC_ID            => 'REFRESH_ALERT_FOR_LOGGING',
                                    PI_PROCEDURE_NAME       => 'p_mview_refresh',
                                    PI_ERROR_MESSAGE        => 'Procedure p_mview_refresh failed' ||
                                                               f_get_exception_backtrace,
                                    PI_ERROR_IN_CODE        => SQLCODE,
                                    PI_TEL_ERROR_EVENT_DATE => gv_processing_date);
  END p_mview_refresh;   
------ADDING MV REFRESH PROCEDURES--------------------
---ADD WRAPPER,JOB SCHEDULE FOR RUNNING WRAPPER *END*
 PROCEDURE p_SQS_metrics_load_mv_wrapper(P_check_flag varchar2 default 'N') is
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Master Wrapper procedure that is invoked from scheduler
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    lv_processing_date date;
    lv_bad_file_seq pls_integer;
    lv_attach_string_to_filename varchar2(4001);
    lv_mail_flag varchar2(4001);
    lv_ocm_flag  varchar2(4001);
    lv_check_flag varchar2(1);
    lv_loader_seq_val number;
    
  begin
    lv_check_flag :=P_check_flag;
    IF lv_check_flag='Y'
    THEN
      p_set_context_load_mv_seq;   ---- setting context gc_new_loader_seq_cur_val
    END IF;
    
    select sys_context('gc_load_mv_seq_cur_val', 'global_attribute') 
      into lv_loader_seq_val 
      from dual; 
      
    lv_bad_file_seq:=lv_loader_seq_val;           
   
    --- Making the MV blank
   /* IF lv_bad_file_seq = 1 
    THEN
      commons_utils_1.P_UPDATE_MVIEW_STATUS(lv_bad_file_seq);
        FOR I IN (SELECT *
                    FROM CONFIG_MATERIALIZED_VIEWS_NEW C
                   WHERE C.CMV_REFRESH_STATUS IN ('N')) 
        LOOP
            DBMS_MVIEW.REFRESH(I.CMV_MV_NAME);
        END LOOP;
    END IF;

    BEGIN
         p_table_ocm_sync_insert (pi_processing_date=>(gv_processing_date+1));
        
         select TOC_FLAG into lv_ocm_flag 
           from table_ocm_sync 
          where TOC_EVENT_DATE=gv_processing_date+1;
          
      IF lv_ocm_flag='N' 
      THEN
          DELETE FROM config_environments_ocm;
          DELETE FROM config_farms_ocm;
          DELETE FROM config_client_projects_ocm;-- temporary commnt until FETCH CALL OF OCM is not in place
          COMMIT;
          --Merge master config tables from _ocm staging tables that are fetched via ocm_sync_job 
          p_config_tables_merge_ocm (pin_processing_date=>(gv_processing_date+1) );
      END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
           commons_utils_1.p_telemetry_info_logging(  pi_procedure_name => 'p_SQS_metrics_wrapper',
                                                      pi_description =>'Error in p_table_ocm_sync_insert/p_config_tables_merge_ocm : '|| SQLERRM|| 'Backtraced : ' || commons_utils_1.f_get_exception_backtrace );
    end;
  */
  
  ------- SQS metrics
       Begin
         execute immediate ' alter session set nls_date_format = ''dd-mm-yyyy''';
         p_load_SQS_wrapper(gv_processing_date-1);
       EXCEPTION
          WHEN OTHERS THEN
           commons_utils_1.p_telemetry_info_logging(  pi_procedure_name => 'p_SQS_metrics_load_mv_wrapper',
                                                      pi_description =>'Error in p_SQS_metrics_load_mv_wrapper : '|| SQLERRM|| 'Backtraced : ' || commons_utils_1.f_get_exception_backtrace );
        end;
 ---- MV refresh call
    Begin
      p_mview_refresh(lv_bad_file_seq);
    EXCEPTION
      WHEN OTHERS THEN
           commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_SQS_metrics_load_mv_wrapper',
                                                      pi_description =>'Error in p_mview_refresh : '|| SQLERRM|| 'Backtraced : ' || commons_utils_1.f_get_exception_backtrace );
    end;

 /*    select PR_VALUE into lv_mail_flag from properties WHERE PR_ID=4 ;
     if lv_mail_flag ='Y'
       then
     commons_utils_1.p_send_alert_email(pin_processing_date=> gv_processing_date,
                                        pin_load_current_iteration=>lv_bad_file_seq);
     end if;
   */
    -- commit;
    EXCEPTION
      WHEN OTHERS THEN
        commons_utils_1.p_error_logging(pi_metric_id            => 'p_SQS_metrics_load_mv_wrapper',
                                        pi_procedure_name       => 'p_SQS_metrics_load_mv_wrapper',
                                        pi_error_message        => 'In  When others (last) of p_SQS_metrics_load_mv_wrapper'|| ' Backtraced: ' || commons_utils_1.f_get_exception_backtrace,
                                        pi_error_in_code        => SQLERRM || SQLCODE,
                                        pi_tel_error_event_date => gv_processing_date);
        RAISE;
  END p_SQS_metrics_load_mv_wrapper;
  
 PROCEDURE p_job_create_load_mv_Sqs
    IS
      exists_cnt pls_integer;
    BEGIN

        SELECT COUNT(1)
        INTO exists_cnt
        FROM USER_SCHEDULER_SCHEDULES
        WHERE schedule_name = 'TWO_AM_SCHEDULE';
        --------------create schedule-----------------
        IF exists_cnt =0 
        THEN
        DBMS_SCHEDULER.CREATE_SCHEDULE (SCHEDULE_NAME   => 'TWO_AM_SCHEDULE',
                                        REPEAT_INTERVAL => 'FREQ=DAILY; BYHOUR=2,3; BYMINUTE=0,30',
                                        START_DATE      => TRUNC(sysdate),
                                        COMMENTS        => '4 half-hourly schedules for 2AM,2:30AM,3AM,3:30AM');
        END IF;

        SELECT COUNT(1)
        INTO exists_cnt
        FROM USER_SCHEDULER_programs
        WHERE PROGRAM_NAME = 'SQS_METRIC_LOAD_MV_SQS_PROG';
        --------------create program----------------- 
        IF exists_cnt=0 
        THEN
        DBMS_SCHEDULER.CREATE_PROGRAM ( PROGRAM_NAME        => 'SQS_METRIC_LOAD_MV_SQS_PROG',
                                        PROGRAM_TYPE        =>'STORED_PROCEDURE',
                                        PROGRAM_ACTION      => 'COMMONS_UTILS_1.P_SQS_METRICS_LOAD_MV_WRAPPER',
                                        ENABLED             => FALSE,
                                        NUMBER_OF_ARGUMENTS => 1,
                                        COMMENTS            => 'This would load all the sqs metrics to the database and refresh mv'
                                       );
        DBMS_SCHEDULER.DEFINE_PROGRAM_ARGUMENT(PROGRAM_NAME      => 'SQS_METRIC_LOAD_MV_SQS_PROG',
                                               ARGUMENT_POSITION => 1,
                                               ARGUMENT_NAME     => 'P_check_flag',
                                               ARGUMENT_TYPE     => 'VARCHAR2',
                                               DEFAULT_VALUE     => 'Y');
                                               
        DBMS_SCHEDULER.ENABLE(NAME =>'SQS_METRIC_LOAD_MV_SQS_PROG' );

        END IF;

        SELECT COUNT(1)
        INTO exists_cnt
        FROM USER_SCHEDULER_jobs a
        WHERE JOB_NAME = 'SQS_METRIC_LOAD_MV_SQS_JOB';
        --------------create job----------------- 
        IF exists_cnt  =0 
        THEN
        DBMS_SCHEDULER.CREATE_JOB(JOB_NAME      => 'SQS_METRIC_LOAD_MV_SQS_JOB',
                                  PROGRAM_NAME  => 'SQS_METRIC_LOAD_MV_SQS_PROG',
                                  SCHEDULE_NAME => 'TWO_AM_SCHEDULE',
                                  ENABLED       => true,
                                  AUTO_DROP     => false,
                                  COMMENTS      => 'This job will run the SQS_METRIC_LOAD_MV_SQS_PROG program according to the 3am_SCHEDULE schedule.');

        END IF;
        
    END p_job_create_load_mv_Sqs;
    
    PROCEDURE  p_job_deletion_load_mv_sqs
    IS
      exists_cnt pls_integer;
    BEGIN
        SELECT COUNT(1)
        INTO exists_cnt
        FROM USER_SCHEDULER_SCHEDULES
        WHERE SCHEDULE_NAME = 'TWO_AM_SCHEDULE';
        --------------delete schedule-----------------
        IF exists_cnt       =1 
        THEN
          DBMS_SCHEDULER.DROP_SCHEDULE('TWO_AM_SCHEDULE',TRUE);
        END IF;
        
        SELECT COUNT(1)
        INTO exists_cnt
        FROM USER_SCHEDULER_PROGRAMS
        WHERE PROGRAM_NAME = 'SQS_METRIC_LOAD_MV_SQS_PROG';
        --------------delete program-----------------
        IF exists_cnt      =1 
        THEN
          DBMS_SCHEDULER.DROP_PROGRAM ('SQS_METRIC_LOAD_MV_SQS_PROG', TRUE);
        END IF;

        SELECT COUNT(1)
        INTO exists_cnt
        FROM USER_SCHEDULER_JOBS A
        WHERE JOB_NAME = 'SQS_METRIC_LOAD_MV_SQS_JOB';
          --------------delete job-----------------
        IF exists_cnt  =1 
        THEN
          DBMS_SCHEDULER.DROP_JOB ( 'SQS_METRIC_LOAD_MV_SQS_JOB',TRUE);
        END IF;    
    END p_job_deletion_load_mv_sqs;


  
     ---ADD WRAPPER,context,JOB SCHEDULE FOR RUNNING WRAPPER *END* 
  
PROCEDURE p_SQS_metrics_wrapper(P_check_flag varchar2 default 'N') is
  -- -----------------------------------------------------------------------------
  -- Author         : Rajput Gaurav 
  -- Reviewer       : Rajput Gaurav
  -- Description    : Master Wrapper procedure that is invoked from scheduler
  
  -- Change description :
  -- -----------------------------------------------------------------------------  
    lv_processing_date date;
    lv_bad_file_seq pls_integer;
    lv_attach_string_to_filename varchar2(4001);
    lv_mail_flag varchar2(4001);
    lv_ocm_flag  varchar2(4001);
    lv_check_flag varchar2(1);
    lv_loader_seq_val number;
    
  begin
    lv_check_flag :=P_check_flag;
    IF lv_check_flag='Y'
    then
      p_set_context_new_loader_seq;   ---- setting context gc_new_loader_seq_cur_val
    end if;
    select sys_context('gc_new_loader_seq_cur_val', 'global_attribute') into lv_loader_seq_val from dual; 
      
    lv_bad_file_seq:=lv_loader_seq_val;           
/*    
    --- Making the MV blank
    IF lv_bad_file_seq = 1 THEN
    commons_utils_1.P_UPDATE_MVIEW_STATUS(lv_bad_file_seq);
    FOR I IN (SELECT *
                FROM CONFIG_MATERIALIZED_VIEWS C
               WHERE C.CMV_REFRESH_STATUS IN ('N')) LOOP
        DBMS_MVIEW.REFRESH(I.CMV_MV_NAME);
    end loop;
    END IF;

    BEGIN
    p_table_ocm_sync_insert (pi_processing_date=>(gv_processing_date+1));
    select TOC_FLAG into lv_ocm_flag from table_ocm_sync where TOC_EVENT_DATE=gv_processing_date+1;
      if lv_ocm_flag='N' then
          Delete from config_environments_ocm;
          Delete from config_farms_ocm;
          Delete from config_client_projects_ocm;-- temporary commnt until FETCH CALL OF OCM is not in place
          COMMIT;
          --Merge master config tables from _ocm staging tables that are fetched via ocm_sync_job 
          p_config_tables_merge_ocm (pin_processing_date=>(gv_processing_date+1) );
      END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
           commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_SQS_metrics_wrapper',pi_description =>'Error in p_table_ocm_sync_insert/p_config_tables_merge_ocm : '|| SQLERRM|| 'Backtraced : ' || commons_utils_1.f_get_exception_backtrace );
    end;
  */
  
  ------- SQS metrics
       Begin
         execute immediate ' alter session set nls_date_format = ''dd-mm-yyyy''';
         p_fetch_SQS_metrics_wrapper(gv_processing_date,pi_attach_string_to_filenam => 'DW_INPUT'); -- ADD lv_attach_string_to_filename for determining the input string for prod or testing
       EXCEPTION
          WHEN OTHERS THEN
           commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_SQS_metrics_wrapper',pi_description =>'Error in p_SQS_PR_metrics_wrapper '|| SQLERRM|| 'Backtraced : ' || commons_utils_1.f_get_exception_backtrace );
        end;
  
  /*   
     ---- MV refresh call
    Begin
      p_mview_refresh(lv_bad_file_seq);
    EXCEPTION
      WHEN OTHERS THEN
           commons_utils_1.p_telemetry_info_logging(  pi_procedure_name       => 'p_SQS_metrics_wrapper',pi_description =>'Error in p_mview_refresh : '|| SQLERRM|| 'Backtraced : ' || commons_utils_1.f_get_exception_backtrace );
    end;

     select PR_VALUE into lv_mail_flag from properties WHERE PR_ID=4 ;
     if lv_mail_flag ='Y'
       then
     commons_utils_1.p_send_alert_email(pin_processing_date=> gv_processing_date,pin_load_current_iteration=>lv_bad_file_seq);
     end if;
*/     
    -- commit;
    EXCEPTION
      WHEN OTHERS THEN
        commons_utils_1.p_error_logging(pi_metric_id    => 'p_SQS_metrics_wrapper',
                                    pi_procedure_name => 'p_SQS_metrics_wrapper',
                                    pi_error_message  => 'In  When others (last) of p_SQS_metrics_wrapper'|| ' Backtraced: ' || commons_utils_1.f_get_exception_backtrace,
                                    pi_error_in_code  => SQLERRM || SQLCODE,
                                    pi_tel_error_event_date => gv_processing_date);
        RAISE;
  END p_SQS_metrics_wrapper;

begin
    -- selecting the root path from properties table
    SELECT pr_value
      INTO gv_root
      FROM properties
     WHERE pr_name = 'Telemetry_root_path';
    
    -- selecting the new root path from properties table
    SELECT pr_value
      INTO gv_new_root
      FROM properties
     WHERE pr_name = 'Telemetry_new_root_path';


    -- selecting the Logging path from properties table
    SELECT pr_value
      INTO gv_loggingroot
      FROM properties
     WHERE pr_name = 'Logging_path';
     
    SELECT TRUNC(SYSDATE-1) 
     INTO gv_processing_date 
     FROM dual ;
	 
	 -- selecting the new Logging path from properties table
    SELECT pr_value
      INTO gv_loggingroot
      FROM properties
     WHERE pr_name = 'New_logging_path';
     

END commons_utils_1;
/

