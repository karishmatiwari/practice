create materialized view VIEW_CLIENTS
refresh complete on demand
  as
    with dates_between as
(select last_day(add_months(trunc(sysdate), -2)) + 1 first_date,
         last_day(add_months(trunc(sysdate), -1)) last_date
    from dual)
SELECT to_char(cp_client_id) CLIENT_ID,
cp_client_name CLIENT_NAME,
CP_CLIENT_COMPLETE_NAME CLIENT_COMPLETE_NAME,
       to_char(dates_between.last_date, 'DD-MM-YYYY') METRIC_DATE,
       TRIM(to_CHAR(dates_between.last_date, 'Month')) ||' '||to_CHAR(dates_between.last_date, 'YYYY') METRIC_MONTH
       FROM config_client_projects
   cross join dates_between
   where CP_IS_DELETED=0
/

